# master/main.py
import asyncio
import os
import time
import uuid
from typing import Dict, Any, List, Optional
from urllib.parse import parse_qs

import socketio
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.responses import PlainTextResponse
from socketio.asgi import ASGIApp

import logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [MASTER] %(message)s")
log = logging.getLogger("master")

import json
from pathlib import Path
import datetime as dt
from dotenv import load_dotenv

# ---------------- ENV / CONFIG ----------------
load_dotenv(os.getenv("ENV_FILE", ".env"), override=False)

PORT = int(os.getenv("PORT", "8000"))
MAX_QUEUE_PER_SENDER = int(os.getenv("MAX_QUEUE_PER_SENDER", "120"))
FRAME_HARD_TIMEOUT_MS = int(os.getenv("FRAME_HARD_TIMEOUT_MS", "0"))  # 0: disabled
RESULTS_JSONL = os.getenv("RESULTS_JSONL", "logs/inference_results.jsonl")

DEFAULT_GROUP = os.getenv("DEFAULT_GROUP", "default")
REQUIRED_TYPES = [t.strip() for t in os.getenv("REQUIRED_TYPES", "A,B,C").split(",") if t.strip()]

STRICT_WAIT_FOR_ALL = os.getenv("STRICT_WAIT_FOR_ALL", "1") == "1"
# ------------------------------------------------

sio = socketio.AsyncServer(
    async_mode="asgi",
    cors_allowed_origins="*",
    max_http_buffer_size=100_000_000,
)
app = FastAPI(title="Multigroup Multi-type Master")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
socket_app = ASGIApp(sio, other_asgi_app=app)

# ---------------- State ----------------
# sender_sid -> { "group":str, "queue":Queue, "inflight":frame_id|None }
senders: Dict[str, Dict[str, Any]] = {}

# groups[group][type] = { worker_id: { "sid":str, "busy":bool } }
groups: Dict[str, Dict[str, Dict[str, Dict[str, Any]]]] = {}

# frame_id -> {
#   "sender_sid": str,
#   "group": str,
#   "required_types": List[str],
#   "assigned_workers": Dict[type, worker_id],
#   "results": Dict[type, List[dict]],
#   "meta": {"width":int,"height":int},
#   "deadline_ms": float|None
# }
inflight_frames: Dict[str, Dict[str, Any]] = {}

schedule_lock = asyncio.Lock()

# ---------------- Utils ----------------
def _now_ms() -> float:
    return time.time() * 1000.0

async def _append_result_jsonl(payload: dict):
    path = Path(RESULTS_JSONL)
    path.parent.mkdir(parents=True, exist_ok=True)
    if "ts" not in payload:
        payload = {**payload, "ts": dt.datetime.utcnow().isoformat() + "Z"}
    line = json.dumps(payload, ensure_ascii=False) + "\n"

    def _write():
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)

    await asyncio.to_thread(_write)

def _sender_group(sid: str) -> str:
    info = senders.get(sid) or {}
    return info.get("group", DEFAULT_GROUP)

def _get_sender_queue(sid: str) -> asyncio.Queue:
    return senders[sid]["queue"]

def _get_free_worker_for_type(group: str, wtype: str) -> Optional[str]:
    # pick any not busy
    pool = groups.get(group, {}).get(wtype, {})
    for wid, meta in pool.items():
        if not meta.get("busy", False):
            return wid
    return None

def _reserve_workers_for_frame(group: str, required_types: List[str]) -> Optional[Dict[str, str]]:
    assigned = {}
    # ensure atomic reservation: check all free first
    for t in required_types:
        wid = _get_free_worker_for_type(group, t)
        if not wid:
            return None
        assigned[t] = wid
    # mark busy
    for t, wid in assigned.items():
        groups[group][t][wid]["busy"] = True
    return assigned

def _mark_workers_free(group: str, assigned: Dict[str, str]):
    for t, wid in assigned.items():
        pool = groups.get(group, {}).get(t, {})
        if wid in pool:
            pool[wid]["busy"] = False

async def _dispatch_next_if_ready(sender_sid: str):
    """
    For this sender:
    - must have no inflight
    - must have a non-empty queue
    - must be able to reserve one free worker of each required type in its group
    """
    async with schedule_lock:
        sinfo = senders.get(sender_sid)
        if not sinfo:
            return
        if sinfo["inflight"] is not None:
            return
        q: asyncio.Queue = sinfo["queue"]
        if q.empty():
            return

        group = sinfo["group"]
        required_types = REQUIRED_TYPES

        assigned = _reserve_workers_for_frame(group, required_types)
        if not assigned:
            # cannot schedule now; workers busy
            return

        # take next chunk
        chunk = await q.get()
        frame_id = chunk["frame_id"]
        sinfo["inflight"] = frame_id

        inflight_frames[frame_id] = {
            "sender_sid": sender_sid,
            "group": group,
            "required_types": required_types,
            "assigned_workers": assigned,  # type -> worker_id
            "results": {},                # type -> det list
            "meta": {"width": chunk["width"], "height": chunk["height"]},
            "deadline_ms": (_now_ms() + FRAME_HARD_TIMEOUT_MS) if FRAME_HARD_TIMEOUT_MS > 0 else None,
        }

        log.info(f"DISPATCH frame={frame_id} group={group} workers={assigned} queue_after_pop={q.qsize()}")

        # emit to each assigned worker
        for wtype, wid in assigned.items():
            wsid = groups[group][wtype][wid]["sid"]
            await sio.emit("process_frame", {
                "frame_id": frame_id,
                "image_b64": chunk["image_b64"],
                "width": chunk["width"],
                "height": chunk["height"],
                "worker_id": wid,
                "worker_type": wtype,
                "group": group,
            }, to=wsid)

        # optional timeout
        if FRAME_HARD_TIMEOUT_MS > 0:
            asyncio.create_task(_finalize_on_timeout(frame_id))

async def _finalize_on_timeout(frame_id: str):
    pf = inflight_frames.get(frame_id)
    if not pf:
        return
    deadline = pf.get("deadline_ms")
    if not deadline:
        return
    await asyncio.sleep(max(0.0, (deadline - _now_ms()) / 1000.0))
    if frame_id in inflight_frames:
        if STRICT_WAIT_FOR_ALL:
            log.warning(f"Timeout for frame={frame_id}; STRICT_WAIT_FOR_ALL=1, keeping in-flight.")
            return
        await _finalize_frame(frame_id, timed_out=True)

async def _finalize_frame(frame_id: str, timed_out: bool = False):
    pf = inflight_frames.pop(frame_id, None)
    if not pf:
        return
    sender_sid = pf["sender_sid"]
    group = pf["group"]
    assigned = pf["assigned_workers"]  # type->wid
    results = pf["results"]
    meta = pf["meta"]
    required_types = pf["required_types"]

    # payload with independent outputs
    results_by_type = {t: results.get(t, []) for t in required_types}
    per_type_counts = {t: len(results_by_type[t] or []) for t in required_types}
    # flat concat (kept for compatibility)
    merged = []
    for t in required_types:
        for d in results_by_type[t] or []:
            dd = dict(d); dd["worker_id"] = assigned.get(t); dd["type"] = t
            merged.append(dd)

    payload = {
        "frame_id": frame_id,
        "width": meta["width"],
        "height": meta["height"],
        "group": group,
        "required_types": required_types,
        "workers_assigned": assigned,        # type -> worker_id
        "workers_responded": [t for t in required_types if t in results],
        "per_type_counts": per_type_counts,
        "results_by_type": results_by_type,  # type -> raw list of dets
        "merged_detections": merged,         # unmerged concat with type/worker tags
        "queue_depth": _get_sender_queue(sender_sid).qsize(),
        "timed_out": timed_out,
    }

    await _append_result_jsonl(payload)
    log.info(f"FINALIZE frame={frame_id} group={group} per_type={per_type_counts} timed_out={timed_out}")
    await sio.emit("inference", payload, to=sender_sid)

    # free workers + clear inflight + try next for this sender
    _mark_workers_free(group, assigned)
    senders[sender_sid]["inflight"] = None
    await _dispatch_next_if_ready(sender_sid)

def _maybe_reassign_on_worker_loss(group: str, wtype: str, lost_wid: str):
    """
    If a worker disconnects while assigned to an in-flight frame, try to reassign
    that type to another free worker in the same group and resend the frame.
    """
    for frame_id, pf in list(inflight_frames.items()):
        if pf["group"] != group:
            continue
        assigned = pf["assigned_workers"]
        if assigned.get(wtype) != lost_wid:
            continue
        # find a replacement
        new_wid = _get_free_worker_for_type(group, wtype)
        if not new_wid:
            log.warning(f"Reassign needed but no free {wtype} in group={group} for frame={frame_id}")
            continue
        # reserve replacement
        groups[group][wtype][new_wid]["busy"] = True
        assigned[wtype] = new_wid
        # re-send to new worker
        meta = pf["meta"]
        sender_sid = pf["sender_sid"]
        q = senders[sender_sid]["queue"]  # just to confirm sender exists
        wsid = groups[group][wtype][new_wid]["sid"]
        # we need original image; we didn't keep it. For simplicity, we *ask the sender to resend* is complex.
        # Better: store the last image payload per inflight frame.
        # We'll store it when dispatching:
        # (this function assumes pf["image_b64"] exists.)
        image_b64 = pf.get("image_b64")
        if image_b64 is None:
            log.error(f"Cannot re-dispatch frame={frame_id} (image not cached).")
            continue
        sio.start_background_task(sio.emit, "process_frame", {
            "frame_id": frame_id,
            "image_b64": image_b64,
            "width": meta["width"],
            "height": meta["height"],
            "worker_id": new_wid,
            "worker_type": wtype,
            "group": group,
        }, to=wsid)
        log.info(f"Reassigned frame={frame_id} type={wtype} -> worker={new_wid} in group={group}")

# ---------------- Socket.IO events ----------------
@sio.event
async def connect(sid, environ, auth):
    scope = environ.get("asgi.scope") or {}
    qs = scope.get("query_string", b"").decode("utf-8")
    q = parse_qs(qs)
    role = (q.get("role", [""])[0]).lower()

    if role == "worker":
        group = (q.get("group", [DEFAULT_GROUP])[0]).strip() or DEFAULT_GROUP
        wtype = (q.get("type", [""])[0]).strip()  # A | B | C etc
        wid = (q.get("worker_id", [""])[0]).strip()
        if not wtype:
            log.warning(f"Rejecting worker (missing type). sid={sid}")
            return
        if not wid:
            log.warning(f"Rejecting worker (missing worker_id). sid={sid}")
            return
        groups.setdefault(group, {}).setdefault(wtype, {})[wid] = {"sid": sid, "busy": False}
        log.info(f"WORKER CONNECT group={group} type={wtype} id={wid} sid={sid}")

    elif role == "sender":
        group = (q.get("group", [DEFAULT_GROUP])[0]).strip() or DEFAULT_GROUP
        senders[sid] = {"group": group, "queue": asyncio.Queue(maxsize=MAX_QUEUE_PER_SENDER), "inflight": None}
        log.info(f"SENDER CONNECT sid={sid} group={group}")

    else:
        log.info(f"Unknown client role={role} sid={sid}")

@sio.event
async def disconnect(sid):
    # worker?
    for group, types in list(groups.items()):
        for wtype, pool in list(types.items()):
            for wid, meta in list(pool.items()):
                if meta["sid"] == sid:
                    pool.pop(wid, None)
                    log.info(f"WORKER DISCONNECT group={group} type={wtype} id={wid}")
                    # try to reassign if this worker was processing a frame
                    _maybe_reassign_on_worker_loss(group, wtype, wid)
                    return

    # sender?
    if sid in senders:
        sinfo = senders.pop(sid)
        # drain queue
        q = sinfo["queue"]
        while not q.empty():
            try:
                q.get_nowait()
            except Exception:
                break
        # if in-flight, finalize to release workers
        frame_id = sinfo["inflight"]
        if frame_id and frame_id in inflight_frames:
            pf = inflight_frames.pop(frame_id)
            _mark_workers_free(pf["group"], pf["assigned_workers"])
            log.info(f"Sender left; dropping in-flight frame={frame_id}")
        log.info(f"SENDER DISCONNECT sid={sid}")

@sio.event
async def media_chunk(sid, payload):
    """
    Sender -> Master
    payload: { image_b64, width:int, height:int }
    """
    sinfo = senders.get(sid)
    if not sinfo:
        return
    image_b64 = payload.get("image_b64")
    width = int(payload.get("width", 0))
    height = int(payload.get("height", 0))
    frame_id = str(uuid.uuid4())

    q: asyncio.Queue = sinfo["queue"]
    if q.full():
        try:
            _ = q.get_nowait()
        except Exception:
            pass

    await q.put({"frame_id": frame_id, "image_b64": image_b64, "width": width, "height": height})
    # try to dispatch
    await _dispatch_next_if_ready(sid)

@sio.event
async def result(sid, payload):
    """
    Worker -> Master
    payload: { frame_id, worker_id, worker_type, detections:[...] }
    """
    frame_id = payload.get("frame_id")
    wtype = payload.get("worker_type")
    wid = payload.get("worker_id")
    dets = payload.get("detections") or []

    pf = inflight_frames.get(frame_id)
    if not pf:
        return

    group = pf["group"]
    assigned = pf["assigned_workers"]
    # accept only the assigned worker for this type
    if not wtype or assigned.get(wtype) != wid:
        return

    pf["results"][wtype] = dets

    # all types done?
    if all(t in pf["results"] for t in pf["required_types"]):
        await _finalize_frame(frame_id)

# ---------------- FastAPI route ----------------
@app.get("/", response_class=PlainTextResponse)
def root():
    return "Master online. Workers: ?role=worker&type=A|B|C&group=<g>&worker_id=<id> ; Senders: ?role=sender&group=<g>"

# ---------------- Entrypoint ----------------
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:socket_app", host="0.0.0.0", port=PORT, reload=False)
