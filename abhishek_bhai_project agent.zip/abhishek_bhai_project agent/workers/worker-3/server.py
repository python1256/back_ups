# worker/worker.py
import os
import sys
import socket
from pathlib import Path

import socketio
import torch
from ultralytics import YOLO

# shared util
sys.path.append(str(Path(__file__).resolve().parents[1] / "common"))
from common.utils import b64_to_cv2  # noqa: E402

MASTER_URL = os.getenv("MASTER_URL", "http://localhost:8000")
GROUP = os.getenv("GROUP", "default")
WORKER_TYPE = os.getenv("WORKER_TYPE", "C")      # A | B | C ...
WORKER_ID = os.getenv("WORKER_ID")               # optional; auto if missing
if not WORKER_ID:
    host = socket.gethostname().split(".")[0]
    pid = os.getpid()
    WORKER_ID = f"{WORKER_TYPE}_{GROUP}_{host}_{pid}"

MODEL_PATH = os.getenv("MODEL_PATH", "yolov8n.pt")
CONF_THRESH = float(os.getenv("CONF_THRESH", "0.25"))
IOU_THRESH  = float(os.getenv("IOU_THRESH", "0.45"))
DEVICE      = os.getenv("DEVICE", "cpu")  # "cpu" or "cuda:0"

print(f"[worker {WORKER_ID}] connect -> {MASTER_URL} group={GROUP} type={WORKER_TYPE} model={MODEL_PATH} device={DEVICE}")
torch.set_grad_enabled(False)

model = YOLO(MODEL_PATH)
model.fuse()
model.overrides["conf"] = CONF_THRESH
model.overrides["iou"] = IOU_THRESH

sio = socketio.Client(reconnection=True, reconnection_attempts=0, logger=False)

@sio.event
def connect():
    print(f"[worker {WORKER_ID}] connected: {sio.sid}")

@sio.event
def disconnect():
    print(f"[worker {WORKER_ID}] disconnected")

@sio.on("process_frame")
def on_process_frame(payload):
    frame_id = payload.get("frame_id")
    image_b64 = payload.get("image_b64")
    print(f"[worker {WORKER_ID}] ASSIGNED frame={frame_id}")

    img = b64_to_cv2(image_b64)
    if img is None:
        print(f"[worker {WORKER_ID}] frame={frame_id} image decode FAILED")
        sio.emit("result", {"frame_id": frame_id, "worker_id": WORKER_ID, "worker_type": WORKER_TYPE, "detections": []})
        return

    with torch.inference_mode():
        results = model.predict(img, imgsz=640, device=DEVICE, conf=CONF_THRESH, iou=IOU_THRESH, verbose=False)

    dets = []
    if results and len(results) > 0:
        r = results[0]
        if r.boxes is not None and len(r.boxes) > 0:
            h, w = img.shape[:2]
            xyxy = r.boxes.xyxy.cpu().numpy()
            confs = r.boxes.conf.cpu().numpy()
            clss = r.boxes.cls.cpu().numpy()
            for i in range(xyxy.shape[0]):
                x1, y1, x2, y2 = xyxy[i].tolist()
                dets.append({
                    "bbox": [x1 / w, y1 / h, x2 / w, y2 / h],
                    "conf": float(confs[i]),
                    "cls": int(clss[i]),
                })

    print(f"[worker {WORKER_ID}] DONE frame={frame_id} dets={len(dets)}")
    sio.emit("result", {"frame_id": frame_id, "worker_id": WORKER_ID, "worker_type": WORKER_TYPE, "detections": dets})

if __name__ == "__main__":
    sio.connect(f"{MASTER_URL}?role=worker&group={GROUP}&type={WORKER_TYPE}&worker_id={WORKER_ID}", wait=True)
    sio.wait()
