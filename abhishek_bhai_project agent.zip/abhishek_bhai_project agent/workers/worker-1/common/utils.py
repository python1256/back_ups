# common/utils.py
import base64
import re
import cv2
import numpy as np

_DATAURL_RE = re.compile(r"^data:image/(png|jpeg|jpg);base64,(?P<b64>.+)$", re.I)

def b64_to_cv2(data_url_or_b64):
    """
    Accepts either a data URL or raw base64 of a JPEG/PNG image.
    Returns BGR np.ndarray or None.
    """
    if not data_url_or_b64:
        return None
    m = _DATAURL_RE.match(data_url_or_b64)
    if m:
        b64 = m.group("b64")
    else:
        b64 = data_url_or_b64
    try:
        buf = base64.b64decode(b64, validate=True)
        arr = np.frombuffer(buf, dtype=np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        return img
    except Exception:
        return None
