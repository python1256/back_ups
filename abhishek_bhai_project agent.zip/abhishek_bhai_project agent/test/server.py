import asyncio
import os
import time
import uuid
from typing import Dict, Any, List
from urllib.parse import parse_qs

import socketio
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from starlette.responses import PlainTextResponse
from socketio.asgi import ASGIApp

import logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [MASTER] %(message)s")
log = logging.getLogger("master")

import json
from pathlib import Path
import datetime as dt
from dotenv import load_dotenv

# ---------------- ENV / CONFIG ----------------
load_dotenv(os.getenv("ENV_FILE", ".env"), override=False)

PORT = int(os.getenv("PORT", "8000"))
EXPECTED_WORKERS: List[str] = [os.getenv("W1", "1"), os.getenv("W2", "2"), os.getenv("W3", "3")]
MAX_QUEUE_PER_SENDER = int(os.getenv("MAX_QUEUE_PER_SENDER", "120"))
FRAME_HARD_TIMEOUT_MS = int(os.getenv("FRAME_HARD_TIMEOUT_MS", "0"))  # 0 = disabled
RESULTS_JSONL = os.getenv("RESULTS_JSONL", "logs/inference_results.jsonl")

# Hard-wire "no merge"
MERGE_MODE = "none"  # explicit: do not merge; keep outputs independent

# Strictly wait for all workers; never finalize early
STRICT_WAIT_FOR_ALL = os.getenv("STRICT_WAIT_FOR_ALL", "1") == "1"

# ------------------------------------------------

sio = socketio.AsyncServer(
    async_mode="asgi",
    cors_allowed_origins="*",
    max_http_buffer_size=100_000_000,  # large base64 frames
)

app = FastAPI(title="YOLOv8 Master (FastAPI + Socket.IO)")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"],
)
socket_app = ASGIApp(sio, other_asgi_app=app)

# ---------------- State ----------------
workers: Dict[str, str] = {}                  # worker_id -> socket sid
worker_busy: Dict[str, bool] = {w: False for w in EXPECTED_WORKERS}

# Per-sender queue and in-flight frame id
sender_queues: Dict[str, asyncio.Queue] = {}  # sender_sid -> asyncio.Queue[{frame_id,image_b64,w,h}]
sender_inflight: Dict[str, str] = {}          # sender_sid -> frame_id or None

# In-flight frames global map
# frame_id -> { sender_sid, deadline_ms, results: {wid: dets}, meta:{w,h} }
inflight_frames: Dict[str, Dict[str, Any]] = {}

schedule_lock = asyncio.Lock()

# ---------------- Utils ----------------
def _now_ms() -> float:
    return time.time() * 1000.0

def _all_workers_connected_and_free() -> bool:
    for wid in EXPECTED_WORKERS:
        if wid not in workers:
            return False
        if worker_busy.get(wid, False):
            return False
    return True

async def _append_result_jsonl(payload: dict):
    """Append one result JSON to RESULTS_JSONL (JSON Lines)."""
    path = Path(RESULTS_JSONL)
    path.parent.mkdir(parents=True, exist_ok=True)
    if "ts" not in payload:
        payload = {**payload, "ts": dt.datetime.utcnow().isoformat() + "Z"}
    line = json.dumps(payload, ensure_ascii=False) + "\n"

    def _write():
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)

    await asyncio.to_thread(_write)

async def _ensure_sender(sender_sid: str) -> asyncio.Queue:
    if sender_sid not in sender_queues:
        sender_queues[sender_sid] = asyncio.Queue(maxsize=MAX_QUEUE_PER_SENDER)
        sender_inflight[sender_sid] = None
    return sender_queues[sender_sid]

# ---------------- Scheduling ----------------
async def _dispatch_next_if_ready(sender_sid: str):
    """
    Pop one chunk for this sender and dispatch to ALL workers iff:
    - all workers are connected & free
    - this sender has no in-flight frame
    - the sender queue is non-empty
    """
    async with schedule_lock:
        if not _all_workers_connected_and_free():
            return
        if sender_inflight.get(sender_sid) is not None:
            return

        q = await _ensure_sender(sender_sid)
        if q.empty():
            return

        chunk = await q.get()
        frame_id = chunk["frame_id"]
        sender_inflight[sender_sid] = frame_id
        log.info(
            f"DISPATCH frame={frame_id} to workers {EXPECTED_WORKERS} (sender={sender_sid}) "
            f"queue_after_pop={q.qsize()}"
        )

        inflight_frames[frame_id] = {
            "sender_sid": sender_sid,
            "deadline_ms": (_now_ms() + FRAME_HARD_TIMEOUT_MS) if FRAME_HARD_TIMEOUT_MS > 0 else None,
            "results": {},  # wid -> list of dets (kept independent)
            "meta": {"width": chunk["width"], "height": chunk["height"]},
        }

        # lock the worker group (one frame at a time)
        for wid in EXPECTED_WORKERS:
            worker_busy[wid] = True

        # fan out the same frame to each expected worker
        for wid in EXPECTED_WORKERS:
            wsid = workers.get(wid)
            if wsid:
                await sio.emit("process_frame", {
                    "frame_id": frame_id,
                    "image_b64": chunk["image_b64"],
                    "width": chunk["width"],
                    "height": chunk["height"],
                    "worker_id": wid,
                }, to=wsid)
            else:
                log.warning(f"Worker {wid} missing at dispatch; waiting until all connect.")

        # optional hard-timeout — with STRICT_WAIT_FOR_ALL, we log only
        if FRAME_HARD_TIMEOUT_MS > 0:
            asyncio.create_task(_finalize_on_timeout(frame_id))

async def _finalize_on_timeout(frame_id: str):
    pf = inflight_frames.get(frame_id)
    if not pf:
        return
    deadline = pf.get("deadline_ms")
    if not deadline:
        return
    await asyncio.sleep(max(0.0, (deadline - _now_ms()) / 1000.0))
    if frame_id in inflight_frames:
        if STRICT_WAIT_FOR_ALL:
            log.warning(
                f"Timeout reached for frame={frame_id}, STRICT_WAIT_FOR_ALL=1 — still waiting for all workers."
            )
            return
        await _finalize_frame(frame_id, timed_out=True)

async def _finalize_frame(frame_id: str, timed_out: bool = False):
    pf = inflight_frames.pop(frame_id, None)
    if not pf:
        return

    sender_sid = pf["sender_sid"]
    meta = pf["meta"]
    results = pf["results"]  # { wid: [dets...] }  (independent, unmerged)

    # Deterministic per-worker map in 1->2->3 order
    results_by_worker = {wid: results.get(wid, []) for wid in EXPECTED_WORKERS}
    workers_responded = [wid for wid in EXPECTED_WORKERS if wid in results]
    per_worker_counts = {wid: len(results_by_worker[wid]) for wid in EXPECTED_WORKERS}

    # Pure concatenation (no merge, no NMS) for convenience & backward compatibility
    all_detections: List[dict] = []
    for wid in EXPECTED_WORKERS:
        dets = results_by_worker[wid] or []
        for d in dets:
            dd = dict(d)
            dd["worker_id"] = wid
            all_detections.append(dd)

    result_payload = {
        "frame_id": frame_id,
        "width": meta["width"],
        "height": meta["height"],
        "workers_expected": EXPECTED_WORKERS,
        "workers_responded": workers_responded,
        "per_worker_counts": per_worker_counts,
        "queue_depth": sender_queues.get(sender_sid).qsize() if sender_sid in sender_queues else 0,
        "timed_out": timed_out,

        # Keep everything independent; no merge performed
        "merge_mode": MERGE_MODE,                     # "none"
        "results_by_worker": results_by_worker,       # wid -> list of dets (raw)
        "all_detections": all_detections,             # simple 1->2->3 concat with worker_id tags

        # For clients that expect this field, we mirror all_detections:
        "merged_detections": all_detections,          # backward-compatible alias (no suppression)
    }

    await _append_result_jsonl(result_payload)
    log.info(
        f"FINALIZE frame={frame_id} mode={MERGE_MODE} per_worker={per_worker_counts} "
        f"all_dets={len(all_detections)} timed_out={timed_out}"
    )

    # Emit to sender
    await sio.emit("inference", result_payload, to=sender_sid)

    # Free workers + clear inflight for this sender, then try next
    for wid in EXPECTED_WORKERS:
        worker_busy[wid] = False
    sender_inflight[sender_sid] = None
    await _dispatch_next_if_ready(sender_sid)

# ---------------- Socket.IO events ----------------
@sio.event
async def connect(sid, environ, auth):
    scope = environ.get("asgi.scope") or {}
    qs = scope.get("query_string", b"").decode("utf-8")
    q = parse_qs(qs)
    role = (q.get("role", [""])[0]).lower()
    worker_id = (q.get("worker_id", [""])[0]).strip()

    if role == "worker" and worker_id:
        workers[worker_id] = sid
        worker_busy[worker_id] = False
        print(f"[master] worker {worker_id} connected ({sid})")
        # If a sender is waiting with a queued frame and all workers are free, scheduling will pick it up
    elif role == "sender":
        await _ensure_sender(sid)
        print(f"[master] sender connected ({sid})")
    else:
        print(f"[master] unknown client ({sid}) role={role!r}")

@sio.event
async def disconnect(sid):
    # worker?
    for wid, wsid in list(workers.items()):
        if wsid == sid:
            workers.pop(wid, None)
            worker_busy[wid] = False
            print(f"[master] worker {wid} disconnected")
            # With STRICT_WAIT_FOR_ALL, any in-flight frame will remain waiting until this worker reconnects
            return
    # sender?
    if sid in sender_queues:
        q = sender_queues.pop(sid)
        while not q.empty():
            try:
                q.get_nowait()
            except Exception:
                break
        frame_id = sender_inflight.pop(sid, None)
        if frame_id and frame_id in inflight_frames:
            # If the sender leaves, finalize to release the workers
            await _finalize_frame(frame_id, timed_out=True)
        print(f"[master] sender disconnected ({sid})")

@sio.event
async def media_chunk(sid, payload):
    """
    Sender -> Master
    payload: { image_b64: str, width: int, height: int }
    Always buffer per-sender; dispatch only when all workers are free & connected and no inflight.
    """
    image_b64 = payload.get("image_b64")
    width = int(payload.get("width", 0))
    height = int(payload.get("height", 0))
    frame_id = str(uuid.uuid4())

    q = await _ensure_sender(sid)
    if q.full():
        # drop the oldest to make room (bounded memory)
        try:
            _ = q.get_nowait()
        except Exception:
            pass

    await q.put({"frame_id": frame_id, "image_b64": image_b64, "width": width, "height": height})
    await _dispatch_next_if_ready(sid)

@sio.event
async def result(sid, payload):
    """
    Worker -> Master
    payload: { frame_id, worker_id, detections: [{bbox:[x1,y1,x2,y2], conf, cls}] }
    We strictly wait for ALL expected workers for this frame.
    """
    frame_id = payload.get("frame_id")
    worker_id = payload.get("worker_id")
    detections = payload.get("detections") or []

    pf = inflight_frames.get(frame_id)
    if not pf:
        # Late or unknown result; ignore
        return

    # Ignore unknown workers (not in EXPECTED_WORKERS)
    if worker_id not in EXPECTED_WORKERS:
        log.warning(f"Ignoring result from unexpected worker_id={worker_id} for frame={frame_id}")
        return

    # Store this worker's results (independent, unmerged)
    pf["results"][worker_id] = detections

    # Finalize only when ALL expected workers have responded for this frame
    if all(wid in pf["results"] for wid in EXPECTED_WORKERS):
        await _finalize_frame(frame_id)

# ---------------- FastAPI route ----------------
@app.get("/", response_class=PlainTextResponse)
def root():
    return "Master online. Sender connects with ?role=sender; workers with ?role=worker&worker_id=1|2|3."

# ---------------- Entrypoint ----------------
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:socket_app", host="0.0.0.0", port=PORT, reload=False)
