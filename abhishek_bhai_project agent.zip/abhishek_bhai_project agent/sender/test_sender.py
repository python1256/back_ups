# sender/test_sender.py
import argparse
import base64
import threading
import time

import cv2
import socketio

def draw_overlay(rgb_frame, dets):
    h, w = rgb_frame.shape[:2]
    out = rgb_frame.copy()
    for d in dets or []:
        x1, y1, x2, y2 = d["bbox"]
        rx1, ry1 = int(x1 * w), int(y1 * h)
        rx2, ry2 = int(x2 * w), int(y2 * h)
        cv2.rectangle(out, (rx1, ry1), (rx2, ry2), (0, 255, 0), 2)
        label = f"t={d.get('type','?')} w={d.get('worker_id','?')} cls={d.get('cls',-1)} conf={d.get('conf',0):.2f}"
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        ytxt = max(0, ry1 - th - 3)
        cv2.rectangle(out, (rx1, ytxt), (rx1 + tw + 6, ytxt + th + 6), (0, 0, 0), -1)
        cv2.putText(out, label, (rx1 + 3, ytxt + th + 2), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    return out

def encode_jpeg_b64(bgr_img, width, height, quality=70):
    resized = cv2.resize(bgr_img, (width, height), interpolation=cv2.INTER_AREA)
    ok, buf = cv2.imencode(".jpg", resized, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    if not ok:
        return None, None, None
    b64 = base64.b64encode(buf).decode("ascii")
    return f"data:image/jpeg;base64,{b64}", width, height

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--master", default="http://localhost:8000", help="Master URL")
    ap.add_argument("--group", default="default", help="Sender group")
    ap.add_argument("--source", default="0", help="0 = webcam, or file path")
    ap.add_argument("--width", type=int, default=640)
    ap.add_argument("--height", type=int, default=360)
    ap.add_argument("--limit", type=int, default=0, help="frames to send; 0=unlimited")
    ap.add_argument("--show", action="store_true")
    args = ap.parse_args()

    cap = cv2.VideoCapture(0 if args.source == "0" else args.source)
    if not cap.isOpened():
        raise RuntimeError(f"Could not open source: {args.source}")

    sio = socketio.Client(reconnection=True, reconnection_attempts=0)
    inflight = threading.Event()
    last_overlay = None
    sent = 0
    got = 0
    t0 = time.time()

    @sio.event
    def connect():
        print(f"[sender] connected: sid={sio.sid} group={args.group}")

    @sio.event
    def disconnect():
        print("[sender] disconnected")

    @sio.on("inference")
    def on_inference(payload):
        nonlocal got, last_overlay
        got += 1
        merged = payload.get("merged_detections") or []
        w = int(payload.get("width", args.width))
        h = int(payload.get("height", args.height))

        # quick per-type counts
        per_type = payload.get("per_type_counts", {})
        per_type_str = ", ".join([f"{k}:{v}" for k, v in per_type.items()])

        if args.show and last_overlay is not None:
            over = draw_overlay(last_overlay, merged)
            cv2.imshow("inference", cv2.cvtColor(over, cv2.COLOR_RGB2BGR))
            cv2.waitKey(1)

        inflight.clear()
        print(f"[inference] frame={payload.get('frame_id')} dets={len(merged)} per_type=[{per_type_str}] qdepth={payload.get('queue_depth')}")

    sio.connect(f"{args.master}?role=sender&group={args.group}", wait=True)

    try:
        while True:
            ok, frame_bgr = cap.read()
            if not ok:
                break

            if inflight.is_set():
                time.sleep(0.001)
                continue

            image_b64, w, h = encode_jpeg_b64(frame_bgr, args.width, args.height, quality=70)
            if image_b64 is None:
                continue

            if args.show:
                last_overlay = cv2.cvtColor(cv2.resize(frame_bgr, (w, h)), cv2.COLOR_BGR2RGB)

            sio.emit("media_chunk", {"image_b64": image_b64, "width": w, "height": h})
            inflight.set()
            sent += 1

            if args.limit and sent >= args.limit:
                break

        while inflight.is_set():
            time.sleep(0.01)

    finally:
        cap.release()
        if args.show:
            cv2.destroyAllWindows()
        try:
            sio.disconnect()
        except Exception:
            pass

    dt = max(1e-6, time.time() - t0)
    print(f"[sender] sent={sent} received={got} avg_send_rate={sent/dt:.2f} fps")

if __name__ == "__main__":
    main()
