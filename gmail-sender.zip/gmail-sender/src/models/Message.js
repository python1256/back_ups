const mongoose = require("mongoose");

const MessageSchema = new mongoose.Schema(
  {
    mailboxId: { type: mongoose.Schema.Types.ObjectId, ref: "Mailbox", index: true },
    folderPath: { type: String, index: true },
    uid: { type: Number, index: true },
    msgId: String,
    subject: String,
    fromAddr: String,
    toAddrs: [String],
    ccAddrs: [String],
    bccAddrs: [String],
    date: Date,
    flags: [String],
    snippet: String,
    textBody: String,
    htmlBody: String,
    hasAttachments: { type: Boolean, default: false }
  },
  { timestamps: true }
);

MessageSchema.index({ mailboxId: 1, folderPath: 1, uid: 1 }, { unique: true });
MessageSchema.index({ date: -1 });

module.exports = mongoose.model("Message", MessageSchema);
