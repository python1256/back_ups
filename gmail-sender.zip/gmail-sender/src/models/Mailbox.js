const mongoose = require("mongoose");

const MailboxSchema = new mongoose.Schema(
  {
    email: { type: String, required: true, unique: true },
    provider: { type: String, default: "gmail" },
    refreshToken: { type: String, required: true },
    accessToken: { type: String },
    accessTokenExp: { type: Number }
  },
  { timestamps: true }
);

MailboxSchema.index({ email: 1 }, { unique: true });

module.exports = mongoose.model("Mailbox", MailboxSchema);
