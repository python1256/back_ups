// const mongoose = require("mongoose");

// const toNumber = (v) => (typeof v === "bigint" ? Number(v) : v);

// const FolderSchema = new mongoose.Schema(
//   {
//     mailboxId: { type: mongoose.Schema.Types.ObjectId, ref: "Mailbox", index: true },
//     path: { type: String, required: true },
//     uidValidity: { type: Number, set: toNumber },   // <-- cast BigInt safely
//     lastUid: { type: Number, set: toNumber }        // (defensive)
//   },
//   { timestamps: true }
// );

// FolderSchema.index({ mailboxId: 1, path: 1 }, { unique: true });

// module.exports = mongoose.model("Folder", FolderSchema);



const mongoose = require("mongoose");
const toNumber = v => (typeof v === "bigint" ? Number(v) : v);

const FolderSchema = new mongoose.Schema(
  {
    mailboxId: { type: mongoose.Schema.Types.ObjectId, ref: "Mailbox", index: true },
    path: { type: String, required: true },
    uidValidity: { type: Number, set: toNumber },
    lastUid:    { type: Number, set: toNumber }
  },
  { timestamps: true }
);

FolderSchema.index({ mailboxId: 1, path: 1 }, { unique: true });

module.exports = mongoose.model("Folder", FolderSchema);
