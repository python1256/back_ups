require("dotenv").config();
const express = require("express");
const cookieParser = require("cookie-parser");
const { connectDB } = require("./db");
const cors = require("cors");
// const helmet = require("helmet");
// const rateLimit = require("express-rate-limit");
// const { auth } = require("./middleware/auth");
const oauthGoogle = require("./routes/oauthGoogle");
const mailboxes = require("./routes/mailboxes");
const messages = require("./routes/messages");
const folderRoutes = require("./routes/folders");
const actionRoutes = require("./routes/actions");
const searchRoutes = require("./routes/search");



const app = express();
app.use(express.json());
app.use(cookieParser());



connectDB();

// app.use(helmet());
app.use(cors({ origin:"*", credentials: false }));
// app.use(cors({ origin: process.env.CORS_ORIGIN, credentials: false }));
// app.use(rateLimit({ windowMs: 60_000, max: 120 })); // 120 requests per minute

app.get("/health", (_req, res) => res.send("ok"));
// app.use("/api", auth); 
app.use("/oauth/google", oauthGoogle);
app.use("/api/mailboxes", mailboxes);
app.use("/api/messages", messages);
app.use("/api/folders", folderRoutes);
app.use("/api/actions", actionRoutes);
app.use("/api/search", searchRoutes);

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`API running on :${port}`));
