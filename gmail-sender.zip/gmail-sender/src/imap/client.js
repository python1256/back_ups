const { ImapFlow } = require("imapflow");
const { getAccessToken } = require("../googleAuth");

function toNum(v) { return typeof v === "bigint" ? Number(v) : Number(v || 0); }

async function getImapClient(mailbox) {
  const accessToken = await getAccessToken(mailbox._id.toString());
  const client = new ImapFlow({
    host: "imap.gmail.com",
    port: 993,
    secure: true,
    auth: { user: mailbox.email, accessToken }
  });
  await client.connect();
  return { client, toNum };
}

module.exports = { getImapClient, toNum };
