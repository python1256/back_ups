const { ImapFlow } = require("imapflow");
const { simpleParser } = require("mailparser");
const Folder = require("../models/Folder");
const Message = require("../models/Message");
const { getAccessToken } = require("../googleAuth");

function toNum(v) { return typeof v === "bigint" ? Number(v) : Number(v || 0); }

async function syncInbox(mailbox, { idle = false } = {}) {
  const accessToken = await getAccessToken(mailbox._id.toString());

  const client = new ImapFlow({
    host: "imap.gmail.com",
    port: 993,
    secure: true,
    auth: { user: mailbox.email, accessToken }
  });

  await client.connect();
  console.log(`🔗 IMAP connected: ${mailbox.email}`);

  // --- CAST uidValidity ---
  const info = await client.mailboxOpen("INBOX");
  await Folder.findOneAndUpdate(
    { mailboxId: mailbox._id, path: "INBOX" },
    { uidValidity: toNum(info.uidValidity) },
    { upsert: true }
  );

  const folder = await Folder.findOne({ mailboxId: mailbox._id, path: "INBOX" });
  // --- CAST lastUid before math ---
  const fromUid = toNum(folder && folder.lastUid) + 1;
  const range = `${fromUid}:*`;

  for await (const msg of client.fetch(range, { uid: true, source: true, flags: true })) {
    const uid = toNum(msg.uid);                // <-- ensure Number
    const parsed = await simpleParser(msg.source);

    await Message.findOneAndUpdate(
      { mailboxId: mailbox._id, folderPath: "INBOX", uid },
      {
        msgId: parsed.messageId || undefined,
        subject: parsed.subject || undefined,
        fromAddr: parsed.from ? parsed.from.text : undefined,
        toAddrs: parsed.to && parsed.to.value ? parsed.to.value.map(v => v.address) : [],
        ccAddrs: parsed.cc && parsed.cc.value ? parsed.cc.value.map(v => v.address) : [],
        bccAddrs: parsed.bcc && parsed.bcc.value ? parsed.bcc.value.map(v => v.address) : [],
        date: parsed.date || undefined,
        flags: Array.from(msg.flags || []),
        snippet: (parsed.text || parsed.html || "").slice(0, 240),
        textBody: parsed.text || undefined,
        htmlBody: parsed.html || undefined,
        hasAttachments: Array.isArray(parsed.attachments) && parsed.attachments.length > 0
      },
      { upsert: true, new: true }
    );

    await Folder.updateOne(
      { mailboxId: mailbox._id, path: "INBOX" },
      { lastUid: uid }                          // <-- save as Number
    );
  }

  if (!idle) {
    await client.logout();
    return;
  }

  client.on("exists", async () => {
    try {
      const status = await client.status("INBOX", { uidNext: true });
      // --- CAST uidNext ---
      const uidNext = typeof status.uidNext === "bigint" ? Number(status.uidNext) : status.uidNext;
      const latest = (uidNext || 1) - 1;

      const iter = client.fetch({ uid: latest }, { uid: true, source: true, flags: true });
      const n = await iter.next();
      if (n.value && n.value.uid && n.value.source) {
        const uid = toNum(n.value.uid);        // <-- ensure Number
        const parsed = await simpleParser(n.value.source);

        await Message.findOneAndUpdate(
          { mailboxId: mailbox._id, folderPath: "INBOX", uid },
          {
            msgId: parsed.messageId,
            subject: parsed.subject,
            fromAddr: parsed.from ? parsed.from.text : undefined,
            toAddrs: parsed.to && parsed.to.value ? parsed.to.value.map(v => v.address) : [],
            date: parsed.date,
            flags: Array.from(n.value.flags || []),
            snippet: (parsed.text || parsed.html || "").slice(0, 240),
            textBody: parsed.text,
            htmlBody: parsed.html,
            hasAttachments: Array.isArray(parsed.attachments) && parsed.attachments.length > 0
          },
          { upsert: true }
        );

        await Folder.updateOne({ mailboxId: mailbox._id, path: "INBOX" }, { lastUid: uid });
      }
    } catch (e) {
      console.error("IDLE exists handler error", e);
    }
  });

  while (true) {
    await client.idle({ timeout: 20 * 60 * 1000 });
  }
}

module.exports = { syncInbox };
