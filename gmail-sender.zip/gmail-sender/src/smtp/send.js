const nodemailer = require("nodemailer");
const { getAccessToken } = require("../googleAuth");

async function sendViaGmail(mailbox, msg) {
  const accessToken = await getAccessToken(mailbox._id.toString());

  const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: { type: "OAuth2", user: mailbox.email, accessToken }
  });

  const info = await transporter.sendMail(msg);
  return { messageId: info.messageId, response: info.response };
}

module.exports = { sendViaGmail };
