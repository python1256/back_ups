const { OAuth2Client } = require("google-auth-library");
const Mailbox = require("./models/Mailbox");

const client = new OAuth2Client(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI
);

async function getAccessToken(mailboxId) {
  const mb = await Mailbox.findById(mailboxId);
  if (!mb) throw new Error("Mailbox not found");

  const now = Math.floor(Date.now() / 1000);
  if (mb.accessToken && mb.accessTokenExp && mb.accessTokenExp - 60 > now) {
    return mb.accessToken;
  }

  const { tokens } = await client.refreshToken(mb.refreshToken);
  if (!tokens.access_token || !tokens.expiry_date) {
    throw new Error("No access token from Google");
  }

  mb.accessToken = tokens.access_token;
  mb.accessTokenExp = Math.floor(tokens.expiry_date / 1000);
  await mb.save();

  return mb.accessToken;
}

module.exports = { getAccessToken };
