const express = require("express");
const Mailbox = require("../models/Mailbox");
const Folder = require("../models/Folder");
const { syncInbox } = require("../imap/sync");

const router = express.Router();

router.get("/", async (_req, res) => {
  const list = await Mailbox.find().lean();
  res.json(list);
});

router.post("/:id/sync", async (req, res) => {
  const mb = await Mailbox.findById(req.params.id);
  if (!mb) return res.status(404).json({ error: "Mailbox not found" });

  syncInbox(mb, { idle: false }).catch(console.error);
  res.json({ ok: true });
});

router.get("/:id/folders", async (req, res) => {
  const folders = await Folder.find({ mailboxId: req.params.id }).lean();
  res.json(folders);
});

module.exports = router;
