const express = require("express");
const Mailbox = require("../models/Mailbox");
const Message = require("../models/Message");
const { sendViaGmail } = require("../smtp/send");

const router = express.Router();

router.get("/", async (req, res) => {
  const { mailboxId } = req.query;
  const q = {};
  if (mailboxId) q.mailboxId = mailboxId;
  const items = await Message.find(q).sort({ date: -1 }).limit(50).lean();
  res.json(items);
});

router.get("/:id", async (req, res) => {
  const msg = await Message.findById(req.params.id).lean();
  if (!msg) return res.status(404).json({ error: "Not found" });
  res.json(msg);
});

router.post("/send/:mailboxId", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const { from, to, subject, text, html, cc, bcc, attachments } = req.body;
  if (!from || !to) return res.status(400).json({ error: "from and to are required" });

  const info = await sendViaGmail(mailbox, { from, to, subject, text, html, cc, bcc, attachments });
  res.status(202).json(info);
});

module.exports = router;
