const express = require("express");
const Mailbox = require("../models/Mailbox");
const Message = require("../models/Message");
const { getImapClient } = require("../imap/client");
const { sendViaGmail } = require("../smtp/send");
const { simpleParser } = require("mailparser");

const router = express.Router();

// Mark read/unread or add/remove flags
// body: { add: ["\\Seen"], remove: ["\\Flagged"] } OR { seen: true|false }
router.post("/:mailboxId/:messageId/flags", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const m = await Message.findById(req.params.messageId);
  if (!m) return res.status(404).json({ error: "Message not found" });

  const { client } = await getImapClient(mailbox);
  try {
    await client.mailboxOpen(m.folderPath);
    const seq = { uid: m.uid };

    if (typeof req.body.seen === "boolean") {
      if (req.body.seen) await client.messageFlagsAdd(seq, ["\\Seen"]);
      else await client.messageFlagsRemove(seq, ["\\Seen"]);
    }
    if (Array.isArray(req.body.add) && req.body.add.length) {
      await client.messageFlagsAdd(seq, req.body.add);
    }
    if (Array.isArray(req.body.remove) && req.body.remove.length) {
      await client.messageFlagsRemove(seq, req.body.remove);
    }

    res.json({ ok: true });
  } finally { await client.logout(); }
});

// Move to another folder
// body: { to: "Archive" }
router.post("/:mailboxId/:messageId/move", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const m = await Message.findById(req.params.messageId);
  if (!m) return res.status(404).json({ error: "Message not found" });

  const { to } = req.body;
  if (!to) return res.status(400).json({ error: "to required" });

  const { client } = await getImapClient(mailbox);
  try {
    await client.mailboxOpen(m.folderPath);
    await client.messageMove({ uid: m.uid }, to);
    res.json({ ok: true });
  } finally { await client.logout(); }
});

// Copy to another folder
router.post("/:mailboxId/:messageId/copy", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const m = await Message.findById(req.params.messageId);
  if (!m) return res.status(404).json({ error: "Message not found" });

  const { to } = req.body;
  if (!to) return res.status(400).json({ error: "to required" });

  const { client } = await getImapClient(mailbox);
  try {
    await client.mailboxOpen(m.folderPath);
    await client.messageCopy({ uid: m.uid }, to);
    res.json({ ok: true });
  } finally { await client.logout(); }
});

// Delete (move to Trash for Gmail) or hard-expunge
// body: { hard?: true }  (danger!)
router.delete("/:mailboxId/:messageId", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const m = await Message.findById(req.params.messageId);
  if (!m) return res.status(404).json({ error: "Message not found" });

  const { hard } = req.body || {};

  const { client } = await getImapClient(mailbox);
  try {
    if (hard) {
      await client.mailboxOpen(m.folderPath);
      await client.messageDelete({ uid: m.uid }); // flags \Deleted + expunge for Gmail
    } else {
      // Gmail "Trash" path can vary; this works on English accounts
      await client.messageMove({ uid: m.uid }, "[Gmail]/Trash");
    }
    res.json({ ok: true });
  } finally { await client.logout(); }
});

// Expunge by UID(s) in a folder (danger)
// body: { folder:"INBOX", uids:[123,124] }
router.post("/:mailboxId/expunge", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const { folder, uids } = req.body || {};
  if (!folder || !Array.isArray(uids) || !uids.length) {
    return res.status(400).json({ error: "folder and uids[] required" });
  }

  const { client } = await getImapClient(mailbox);
  try {
    await client.mailboxOpen(folder);
    for (const uid of uids) await client.messageDelete({ uid });
    res.json({ ok: true });
  } finally { await client.logout(); }
});

// Save Draft (APPEND to Drafts)
router.post("/:mailboxId/draft", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const { raw, subject, from, to, text, html } = req.body;
  const { client } = await getImapClient(mailbox);
  try {
    await client.append("[Gmail]/Drafts",
      raw || buildRaw({ from, to, subject, text, html }),
      { flags: ["\\Draft"], internalDate: new Date() }
    );
    res.json({ ok: true });
  } finally { await client.logout(); }
});

// Reply
// body: { text?, html? }
router.post("/:mailboxId/:messageId/reply", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const m = await Message.findById(req.params.messageId);
  if (!m) return res.status(404).json({ error: "Message not found" });

  const replyTo = m.fromAddr;
  const subject = m.subject?.startsWith("Re:") ? m.subject : `Re: ${m.subject || ""}`;
  const refs = []; // if you store References/Message-ID, append here

  const info = await sendViaGmail(mailbox, {
    from: mailbox.email,
    to: replyTo,
    subject,
    text: req.body.text || `On ${m.date?.toISOString() || ""}, ${m.fromAddr} wrote:\n\n${m.textBody || ""}`,
    html: req.body.html || undefined,
    headers: {
      "In-Reply-To": m.msgId || undefined,
      "References": [m.msgId, ...refs].filter(Boolean).join(" ")
    }
  });

  res.json(info);
});

// Forward
// body: { to: "target@example.com", text?, html? }
router.post("/:mailboxId/:messageId/forward", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const m = await Message.findById(req.params.messageId);
  if (!m) return res.status(404).json({ error: "Message not found" });

  const { to, text, html } = req.body;
  if (!to) return res.status(400).json({ error: "to required" });

  const subject = m.subject?.startsWith("Fwd:") ? m.subject : `Fwd: ${m.subject || ""}`;

  const info = await sendViaGmail(mailbox, {
    from: mailbox.email,
    to,
    subject,
    text: text || (`---------- Forwarded message ---------\nFrom: ${m.fromAddr}\nSubject: ${m.subject}\nDate: ${m.date}\n\n${m.textBody || ""}`),
    html: html || m.htmlBody || undefined
  });

  res.json(info);
});

// Build a minimal raw rfc822 if you want to append drafts without nodemailer
function buildRaw({ from, to, subject, text, html }) {
  const date = new Date().toUTCString();
  const boundary = "b1_" + Math.random().toString(36).slice(2);
  if (html) {
    return [
      `From: ${from}`,
      `To: ${Array.isArray(to) ? to.join(", ") : to}`,
      `Subject: ${subject || ""}`,
      `Date: ${date}`,
      "MIME-Version: 1.0",
      `Content-Type: multipart/alternative; boundary="${boundary}"`,
      "",
      `--${boundary}`,
      "Content-Type: text/plain; charset=UTF-8",
      "",
      text || "",
      `--${boundary}`,
      "Content-Type: text/html; charset=UTF-8",
      "",
      html,
      `--${boundary}--`,
      ""
    ].join("\r\n");
  }
  return [
    `From: ${from}`,
    `To: ${Array.isArray(to) ? to.join(", ") : to}`,
    `Subject: ${subject || ""}`,
    `Date: ${date}`,
    "MIME-Version: 1.0",
    "Content-Type: text/plain; charset=UTF-8",
    "",
    text || "",
    ""
  ].join("\r\n");
}

module.exports = router;
