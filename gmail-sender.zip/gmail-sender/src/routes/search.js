const express = require("express");
const Mailbox = require("../models/Mailbox");
const { getImapClient } = require("../imap/client");

const router = express.Router();

// Basic IMAP search (subject/from/unseen/since)
// /api/search/basic/:mailboxId?folder=INBOX&subject=foo&from=bar&unseen=true&since=2025-11-01
router.get("/basic/:mailboxId", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const { folder = "INBOX", subject, from, unseen, since } = req.query;
  const criteria = ["ALL"];
  if (subject) criteria.push(["HEADER", "SUBJECT", String(subject)]);
  if (from)    criteria.push(["HEADER", "FROM", String(from)]);
  if (unseen === "true") criteria.push("UNSEEN");
  if (since) criteria.push(["SINCE", new Date(String(since))]);

  const { client } = await getImapClient(mailbox);
  try {
    await client.mailboxOpen(String(folder));
    const uids = await client.search({ criteria });
    res.json({ uids });
  } finally { await client.logout(); }
});

// Gmail RAW search (X-GM-RAW)
// /api/search/raw/:mailboxId?folder=INBOX&q=from:abc has:attachment newer_than:7d
router.get("/raw/:mailboxId", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const { folder = "INBOX", q = "" } = req.query;
  const { client } = await getImapClient(mailbox);
  try {
    await client.mailboxOpen(String(folder));
    const uids = await client.search({ criteria: [["X-GM-RAW", String(q)]] });
    res.json({ uids });
  } finally { await client.logout(); }
});

module.exports = router;
