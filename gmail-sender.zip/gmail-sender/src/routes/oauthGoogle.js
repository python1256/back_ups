const express = require("express");
const { OAuth2Client } = require("google-auth-library");
const Mailbox = require("../models/Mailbox");

const router = express.Router();

function getClient() {
  return new OAuth2Client(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
}

// GET /oauth/google?email=you@gmail.com
router.get("/", (req, res) => {
  const email = String(req.query.email || "");
  if (!email) return res.status(400).send("Provide ?email=you@gmail.com");

  const client = getClient();
  const url = client.generateAuthUrl({
    access_type: "offline",
    prompt: "consent",
    scope: ["https://mail.google.com/"],
    login_hint: email
  });

  res.cookie("pending_email", email, { httpOnly: true });
  return res.redirect(url);
});

// GET /oauth/google/callback?code=...
router.get("/callback", async (req, res) => {
  const code = String(req.query.code || "");
  if (!code) return res.status(400).send("Missing code");

  const client = getClient();
  const { tokens } = await client.getToken(code);

  const refresh = tokens.refresh_token;
  const access = tokens.access_token;
  const expiry = tokens.expiry_date ? Math.floor(tokens.expiry_date / 1000) : undefined;

  if (!refresh) {
    return res
      .status(400)
      .send("No refresh_token returned. Re-run with prompt=consent or revoke the app and try again.");
  }

  const email = (req.cookies && req.cookies.pending_email) || "unknown@unknown";
  const mailbox = await Mailbox.findOneAndUpdate(
    { email },
    { provider: "gmail", refreshToken: refresh, accessToken: access, accessTokenExp: expiry },
    { upsert: true, new: true }
  );

  return res.send(`<h2>✅ Connected ${mailbox.email}</h2><p>Refresh token saved.</p>`);
});

module.exports = router;
