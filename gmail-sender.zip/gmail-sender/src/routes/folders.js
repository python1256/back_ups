const express = require("express");
const Mailbox = require("../models/Mailbox");
const Folder = require("../models/Folder");
const { getImapClient, toNum } = require("../imap/client");

const router = express.Router();

// Create folder
router.post("/:mailboxId/create", async (req, res) => {
  const { path } = req.body;
  if (!path) return res.status(400).json({ error: "path required" });

  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const { client } = await getImapClient(mailbox);
  try {
    await client.mailboxCreate(path);
    const info = await client.mailboxOpen(path);
    await Folder.findOneAndUpdate(
      { mailboxId: mailbox._id, path },
      { uidValidity: toNum(info.uidValidity) },
      { upsert: true }
    );
    res.json({ ok: true });
  } finally { await client.logout(); }
});

// Rename folder
router.post("/:mailboxId/rename", async (req, res) => {
  const { from, to } = req.body;
  if (!from || !to) return res.status(400).json({ error: "from and to required" });

  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const { client } = await getImapClient(mailbox);
  try {
    await client.mailboxRename(from, to);
    await Folder.deleteOne({ mailboxId: mailbox._id, path: from });
    res.json({ ok: true });
  } finally { await client.logout(); }
});

// Delete folder
router.delete("/:mailboxId/:path", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const path = decodeURIComponent(req.params.path);
  const { client } = await getImapClient(mailbox);
  try {
    await client.mailboxDelete(path);
    await Folder.deleteOne({ mailboxId: mailbox._id, path });
    res.json({ ok: true });
  } finally { await client.logout(); }
});

// Subscribe / Unsubscribe
router.post("/:mailboxId/:path/subscribe", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const path = decodeURIComponent(req.params.path);
  const { on } = req.body; // boolean
  const { client } = await getImapClient(mailbox);
  try {
    if (on) await client.subscribeMailbox(path);
    else await client.unsubscribeMailbox(path);
    res.json({ ok: true });
  } finally { await client.logout(); }
});

// List folders (server-side live)
router.get("/:mailboxId", async (req, res) => {
  const mailbox = await Mailbox.findById(req.params.mailboxId);
  if (!mailbox) return res.status(404).json({ error: "Mailbox not found" });

  const { client } = await getImapClient(mailbox);
  try {
    const out = [];
    for await (const box of client.list()) out.push({ path: box.path, specialUse: box.specialUse });
    res.json(out);
  } finally { await client.logout(); }
});

module.exports = router;
