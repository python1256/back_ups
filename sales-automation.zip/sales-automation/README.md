# LinkedIn Sales Navigator Scraper Extension

The **LinkedIn Sales Navigator Scraper** is a Chrome extension designed to automate the process of extracting LinkedIn profile data and generating personalized business outreach.

---

## 🧩 Key Features

- Extracts profile data such as:
  - Name, Bio/About, Education, Interests, Skills, Location, Experience
  - Recent posts and activities
- Analyzes profile information in conjunction with Aspire SoftServ's business summary
- Identifies shared interests and potential areas of collaboration
- Uses Gemini (LLM) to generate:
  - Personalized, professional business emails
  - Tailored LinkedIn connection requests based on profile context

---

## 🎯 Purpose

This tool eliminates the manual effort involved in browsing profiles and crafting messages. It accelerates lead engagement by:

- Automatically collecting relevant data
- Analyzing client compatibility
- Generating high-quality emails and requests to foster connections and explore synergy

---

## 🛠️ Installation Guide

Follow these steps to install the extension manually in your Chrome browser:

1. **Download the Extension**  
   Navigate to:  
   `https://yourdomain.com/download-extension` *(replace with actual URL)*  
   The extension will be downloaded as a `.zip` file.

2. **Extract the Contents**  
   Unzip the downloaded file to a local folder.

3. **Open Chrome Extensions Page**  
   - Open Chrome browser  
   - Click the three-dot menu in the top-right corner  
   - Go to `Extensions → Manage Extensions`

4. **Enable Developer Mode**  
   Toggle **Developer mode** to **ON** (top-right corner)

5. **Load the Unpacked Extension**  
   - Click on **Load unpacked**  
   - Navigate to the extracted folder:  
     `chrome-extension → extension → [select folder with manifest.json]`

6. **Complete Installation**  
   Once loaded, the extension will appear in your Chrome extension list.

✅ You have now successfully installed the extension.  
👉 Now, follow the **Usage Guide** to start scraping profiles and generating outreach content.

---

## 📖 Usage Guide

1. **Log in to LinkedIn Sales Navigator**  
   Manually log in to your LinkedIn Sales Navigator account in your browser.

2. **Search for Target Profiles**  
   Use the search bar to find profiles you're interested in.

3. **Open Profile in a New Tab**  
   Click on a profile to open it in a **new browser tab**.  
   ⚠️ *This step is required for the extension to function properly.*

4. **Launch the Extension**  
   Click on the extension icon in your browser toolbar.

5. **Wait for the UI to Render**  
   Wait for the extension interface to load completely.

6. **Click on "Get URL"**  
   This will fetch the URL of the currently open profile.

7. **Allow Time for Processing**  
   The scraper will now:
   - Extract profile information (e.g., name, bio, education, experience, skills)
   - Analyze the profile and Aspire SoftServ's data
   - Generate a personalized business email and connection request

8. **Review the Output**  
   The extension will display the generated content, ready for copying or export.
