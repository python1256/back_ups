// src/utils/withAuth.jsx
import React, { useEffect, useState } from 'react';
import axiosInstance from './axiosInstance';
import LoginPage from '@/components/login/login-page';

// Helper function to get access token
const getAccessToken = async () => {
  if (typeof chrome !== 'undefined' && chrome.storage?.local) {
    return new Promise((resolve) => {
      chrome.storage.local.get('access_token', (res) =>
        resolve(res.access_token)
      );
    });
  } else {
    return localStorage.getItem('access_token');
  }
};

const withAuth = (WrappedComponent) => {
  return (props) => {
    const [isVerified, setIsVerified] = useState(null);

    useEffect(() => {
      const verifyUser = async () => {
        try {
          const access_token = await getAccessToken();

          if (!access_token) {
            setIsVerified(false);
            return;
          }

          await axiosInstance.get('/me', {
            headers: { Authorization: `Bearer ${access_token}` },
          });

          setIsVerified(true);
        } catch {
          setIsVerified(false);
        }
      };

      verifyUser();
    }, []);

    if (isVerified === null) return <div>Loading...</div>;
    if (!isVerified)
      return (
        <LoginPage {...props} onLoginSuccess={() => setIsVerified(true)} />
      );

    return <WrappedComponent {...props} />;
  };
};

export default withAuth;
