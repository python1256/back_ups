import axios from 'axios';

// Create instance
const axiosInstance = axios.create({
  baseURL: 'http://localhost:8000', // change to your API base URL
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor: attach token
axiosInstance.interceptors.request.use(
  async (config) => {
    // Attach token from chrome.storage (async)
    if (typeof chrome !== 'undefined' && chrome.storage?.local) {
      const token = await new Promise((resolve) =>
        chrome.storage.local.get('access_token', (res) =>
          resolve(res.access_token)
        )
      );
      if (token) config.headers.Authorization = `Bearer ${token}`;
    } else {
      const token = localStorage.getItem('access_token');
      if (token) config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Helper: get token (access or refresh)
const getToken = async (key) => {
  if (typeof chrome !== 'undefined' && chrome.storage?.local) {
    return new Promise((resolve) =>
      chrome.storage.local.get(key, (res) => resolve(res[key]))
    );
  } else {
    return localStorage.getItem(key);
  }
};

// Helper: set token
const setToken = async (key, value) => {
  if (typeof chrome !== 'undefined' && chrome.storage?.local) {
    chrome.storage.local.set({ [key]: value });
  } else {
    localStorage.setItem(key, value);
  }
};

// Helper: remove tokens
const clearTokens = async () => {
  if (typeof chrome !== 'undefined' && chrome.storage?.local) {
    chrome.storage.local.remove(['access_token', 'refresh_token']);
  } else {
    localStorage.removeItem('access_token');
    localStorage.removeItem('refresh_token');
  }
};

// Helper: refresh token
const refreshAccessToken = async (refresh_token) => {
  const res = await axios.post('http://localhost:8000/refresh', {
    refresh_token,
  });
  const newAccessToken = res.data.access_token;
  await setToken('access_token', newAccessToken);
  return newAccessToken;
};

// Response interceptor
axiosInstance.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const refresh_token = await getToken('refresh_token');
        if (!refresh_token) throw new Error('No refresh token available');

        const newAccessToken = await refreshAccessToken(refresh_token);
        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
        return axiosInstance(originalRequest);
      } catch (refreshError) {
        console.error('Token refresh failed:', refreshError);
        await clearTokens();
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);
export default axiosInstance;
