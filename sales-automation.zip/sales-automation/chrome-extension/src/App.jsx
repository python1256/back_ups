import './styles/App.css';
import { useEffect, useState } from 'react';
import GetCurrentUrl from './components/scrap';
import LoginPage from './components/login/login-page';
import axiosInstance from './utils/axiosInstance';

// Helper to get token from Chrome storage
const getChromeToken = (key) =>
  new Promise((resolve) => {
    chrome.storage.local.get([key], (result) => resolve(result[key]));
  });

// Helper to verify token
const verifyToken = async () => {
  const refreshToken = await getChromeToken('refresh_token');

  if (!refreshToken) return false;

  try {
    const res = await axiosInstance.get('/me', {
      headers: {
        Authorization: `Bearer ${refreshToken}`,
        'Content-Type': 'application/json',
      },
    });
    return res.status === 200;
  } catch (err) {
    console.error('Verify token failed', err.message);
    return false;
  }
};

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(null);

  useEffect(() => {
    const checkAuth = async () => {
      const verified = await verifyToken();
      setIsAuthenticated(verified);
      if (verified) console.log('Is authenticated: true');
    };

    checkAuth();
  }, []);

  if (isAuthenticated === null) return <div>Loading...</div>;

  return isAuthenticated ? (
    <GetCurrentUrl />
  ) : (
    <LoginPage onLoginSuccess={() => setIsAuthenticated(true)} />
  );
}

export default App;
