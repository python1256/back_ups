import React from 'react';
import PropTypes from 'prop-types';
import { Link, WandSparklesIcon } from 'lucide-react';

const UrlDisplay = ({ url, isLoading, onClick }) => {
  return (
    <div className="url-display-card">
      {/* Header with icon, title, and button in one row */}
      <div className="url-header">
        <Link size={20} className="url-header-icon text-blue-600" />
        <h3 className="text-md font-semibold text-gray-800">Current Page</h3>

        <div
          className={`transition-opacity duration-300 ${
            isLoading ? 'opacity-0 pointer-events-none' : 'opacity-100'
          }`}
        >
          <button
            onClick={onClick}
            disabled={isLoading}
            className="action-button w-auto text-sm"
          >
            Get Data
          </button>
        </div>
      </div>

      {/* URL or Loading */}
      {isLoading ? (
        <div className="loading-state flex items-center gap-2 text-gray-500">
          <span className="loading-text">
            Fetching URL <WandSparklesIcon size={20} className="wand-magic" />
          </span>
        </div>
      ) : (
        <div className="url-text text-blue-600 font-medium break-words">
          {url || 'URL will appear here after clicking "Get Data".'}
        </div>
      )}
    </div>
  );
};

// ----------------- PropTypes -----------------
UrlDisplay.propTypes = {
  url: PropTypes.string,
  isLoading: PropTypes.bool,
  onClick: PropTypes.func.isRequired,
};

// Default props if not provided
UrlDisplay.defaultProps = {
  url: '',
  isLoading: false,
};

export default UrlDisplay;
