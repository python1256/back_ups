import React, { useState, useEffect } from 'react';
import Card from '../ui/card';
import Button from '../ui/button';
import { Loader2, Sparkles, SlidersHorizontal } from 'lucide-react';
import axiosInstance from '@/utils/axiosInstance';
import withAuth from '../../utils/withAuth';
import Select from 'react-select';
import { motion } from 'framer-motion';
import PropTypes from 'prop-types';
// Helper to get access token from Chrome storage
const getAccessToken = async () =>
  new Promise((resolve) => {
    chrome.storage.local.get('access_token', (result) =>
      resolve(result.access_token)
    );
  });
const CustomizeContent = ({ onGenerateContent }) => {
  const [selectedTone, setSelectedTone] = useState('professional');
  const [isGenerating, setIsGenerating] = useState(false);

  const [valueProps, setValueProps] = useState([]);
  const [writingStyles, setWritingStyles] = useState([]);
  const [salesAssets, setSalesAssets] = useState([]);

  const [selectedValueProps, setSelectedValueProps] = useState([]);
  const [selectedWritingStyle, setSelectedWritingStyle] = useState([]);
  const [selectedSalesAsset, setSelectedSalesAsset] = useState(null);
  const [contentType, setContentType] = useState('email');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const access_token = await getAccessToken();

        if (!access_token) {
          console.warn('No access token found. Please login.');
          return;
        }

        const config = { headers: { Authorization: `Bearer ${access_token}` } };

        const [vpRes, wsRes, saRes] = await Promise.all([
          axiosInstance.get('/value-propositions/', config),
          axiosInstance.get('/writing-styles/', config),
          axiosInstance.get('/sales-assets/', config),
        ]);

        setValueProps(vpRes.data?.data || []);
        setWritingStyles(wsRes.data?.data || []);
        setSalesAssets(saRes.data?.data || []);
      } catch (error) {
        console.error('Error fetching customization data:', error);
      }
    };

    fetchData();
  }, []);

  const handleGenerate = async () => {
    if (!onGenerateContent) return;
    setIsGenerating(true);
    await onGenerateContent({
      tone: selectedTone,
      valueProposition: selectedValueProps,
      writingStyle: selectedWritingStyle,
      salesAsset: selectedSalesAsset,
      type: contentType,
    });
    setIsGenerating(false);
  };

  // ✨ Custom react-select styles
  const customSelectStyles = {
    control: (provided) => ({
      ...provided,
      borderRadius: '1rem',
      borderColor: '#E5E7EB',
      boxShadow: 'none',
      backgroundColor: 'white',
      padding: '4px 6px',
      '&:hover': { borderColor: '#60A5FA' },
    }),
    multiValue: (provided) => ({
      ...provided,
      backgroundColor: '#DBEAFE',
      borderRadius: '0.5rem',
      padding: '0 2px',
    }),
    multiValueLabel: (provided) => ({
      ...provided,
      color: '#1E40AF',
      fontWeight: 500,
    }),
    placeholder: (provided) => ({
      ...provided,
      color: '#9CA3AF',
    }),
  };

  const selectClass =
    'w-full border border-gray-200 rounded-2xl px-3 py-2 text-sm shadow-sm bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-150 ease-in-out hover:border-blue-300';

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      <Card className="p-8 bg-gradient-to-br from-white via-blue-50 to-indigo-50 rounded-3xl shadow-xl border border-gray-100 space-y-10">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center gap-2 text-blue-600">
            <SlidersHorizontal size={18} />
            <span className="font-semibold text-sm tracking-wider uppercase">
              AI Customization
            </span>
          </div>
          <h2 className="text-3xl font-bold text-gray-900">
            Customize Your Content
          </h2>
          <p className="text-sm text-gray-600 max-w-md mx-auto leading-relaxed">
            Adjust tone, focus areas, and style preferences to tailor your
            AI-generated content.
          </p>
        </div>

        {/* Grid Inputs */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Tone */}
          <div className="flex flex-col space-y-2">
            <label
              htmlFor="tone"
              className="text-sm font-semibold text-gray-700"
            >
              Tone
            </label>
            <select
              id="tone"
              className={selectClass}
              value={selectedTone}
              onChange={(e) => setSelectedTone(e.target.value)}
            >
              <option value="professional">Professional</option>
              <option value="casual">Casual</option>
              <option value="enthusiastic">Enthusiastic</option>
              <option value="empathetic">Empathetic</option>
            </select>
          </div>

          {/* Value Proposition */}
          <div className="flex flex-col space-y-2">
            <label htmlFor="vp" className="text-sm font-semibold text-gray-700">
              Value Proposition
            </label>
            <Select
              id="vp"
              isMulti
              options={valueProps.map((v) => ({
                value: v,
                label: v.persona || v.description || 'Unnamed Value',
              }))}
              value={selectedValueProps.map((v) => ({
                value: v,
                label: v.persona || v.description || 'Unnamed Value',
              }))}
              onChange={(selected) =>
                setSelectedValueProps(selected.map((s) => s.value))
              }
              styles={customSelectStyles}
              placeholder="Select Value Propositions..."
            />
          </div>

          {/* Writing Style */}
          <div className="flex flex-col space-y-2">
            <label htmlFor="ws" className="text-sm font-semibold text-gray-700">
              Writing Style
            </label>
            <Select
              id="ws"
              isMulti
              options={writingStyles.map((w) => ({
                value: w,
                label: w.style || w.tone || 'Unnamed Style',
              }))}
              value={selectedWritingStyle.map((w) => ({
                value: w,
                label: w.style || w.tone || 'Unnamed Style',
              }))}
              onChange={(selected) =>
                setSelectedWritingStyle(selected.map((s) => s.value))
              }
              styles={customSelectStyles}
              placeholder="Select Writing Styles..."
            />
          </div>

          {/* Sales Asset */}
          <div className="flex flex-col space-y-2">
            <label htmlFor="sa" className="text-sm font-semibold text-gray-700">
              Sales Asset
            </label>
            <select
              id="sa"
              className={selectClass}
              value={selectedSalesAsset?._id || ''}
              onChange={(e) => {
                const obj = salesAssets.find((s) => s._id === e.target.value);
                setSelectedSalesAsset(obj || null);
              }}
            >
              <option value="">Select Sales Asset</option>
              {salesAssets.map((s) => (
                <option key={s._id} value={s._id}>
                  {s.name || s.content || 'Unnamed Asset'}
                </option>
              ))}
            </select>
          </div>

          {/* Content Type */}
          <div className="flex flex-col space-y-2">
            <label htmlFor="ct" className="text-sm font-semibold text-gray-700">
              Content Type
            </label>
            <select
              id="ct"
              className={selectClass}
              value={contentType}
              onChange={(e) => setContentType(e.target.value)}
            >
              <option value="email">Email</option>
              <option value="sms">SMS</option>
              <option value="whatsapp">WhatsApp Message</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>

        {/* Generate Button */}
        <div className="pt-4">
          <Button
            onClick={handleGenerate}
            disabled={isGenerating}
            className={`w-full py-3 font-semibold text-base rounded-2xl flex items-center justify-center gap-2 transition-all duration-200 shadow-lg ${
              isGenerating
                ? 'bg-blue-300 text-gray-800 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:from-blue-700 hover:to-indigo-700 active:scale-[0.98]'
            }`}
          >
            {isGenerating ? (
              <>
                <Loader2 className="animate-spin" size={18} strokeWidth={1.5} />
                Generating...
              </>
            ) : (
              <>
                <Sparkles size={18} strokeWidth={1.5} />
                Generate Content
              </>
            )}
          </Button>
        </div>
      </Card>
    </motion.div>
  );
};
CustomizeContent.propTypes = {
  onGenerateContent: PropTypes.func.isRequired,
};

export default withAuth(CustomizeContent);
