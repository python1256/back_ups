import React, { useEffect, useState } from 'react';
import Card from '../ui/card';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import CopyIconButton from '../ui/copy';
import { Loader } from 'lucide-react';
import withAuth from '../../utils/withAuth';
import PropTypes from 'prop-types';
const ContentView = ({ generatedContent, isLoading = false }) => {
  const [isTimeout, setIsTimeout] = useState(false);

  let contentArray = [];

  if (Array.isArray(generatedContent)) {
    contentArray = generatedContent;
  } else if (generatedContent) {
    contentArray = [generatedContent];
  }
  const hashKey = (obj) => {
    return btoa(JSON.stringify(obj)).substring(0, 12);
  };
  useEffect(() => {
    if (isLoading) {
      setIsTimeout(false);
      const timer = setTimeout(() => setIsTimeout(true), 60000);
      return () => clearTimeout(timer);
    }
    return () => setIsTimeout(false);
  }, [isLoading]);

  return (
    <div className="space-y-6">
      {/* Loading */}
      {isLoading && !isTimeout && (
        <div className="flex flex-col items-center justify-center py-16 bg-white rounded-xl shadow-md">
          <Loader
            className="animate-spin-slow"
            size={16}
            strokeWidth={1}
            absoluteStrokeWidth
            color="blue"
          />{' '}
          <p className="text-sm text-gray-700 font-medium mt-4">
            AI is crafting your content...
          </p>
          <p className="text-xs text-gray-500 mt-1">
            This may take up to a minute.
          </p>
        </div>
      )}

      {/* Timeout */}
      {isTimeout && (
        <div className="bg-red-50 border border-red-300 p-5 rounded-xl shadow-md flex items-center space-x-3">
          <span className="text-red-500 text-xl font-bold">🚨</span>
          <div>
            <p className="text-sm text-red-800 font-bold mb-0.5">
              Generation Timeout
            </p>
            <p className="text-xs text-red-700">
              The content generation took too long. Please adjust your
              parameters and try again.
            </p>
          </div>
        </div>
      )}

      {/* Empty */}
      {!isLoading && !isTimeout && contentArray.length === 0 && (
        <div className="bg-gray-50 border border-gray-200 p-6 rounded-xl text-center shadow-md flex flex-col items-center">
          <span className="text-2xl mb-2">📄</span>
          <p className="text-base text-gray-700 font-semibold mb-1">
            No Generated Content
          </p>
          <p className="text-sm text-gray-500">
            Head to the{' '}
            <span className="font-bold text-blue-600">Customize</span> tab to
            generate your personalized messages.
          </p>
        </div>
      )}

      {/* Content */}
      {!isLoading &&
        !isTimeout &&
        contentArray.map((item) => (
          <Card
            key={hashKey(item)}
            className="p-6 border border-gray-100 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:ring-2 hover:ring-blue-500/20"
          >
            <div className="mb-4 pb-2 border-b border-gray-100">
              <p className="text-xs font-semibold text-blue-600 uppercase tracking-wider mb-1">
                {item.title ? 'Subject' : 'Generated Message'}
              </p>
              <h4 className="text-xl font-bold text-gray-900">
                {item.title || 'Untitled Content'}
              </h4>
            </div>

            {/* Markdown Renderer */}
            <div className="prose prose-blue max-w-none text-gray-800 leading-relaxed">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>
                {item.content || item.text || 'No content available.'}
              </ReactMarkdown>
            </div>

            {/* Actions */}
            <CopyIconButton text={item.content} />
          </Card>
        ))}
    </div>
  );
};
ContentView.propTypes = {
  generatedContent: PropTypes.oneOfType([
    PropTypes.arrayOf(
      PropTypes.shape({
        title: PropTypes.string,
        content: PropTypes.string,
        text: PropTypes.string,
      })
    ),
    PropTypes.shape({
      title: PropTypes.string,
      content: PropTypes.string,
      text: PropTypes.string,
    }),
    PropTypes.string,
  ]),
  isLoading: PropTypes.bool,
};

export default withAuth(ContentView);
