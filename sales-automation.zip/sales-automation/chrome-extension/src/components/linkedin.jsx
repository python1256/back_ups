import React from 'react';
import PropTypes from 'prop-types';

import PortfolioCompanyLinkedIn from './profile/companyprotfolio';
import {
  PortfolioAbout,
  PortfolioCompanyInfo,
  PortfolioExperience,
  PortfolioHeader,
  PortfolioTags,
} from './profile/portfolioscore';

const LinkedInPortfolio = ({ data }) => {
  if (!data) return null;

  const {
    profile_data,
    contact_info,
    linkedin_company_url,
    company_data,
    score_data,
  } = data;
  if (!profile_data) return null;

  const {
    name,
    headline,
    location,
    about,
    experience,
    technical_tags,
    profile_tags,
  } = profile_data;

  return (
    <div className="p-6 bg-gray-50 min-h-screen font-sans">
      <PortfolioHeader
        name={name}
        headline={headline}
        location={location}
        linkedinProfile={contact_info?.linkedin_profile}
        score={score_data}
      />
      <PortfolioAbout overview={about?.overview} />
      <PortfolioCompanyInfo company={company_data} />
      <PortfolioExperience experience={experience} />
      <PortfolioCompanyLinkedIn linkedinCompanyUrl={linkedin_company_url} />
      <PortfolioTags
        title="Profile Tags"
        tags={profile_tags}
        bgColor="#e0f2fe"
        textColor="#0369a1"
      />
      <PortfolioTags
        title="Skills / Technical Tags"
        tags={technical_tags}
        bgColor="#d1fae5"
        textColor="#065f46"
      />
    </div>
  );
};

// ✅ Add prop validation
LinkedInPortfolio.propTypes = {
  data: PropTypes.shape({
    profile_data: PropTypes.shape({
      name: PropTypes.string,
      headline: PropTypes.string,
      location: PropTypes.string,
      about: PropTypes.object,
      experience: PropTypes.array,
      technical_tags: PropTypes.array,
      profile_tags: PropTypes.array,
    }),
    contact_info: PropTypes.object,
    linkedin_company_url: PropTypes.string,
    company_data: PropTypes.object,
    score_data: PropTypes.object,
  }),
};

export default LinkedInPortfolio;
