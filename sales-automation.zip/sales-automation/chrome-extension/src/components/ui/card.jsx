import React from 'react';
import PropTypes from 'prop-types';

const Card = ({ children }) => (
  <div
    style={{
      background: 'linear-gradient(145deg, #ffffff, #f0f4ff)', // soft gradient
      borderRadius: '16px',
      boxShadow:
        '0 8px 20px rgba(0,0,0,0.1), inset 0 0 5px rgba(255,255,255,0.2)', // soft shadow + inner glow
      padding: '20px',
      marginBottom: '20px',
      transition: 'transform 0.3s, box-shadow 0.3s',
      cursor: 'pointer',
    }}
    // onMouseEnter={(e) => {
    //   e.currentTarget.style.transform = 'translateY(-5px)';
    //   e.currentTarget.style.boxShadow =
    //     '0 12px 25px rgba(0,0,0,0.15), inset 0 0 8px rgba(255,255,255,0.3)';
    // }}
    // onMouseLeave={(e) => {
    //   e.currentTarget.style.transform = 'translateY(0)';
    //   e.currentTarget.style.boxShadow =
    //     '0 8px 20px rgba(0,0,0,0.1), inset 0 0 5px rgba(255,255,255,0.2)';
    // }}
  >
    {children}
  </div>
);

// ------------------ PropTypes ------------------
Card.propTypes = {
  children: PropTypes.node.isRequired,
};

export default Card;
