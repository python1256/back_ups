import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { Copy, Check } from 'lucide-react';

const CopyIconButton = ({ text }) => {
  const [isCopied, setIsCopied] = useState(false);

  const handleCopy = () => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 1000); // 1s blink
  };

  return (
    <div className="absolute top-2 right-2 flex items-center gap-1">
      <div className="relative">
        {isCopied ? (
          <Check
            size={14}
            className="text-green-500 transition-transform duration-300 scale-110"
          />
        ) : (
          <Copy
            size={14}
            onClick={handleCopy}
            className="cursor-pointer text-gray-500 hover:text-gray-700 transition-transform duration-200 hover:scale-110"
          />
        )}
      </div>
      {isCopied && (
        <span className="text-[6px] text-green-500 font-medium animate-fade">
          Copied
        </span>
      )}
    </div>
  );
};

// ------------------ PropTypes ------------------
CopyIconButton.propTypes = {
  text: PropTypes.string.isRequired,
};

export default CopyIconButton;
