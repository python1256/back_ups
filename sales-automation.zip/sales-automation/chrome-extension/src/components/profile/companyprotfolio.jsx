import React from 'react';
import PropTypes from 'prop-types';
import Card from '../ui/card';

const PortfolioCompanyLinkedIn = ({ linkedinCompanyUrl }) => {
  if (!linkedinCompanyUrl) return null;

  // Normalize URL
  const normalizedUrl = linkedinCompanyUrl.startsWith('http')
    ? linkedinCompanyUrl
    : `https://${linkedinCompanyUrl}`;

  return (
    <Card className="mb-4 p-4">
      <h3 className="font-semibold text-lg mb-2 text-gray-800">
        Company LinkedIn
      </h3>
      <a
        href={normalizedUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="text-blue-600 hover:text-blue-700 underline text-sm break-all"
      >
        {linkedinCompanyUrl}
      </a>
    </Card>
  );
};

PortfolioCompanyLinkedIn.propTypes = {
  linkedinCompanyUrl: PropTypes.string,
};

PortfolioCompanyLinkedIn.defaultProps = {
  linkedinCompanyUrl: '',
};

export default PortfolioCompanyLinkedIn;
