import React, { useRef, useState, useEffect } from 'react';
import { Newspaper } from 'lucide-react';
import PropTypes from 'prop-types';

const MAX_HEIGHT = 400;

const PostsCard = ({ postcontent = [] }) => {
  const contentRef = useRef(null);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isOverflowing, setIsOverflowing] = useState(false);

  // Filter out empty or invalid posts
  const filteredPosts = postcontent.filter(
    (item) => typeof item === 'string' && item.trim() !== ''
  );

  useEffect(() => {
    const el = contentRef.current;
    if (el) {
      setIsOverflowing(el.scrollHeight > MAX_HEIGHT);
    }
  }, [filteredPosts, isExpanded]);

  if (filteredPosts.length === 0) return null;

  return (
    <div className="display-container">
      <h3 className="component-header flex items-center">
        <Newspaper size={25} color="#3e56ee" />
        <span className="ml-2">Recent Activities</span>
      </h3>

      <div className="content-text">
        <ul
          ref={contentRef}
          className="post-list"
          style={{
            maxHeight: isExpanded ? 'none' : `${MAX_HEIGHT}px`,
            overflowY: isExpanded ? 'visible' : 'auto',
            paddingRight: isExpanded ? 0 : '4px',
            transition: 'max-height 0.3s ease',
          }}
        >
          {filteredPosts.map((item) => {
            const [firstPart, ...rest] = item.split(':');
            const secondPart = rest.join(':').trim();

            // Generate a unique key based on content
            const key = `${firstPart?.trim() ?? 'unknown'}-${
              secondPart?.slice(0, 20)?.replace(/\s+/g, '-') ?? ''
            }`;

            return (
              <li key={key} className="mt-2 list-item">
                <strong>{firstPart?.trim() ?? ''}:</strong> {secondPart || ''}
              </li>
            );
          })}
        </ul>

        {isOverflowing && (
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="show-more-btn mt-2 text-blue-600 hover:underline text-left"
          >
            {isExpanded ? 'Collapse' : 'Extend'}
          </button>
        )}
      </div>
    </div>
  );
};

PostsCard.propTypes = {
  postcontent: PropTypes.arrayOf(PropTypes.string),
};

export default PostsCard;
