import React from 'react';
import { GraduationCap } from 'lucide-react';
import PropTypes from 'prop-types';
const Education = ({ education = [] }) => {
  const filteredEducation = education.filter(
    (item) =>
      item &&
      typeof item === 'object' &&
      item.school?.trim() &&
      item.degree?.trim()
  );

  if (filteredEducation.length === 0) return null;

  return (
    <div className="display-container">
      <div className="component-header flex items-center">
        <GraduationCap size={25} color="#3e56ee" />
        <span className="ml-2">Education</span>
      </div>

      <ul className="content-text list space-y-2 mt-2">
        {filteredEducation.map((item) => (
          <li className="list-item" key={item.degree}>
            <p className="font-semibold text-[#3e56ee] m-0">{item.school}</p>
            <p className="m-0">
              {item.degree}
              {item.field ? ` — ${item.field}` : ''}
            </p>
            <p className="text-sm text-gray-500 m-0">{item.duration}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};
Education.propTypes = {
  education: PropTypes.array,
};
export default Education;
