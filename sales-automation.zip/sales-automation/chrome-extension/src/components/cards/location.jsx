import React from 'react';
import { MapPin } from 'lucide-react';
import PropTypes from 'prop-types';

const LocationCard = ({ location }) => {
  if (!location?.trim()) return null; // optional safeguard

  return (
    <div className="display-container">
      <div className="component-header">
        <MapPin color="#3e56ee" size={25} />
        <span>Location</span>
      </div>
      <span className="content-text">{location}</span>
    </div>
  );
};

LocationCard.propTypes = {
  location: PropTypes.string,
};

export default LocationCard;
