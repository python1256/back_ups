import React from 'react';
import { LucideClover } from 'lucide-react';
import PropTypes from 'prop-types';
const Interest = ({ interest = [] }) => {
  const filtered = interest.filter((item) => item.trim() !== '');
  if (filtered.length === 0) return null;

  return (
    <div className="display-container">
      <h3 className="component-header flex items-center">
        <LucideClover color="#3e56ee" size={25} />
        <span className="ml-2">Interests</span>
      </h3>
      <ul className="content-text list">
        {interest
          .filter((item) => item.trim() !== '')
          .map((item) => (
            <li key={item} className="list-item">
              {item}
            </li>
          ))}
      </ul>
    </div>
  );
};

Interest.propTypes = {
  interest: PropTypes.arrayOf(PropTypes.string),
};

export default Interest;
