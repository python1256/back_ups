import React, { useState } from 'react';
import { MailSearchIcon, Copy } from 'lucide-react';
import PropTypes from 'prop-types';

const EmailCard = ({ emailContent }) => {
  const [copied, setCopied] = useState(false);

  const copyText = async () => {
    try {
      await navigator.clipboard.writeText(emailContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      alert('Copy failed.');
    }
  };

  return (
    <div className="display-container">
      <h3 className="component-header flex items-center">
        <MailSearchIcon color="#3e56ee" size={25} />
        <span className="ml-2">Email</span>

        <div className="ml-auto flex items-center gap-2">
          {copied ? (
            <span className="text-green-600 text-sm font-medium">Copied!</span>
          ) : (
            <Copy
              onClick={copyText}
              className="cursor-pointer hover:text-blue-700"
              size={20}
              color="#3e56ee"
            />
          )}
        </div>
      </h3>

      <div className="content-text mt-2">
        <div className="email-content whitespace-pre-line break-words">
          {emailContent}
        </div>
      </div>
    </div>
  );
};

// ✅ Correct propTypes definition
EmailCard.propTypes = {
  emailContent: PropTypes.string.isRequired,
};

export default EmailCard;
