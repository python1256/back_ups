let popupWindowId = null;
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message?.action) return;

  if (message.action === 'openPopup' || message.action === 'updateTabInfo') {
    chrome.runtime.sendMessage({
      action: 'updateTabInfo',
      tabInfo: {
        id: sender.tab.id,
        url: message.currentUrl,
      },
    });
    chrome.storage.local.set(
      {
        sourceTabInfo: {
          id: sender.tab.id,
          url: message.currentUrl,
          windowId: sender.tab.windowId,
        },
      },
      () => {
        if (chrome.runtime.lastError) {
          console.error('Error storing tab info:', chrome.runtime.lastError);
        }
      }
    );

    if (popupWindowId) {
      chrome.windows.get(popupWindowId, (window) => {
        chrome.windows.update(popupWindowId, { focused: true });
      });
    }
  }

  return true;
});

function createPopup() {
  chrome.windows.create(
    {
      url: chrome.runtime.getURL('index.html'),
      type: 'popup',
      width: 400,
      height: 600,
      top: 100,
      left: 100,
    },
    (newWindow) => {
      popupWindowId = newWindow.id;
    }
  );
}

chrome.windows.onRemoved.addListener((windowId) => {
  if (windowId === popupWindowId) {
    popupWindowId = null;
  }
});
