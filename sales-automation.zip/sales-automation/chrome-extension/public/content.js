(function () {
  if (document.getElementById('floating-bubble')) return;
  let windowDiv = null;

  // Create the floating bubble (launcher)
  const bubble = document.createElement('div');
  bubble.id = 'floating-bubble';
  bubble.innerHTML = `
    <svg id="bubble-icon" viewBox="0 0 96 96" fill="none" xmlns="http://www.w3.org/2000/svg">
  <circle cx="48" cy="48" r="46" fill="url(#bgGradient)" stroke="white" stroke-width="2"/>

  <circle cx="48" cy="48" r="6" fill="white">
    <animate attributeName="r" values="5;6;5" dur="1.5s" repeatCount="indefinite" />
  </circle>

  <g transform="translate(48,48)" fill="white" opacity="0.95">
    <path d="M0,-28 Q2,-12 0,-6 Q-2,-12 0,-28Z"/>
    <path d="M0,28 Q2,12 0,6 Q-2,12 0,28Z"/>
    <path d="M28,0 Q12,2 6,0 Q12,-2 28,0Z"/>
    <path d="M-28,0 Q-12,2 -6,0 Q-12,-2 -28,0Z"/>

    <path d="M19.8,-19.8 Q8,-6 4,-4 Q6,-8 19.8,-19.8Z"/>
    <path d="M-19.8,-19.8 Q-8,-6 -4,-4 Q-6,-8 -19.8,-19.8Z"/>
    <path d="M19.8,19.8 Q8,6 4,4 Q6,8 19.8,19.8Z"/>
    <path d="M-19.8,19.8 Q-8,6 -4,4 Q-6,8 -19.8,19.8Z"/>
  </g>

  <circle cx="48" cy="48" r="20" fill="url(#glowGradient)" opacity="0.4" />

  <defs>
    <radialGradient id="bgGradient" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#0077B5"/>
      <stop offset="100%" stop-color="#004f7c"/>
    </radialGradient>
    <radialGradient id="glowGradient" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="white" stop-opacity="0.8"/>
      <stop offset="100%" stop-color="white" stop-opacity="0"/>
    </radialGradient>
  </defs>
</svg>

  `;
  document.body.appendChild(bubble);

  // Style for the bubble and floating window
  const style = document.createElement('style');
  style.innerHTML = `
    /* Floating Bubble Styles */
    #floating-bubble {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 50px;
      height: 50px;
      background: #007bff;
      color: white;
      display: flex;
      justify-content: center;
      align-items: center;
      border-radius: 50%;
      cursor: pointer;
      z-index: 9999;
      box-shadow: 0 4px 12px rgba(0,0,0,0.25);
      user-select: none;
      transition: transform 0.2s ease-out, opacity 0.2s ease-out;
    }

    #floating-bubble:hover {
      transform: translateY(-3px);
      box-shadow: 0 6px 16px rgba(0,0,0,0.3);
    }

    #floating-bubble:active {
      transform: scale(0.95);
    }

    #floating-bubble.disabled {
      opacity: 0;
      pointer-events: none;
      transform: scale(0.8);
    }

    #bubble-icon {
      width: 28px;
      height: 28px;
      fill: currentColor;
    }

    /* Custom Floating Window Styles */
    #custom-floating-window {
    position: fixed;
    width: 400px;
    height: 600px;
    max-width: 90vw;
    max-height: 85vh;
    background: linear-gradient(to bottom right, #fdfdfd, #ffffff);
    border: none;
    border-radius: 10px;
    box-shadow:
        0 4px 6px rgba(0, 0, 0, 0.1),
        0 10px 20px rgba(0, 0, 0, 0.15);
    z-index: 10000;
    display: flex;
    flex-direction: column;
    overflow: hidden;

    opacity: 0;
    transform: scale(0.2);
    transition: all 0.3s ease-out;
}

/* Class to trigger the "open" animation */
#custom-floating-window.is-open {
    opacity: 1;
    transform: scale(1);
}

    #window-header {
    height: 48px;
    background:rgb(207, 223, 240);
    color: #3c4043;
    padding: 0 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    cursor: grab;
    user-select: none;
    font-weight: 500;
    font-size: 16px;
    border-top-left-radius: 10px;
    border-top-right-radius: 10px;
    border-bottom: 1px solid #dadce0;
}

#window-header:active {
    cursor: grabbing;
}

#window-header .header-title {
    flex-grow: 1;
    text-overflow: ellipsis;
    white-space: nowrap;
    overflow: hidden;
    margin-right: 10px;
}

    #window-close {
    font-size: 24px;
    color: #5f6368;
    font-weight: normal;
    cursor: pointer;
    line-height: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    transition: background-color 0.2s ease-out, transform 0.2s ease-out;
}

    #window-close:hover {
    background-color: rgba(0, 0, 0, 0.08);
    color: #202124;
}

    #window-iframe {
    flex-grow: 1;
    border: none;
    width: 100%;
    height: 100%;
    background-color: transparent;
}

    /* Media Queries for Responsiveness */
    @media (max-width: 600px) {
      #custom-floating-window {
        right: 10px;
        bottom: 10px;
        width: calc(100vw - 20px);
        height: calc(100vh - 100px);
        max-width: none;
        max-height: none;
        border-radius: 8px;
    }
      #window-header {
        height: 40px;
        padding: 0 12px;
        font-size: 14px;
    }

      #floating-bubble {
        bottom: 10px;
        right: 10px;
        width: 45px;
        height: 45px;
      }
      #bubble-icon {
        width: 24px;
        height: 24px;
      }
        #window-close {
        font-size: 20px;
        width: 28px;
        height: 28px;
    }
    }
  `;
  document.head.appendChild(style);

  // Drag logic for the bubble
  let isBubbleDragging = false;
  let bubbleOffsetX, bubbleOffsetY;
  let wasDragged = false; // NEW FLAG

  bubble.addEventListener('mousedown', (event) => {
    if (!bubble.classList.contains('disabled')) {
      isBubbleDragging = true;
      wasDragged = false; // Reset wasDragged on every new mousedown
      bubbleOffsetX = event.clientX - bubble.getBoundingClientRect().left;
      bubbleOffsetY = event.clientY - bubble.getBoundingClientRect().top;
      bubble.style.cursor = 'grabbing';
      // Temporarily disable transitions during drag for smoother movement
      bubble.style.transition = 'none';
    }
  });

  document.addEventListener('mousemove', (event) => {
    if (!isBubbleDragging) return;

    // If mouse moves significantly while dragging, set wasDragged to true
    if (
      Math.abs(
        event.clientX - (bubble.getBoundingClientRect().left + bubbleOffsetX)
      ) > 5 || // Check horizontal movement
      Math.abs(
        event.clientY - (bubble.getBoundingClientRect().top + bubbleOffsetY)
      ) > 5
    ) {
      // Check vertical movement
      wasDragged = true;
    }

    const x = event.clientX - bubbleOffsetX;
    const y = event.clientY - bubbleOffsetY;

    // Constrain bubble to viewport
    const maxX = window.innerWidth - bubble.offsetWidth;
    const maxY = window.innerHeight - bubble.offsetHeight;

    bubble.style.left = `${Math.min(maxX, Math.max(0, x))}px`;
    bubble.style.top = `${Math.min(maxY, Math.max(0, y))}px`;
    bubble.style.right = 'auto'; // Ensure right/bottom are not overriding
    bubble.style.bottom = 'auto';
  });

  document.addEventListener('mouseup', () => {
    if (isBubbleDragging) {
      isBubbleDragging = false;
      // wasDragged is already set or not by mousemove
      bubble.style.cursor = 'pointer'; // Reset cursor
      // Re-enable transitions after drag
      bubble.style.transition =
        'transform 0.2s ease-out, opacity 0.2s ease-out';
    }
  });

  // On bubble click, open draggable window
  bubble.addEventListener('click', (event) => {
    event.stopPropagation();
    if (wasDragged) {
      return;
    }
    if (isBubbleDragging) return;

    chrome.runtime.sendMessage({
      action: 'openPopup',
      currentUrl: window.location.href,
    });

    if (document.getElementById('custom-floating-window')) {
      return;
    }

    bubble.classList.add('disabled');

    windowDiv = document.createElement('div');
    windowDiv.id = 'custom-floating-window';

    const header = document.createElement('div');
    header.id = 'window-header';
    header.innerHTML = `<span>Sales Automation AI</span><span id="window-close">&times;</span>`;

    const iframe = document.createElement('iframe');
    iframe.id = 'window-iframe';
    iframe.src = chrome.runtime.getURL('index.html');
    iframe.allow = 'clipboard-write';
    windowDiv.appendChild(header);
    windowDiv.appendChild(iframe);
    document.body.appendChild(windowDiv);

    const bubbleRect = bubble.getBoundingClientRect();
    const windowWidth = 400;
    const windowHeight = 600;
    let targetLeft = bubbleRect.left - (windowWidth - bubbleRect.width);
    let targetTop = bubbleRect.top - windowHeight - 10;

    if (targetLeft < 0) {
      targetLeft = 10;
    }

    if (targetTop < 0) {
      targetTop = 10;
    }

    if (targetLeft + windowWidth > window.innerWidth) {
      targetLeft = window.innerWidth - windowWidth - 10;
    }

    if (targetTop + windowHeight > window.innerHeight) {
      targetTop = window.innerHeight - windowHeight - 10;
    }

    windowDiv.style.left = `${targetLeft}px`;
    windowDiv.style.top = `${targetTop}px`;

    const originX = bubbleRect.right - targetLeft;
    const originY = bubbleRect.bottom - targetTop;
    windowDiv.style.transformOrigin = `${originX}px ${originY}px`;

    windowDiv.getBoundingClientRect();

    setTimeout(() => {
      windowDiv.classList.add('is-open');
    }, 50);

    header.querySelector('#window-close').onclick = () => {
      const currentWindowRect = windowDiv.getBoundingClientRect();
      const originX_close = bubbleRect.right - currentWindowRect.left;
      const originY_close = bubbleRect.bottom - currentWindowRect.top;
      windowDiv.style.transformOrigin = `${originX_close}px ${originY_close}px`;

      windowDiv.classList.remove('is-open');
      windowDiv.addEventListener('transitionend', function handler() {
        windowDiv.removeEventListener('transitionend', handler);
        if (!windowDiv.classList.contains('is-open')) {
          windowDiv.remove();
          bubble.classList.remove('disabled');
        }
      });
    };

    // Make window draggable
    let dragOffsetX,
      dragOffsetY,
      draggingWindow = false;

    header.addEventListener('mousedown', (e) => {
      draggingWindow = true;
      const rect = windowDiv.getBoundingClientRect();
      dragOffsetX = e.clientX - rect.left;
      dragOffsetY = e.clientY - rect.top;
      document.body.style.userSelect = 'none';
      document.body.style.cursor = 'grabbing';
      // Temporarily disable transitions on the window while dragging
      windowDiv.style.transition = 'none';
    });

    document.addEventListener('mousemove', (e) => {
      if (!draggingWindow) return;
      windowDiv.style.left = `${e.clientX - dragOffsetX}px`;
      windowDiv.style.top = `${e.clientY - dragOffsetY}px`;
      windowDiv.style.right = 'auto'; // Reset right/bottom
      windowDiv.style.bottom = 'auto';
    });

    document.addEventListener('mouseup', () => {
      if (draggingWindow) {
        draggingWindow = false;
        document.body.style.userSelect = '';
        document.body.style.cursor = '';
        windowDiv.style.transition = 'all 0.3s ease-out';
      }
    });

    // Mutation observer for SPA navigation
  });
  let lastUrl = location.href;
  new MutationObserver(() => {
    const currentUrl = location.href;
    if (currentUrl !== lastUrl) {
      lastUrl = currentUrl;
      chrome.runtime.sendMessage({
        action: 'updateTabInfo',
        currentUrl: window.location.href,
      });
    }
  }).observe(document, { subtree: true, childList: true });
})();
