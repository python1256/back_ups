import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import * as path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    cors: true,
    headers: {
      'X-Frame-Options': 'ALLOWALL',
      'Content-Security-Policy':
        'frame-ancestors https: http: chrome-extension://*;',
    },
    allowedHosts: [
      '.ngrok-free.app',
      'localhost',
      '127.0.0.1',
      '.aspiresoftware.in',
      '48424afdb62c.ngrok-free.app',
    ],
  },
  build: {
    outDir: '../webscrapper/extension',
    rollupOptions: {
      input: {
        main: 'index.html',
      },
      output: {
        entryFileNames: 'assets/[name].js',
        chunkFileNames: 'assets/[name].js',
        assetFileNames: 'assets/[name].[ext]',
      },
    },
  },
});
