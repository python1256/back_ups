import gc
import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict

import html2text
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from ....core.selenium_session import SeleniumManager
from ....database.mongo_database import MongoDBConnection
from ....database.profile_data_schema import Company, ProfileScraping
from ...utils.load_env import environment
from ...utils.log import logger
from .content_generator import AIGenerator
from .score_service import AIScoreGenerator


class AIScraper:
    """
    Scraper that uses Selenium to extract page content,
    process insights with AI, and store results in MongoDB.
    """

    def __init__(self):
        self.manager = SeleniumManager()
        self.ai_generator = AIGenerator()
        self.text_transformer = html2text.HTML2Text()

        self.db_conn = MongoDBConnection(host=environment.MONGO_HOST)

    def _scroll_to_bottom(
        self, session: webdriver.Chrome, pause_time: float = 0.5, max_scrolls: int = 1
    ) -> None:
        """Scroll page to bottom multiple times to load dynamic content."""
        try:
            for scroll_count in range(max_scrolls):
                logger.debug(f"Scrolling... ({scroll_count + 1}/{max_scrolls})")
                session.execute_script(
                    """
                    let scroll = document.getElementsByTagName("body")[0];
                    scroll.scrollTop = document.body.scrollHeight;
                    """
                )
                time.sleep(pause_time)
            logger.debug("Finished scrolling")
        except Exception as e:
            logger.error(f"Error while scrolling >> {e}")

    def _multi_surf(
        self, session: webdriver.Chrome, raw_url_dict: Dict[str, str]
    ) -> Dict[str, str]:
        """Visit multiple URLs and return page content as plain text."""
        pages = {}
        for key, url in raw_url_dict.items():
            if not url:
                continue
            try:
                session.get(url)
                WebDriverWait(session, 10).until(
                    EC.visibility_of_element_located((By.TAG_NAME, "body"))
                )
                self._scroll_to_bottom(session)
                pages[key] = self.text_transformer.handle(session.page_source)
            except Exception as e:
                logger.error(f"Error loading {url} >> {e}")
                pages[key] = f"Error: {e}"
        return pages

    def _run_multi_io_tasks(
        self, insights_map: Dict[str, str], max_workers: int = 4
    ) -> Dict[str, Any]:
        """Run AI insight generation concurrently for multiple pages."""
        results = {}
        logger.debug("Starting multi I/O task processing...")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            task_map = {
                executor.submit(
                    self.ai_generator._get_insights,
                    page_content=raw_page_content,
                    details=details,
                ): details
                for details, raw_page_content in insights_map.items()
            }

            for task in as_completed(task_map):
                key = task_map[task]
                try:
                    results[key] = task.result()
                except Exception as e:
                    logger.error(f"Task failed for {key} >> {e}")
                    results[key] = {"error": str(e)}

        return results

    def _start_score_generation(
        self,
        profile_name: str,
        profile_data: Dict,
        company_insights: Dict,
        client_company_details: str,
        filter_id: str,
    ) -> None:
        """Run score generation in background thread."""

        def task():
            try:
                AIScoreGenerator()(
                    profile_name=profile_name,
                    candidate_profile=profile_data,
                    company_details=company_insights,
                    client_company_details=client_company_details,
                    filter_id=filter_id,
                )
            except Exception as e:
                logger.error(f"Error in score generation >> {e}")

        thread = threading.Thread(target=task, daemon=True)
        thread.start()

    def _update_database(
        self, profile_name: str, company_name: str, company_insights: Dict
    ) -> None:
        """Update MongoDB with company insights."""
        try:
            self.db_conn.update_db(
                identifier_field="profile_name",
                identifier_value=profile_name,
                fields_data={ProfileScraping.companyData.name: company_insights},
                collection_object=ProfileScraping,
            )
            self.db_conn.update_db(
                identifier_field="company_name",
                identifier_value=company_name,
                fields_data={ProfileScraping.companyData.name: company_insights},
                collection_object=Company,
            )
            logger.debug("Database updated successfully.")
        except Exception as e:
            logger.error(f"Error updating database >> {e}")

    def __call__(
        self,
        request_url: str,
        session_name: str,
        is_login_required: bool,
        profile_name: str,
        profile_data: Dict,
        company_name: str,
        client_company_details: str,
        filter_id: str,
        headless: bool = True,
    ) -> Dict[str, Any]:
        """Main entrypoint: scrape company insights and update DB."""
        session = None
        try:
            session = self.manager.create_session(
                session_name=session_name,
                is_login_required=is_login_required,
                headless=headless,
            )
            session.get(request_url)
            WebDriverWait(session, 10).until(
                EC.visibility_of_element_located((By.TAG_NAME, "body"))
            )
            self._scroll_to_bottom(session)

            logger.debug("Extracting page content...")
            raw_page_text = self.text_transformer.handle(session.page_source)

            logger.debug("Extracting insights URLs...")
            raw_urls = self.ai_generator._get_urls(
                company_url=request_url, page_content=raw_page_text
            )
            try:
                raw_url_dict = json.loads(raw_urls)
            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON from AI URL extractor >> {e}")
                return {"error": "Invalid JSON from AI URL extractor"}

            url_content_map = self._multi_surf(session, raw_url_dict)
            company_insights = self._run_multi_io_tasks(url_content_map)

            logger.debug("Starting score generation...")
            self._start_score_generation(
                profile_name,
                profile_data,
                company_insights,
                client_company_details,
                filter_id=filter_id,
            )

            logger.debug("Saving data to database...")
            self._update_database(profile_name, company_name, company_insights)

            return company_insights

        except Exception as e:
            logger.error(f"Error in AIScraper call >> {e}")
            return {"error": str(e)}

        finally:
            gc.collect()
            logger.debug("Closing Selenium session...")
            if session:
                self.manager.close_session(session_name=session_name)
