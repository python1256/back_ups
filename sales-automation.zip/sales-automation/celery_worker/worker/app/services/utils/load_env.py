from dotenv import load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    GENAI_API_KEY: str = Field(..., env="GENAI_API_KEY")
    MONGO_HOST: str = Field(..., env="MONGO_URI")
    CELERY_BROKER_URL: str = Field(..., env="CELERY_BROKER_URL")
    CELERY_RESULT_BACKEND: str = Field(..., env="CELERY_RESULT_BACKEND")
    MODEL_NAME: str = Field(..., env="MODEL_NAME")

    class Config:
        load_dotenv()
        env_file_encoding = "utf-8"
        extra = "allow"


environment = Settings()
