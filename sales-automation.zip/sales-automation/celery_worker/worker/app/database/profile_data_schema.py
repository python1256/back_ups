import json
from datetime import datetime, timezone

from mongoengine import (
    BooleanField,
    DateTimeField,
    Document,
    FloatField,
    IntField,
    ReferenceField,
    StringField,
)
from mongoengine.queryset.visitor import Q


class Company(Document):
    company_name = StringField(required=True)
    companyData = StringField(required=True, default="")
    createdAt = DateTimeField(default=datetime.now(timezone.utc))
    updatedAt = DateTimeField(default=datetime.now(timezone.utc))
    is_delete = BooleanField(default=False)

    meta = {
        "collection": "companies",
        "indexes": [{"fields": ["company_name"], "unique": True}],
    }


class Account(Document):
    """
    LinkedIn account collection that stores cookies for a user.
    """

    cookies = StringField(required=True)
    status = StringField(default="active", choices=["active", "expired", "banned"])
    linkedin_url = StringField(default="", required=True)
    createdAt = DateTimeField(default=datetime.now(timezone.utc))
    updatedAt = DateTimeField(default=datetime.now(timezone.utc))
    is_delete = BooleanField(default=False)
    username = StringField(required=True, unique=True)
    email = StringField(required=True, unique=True)
    password_hash = StringField(required=True)
    is_active = BooleanField(default=True)

    meta = {"collection": "account"}

    def save(self, *args, **kwargs):
        """Override save to auto-update updatedAt"""
        if not self.createdAt:
            self.createdAt = datetime.now(timezone.utc)
        self.updatedAt = datetime.now(timezone.utc)
        return super(Account, self).save(*args, **kwargs)

    @classmethod
    def upsert_from_request(cls, request):
        """Create, update, or fetch account depending on request data."""

        if hasattr(request, "account_id") and request.account_id:
            account = cls.objects(id=request.account_id).first()
            if not account:
                raise ValueError(f"Account not found for id: {request.account_id}")
            return account

        if not hasattr(request, "username"):
            raise ValueError("Missing 'username' in request for new account creation")

        account = cls.objects(username=request.username).first()
        if not account:
            account = cls(username=request.username)

        if hasattr(request, "cookies"):
            account.cookies = json.dumps(request.cookies, indent=4)
        if hasattr(request, "person_linkedin_url"):
            account.linkedin_url = request.person_linkedin_url

        account.save()
        return account


class Filter(Document):
    filterName = StringField(default="", required=True)
    filterData = StringField(
        required=True, help_text="Filter details stored as JSON string"
    )
    totalUrls = IntField(
        required=True, default=0, help_text="Total URLs referencing this filter"
    )
    totalScrapedUrls = IntField(
        required=True, default=0, help_text="Total URLs scraped successfully"
    )
    isEmailSent = BooleanField(
        required=True,
        default=False,
        help_text="Indicates whether email was sent for this filter",
    )
    account_id = ReferenceField(Account, required=True)
    createdAt = DateTimeField(default=datetime.now(timezone.utc))
    updatedAt = DateTimeField(default=datetime.now(timezone.utc))
    is_delete = BooleanField(default=False)

    meta = {"collection": "filters", "indexes": ["filterName", "account_id"]}

    def save(self, *args, **kwargs):
        if not self.createdAt:
            self.createdAt = datetime.now(timezone.utc)
        self.updatedAt = datetime.now(timezone.utc)
        return super(Filter, self).save(*args, **kwargs)

    @classmethod
    def upsert_from_request(cls, request):
        filter_data_json = json.dumps(request.company_requirements, indent=4)

        filter_doc = cls.objects(
            filterName=request.filter_name, account_id=request.account_id
        ).first()

        if not filter_doc:
            filter_doc = cls(
                filterName=request.filter_name,
                filterData=filter_data_json,
                account_id=request.account_id,
            )
        else:
            filter_doc.filterData = filter_data_json
            filter_doc.isEmailSent = False

        filter_doc.updatedAt = datetime.now(timezone.utc)
        filter_doc.save()
        return filter_doc


class ProfileScraping(Document):
    profile_name = StringField(
        required=True, unique=True, help_text="Unique profile name or identifier"
    )

    profileData = StringField(
        required=True, default="", help_text="Profile details as JSON string"
    )
    companyData = StringField(required=True, default="")
    scoringData = StringField(
        required=True,
        default="",
        help_text="Scoring data with relevance, match, weights",
    )

    previousProfileData = StringField(
        required=True, default="", help_text="Profile details as JSON string"
    )
    previousCompanyData = StringField(required=True, default="")
    previousScoringData = StringField(
        required=True,
        default="",
        help_text="Scoring data with relevance, match, weights",
    )

    is_delete = BooleanField(default=False)
    createdAt = DateTimeField(default=datetime.now(timezone.utc))
    updatedAt = DateTimeField(default=datetime.now(timezone.utc))

    meta = {
        "collection": "profiles",
        "indexes": ["profile_name"],
        "ordering": ["-createdAt"],
    }

    def save(self, *args, **kwargs):
        if self.pk:
            old: ProfileScraping = ProfileScraping.objects.get(id=self.pk)

            self.previousProfileData = old.profileData
            self.previousCompanyData = old.companyData
            self.previousScoringData = old.scoringData

        self.updatedAt = datetime.now(timezone.utc)
        return super(ProfileScraping, self).save(*args, **kwargs)


class DecisionData(Document):
    """Separated decision data for multi-user and multi-filter perspective"""

    profile = ReferenceField(ProfileScraping, required=True)
    filter = ReferenceField(Filter, required=False)

    decisionData = StringField(
        required=True,
        default="",
        help_text="Business decision data with relevance, match, weights",
    )

    decision_score = FloatField(
        required=True, default=0.0, help_text="Final decision score as a numeric value"
    )

    createdAt = DateTimeField(default=datetime.now(timezone.utc))
    updatedAt = DateTimeField(default=datetime.now(timezone.utc))
    is_delete = BooleanField(default=False)

    meta = {
        "collection": "decision_data",
        "indexes": ["profile", "filter"],
        "ordering": ["-createdAt"],
    }

    def save(self, *args, **kwargs):
        if not self.createdAt:
            self.createdAt = datetime.now(timezone.utc)
        self.updatedAt = datetime.now(timezone.utc)
        return super(DecisionData, self).save(*args, **kwargs)


class LinkedInURL(Document):
    url = StringField(required=True)
    status = StringField(
        default="pending", choices=["pending", "in_progress", "done", "failed", "draft"]
    )
    is_update = BooleanField(default=False)
    account = ReferenceField(Account, required=True)
    filter = ReferenceField(Filter, required=False)
    createdAt = DateTimeField(default=datetime.now(timezone.utc))
    updatedAt = DateTimeField(default=datetime.now(timezone.utc))
    is_delete = BooleanField(default=False)

    meta = {
        "collection": "linkedin_urls",
        "indexes": [{"fields": ["url", "filter"], "unique": True}],
    }

    def save(self, *args, **kwargs):
        if not self.createdAt:
            self.createdAt = datetime.now(timezone.utc)
        self.updatedAt = datetime.now(timezone.utc)
        result = super(LinkedInURL, self).save(*args, **kwargs)

        if self.filter:
            update_filter_counts(self.filter.id)

        return result

    def update_doc(self, **kwargs):
        for field, value in kwargs.items():
            setattr(self, field, value)
        self.updatedAt = datetime.now(timezone.utc)
        self.save()


def update_filter_counts(filter_id):
    total_urls = LinkedInURL.objects(filter=filter_id).count()
    total_scraped = LinkedInURL.objects(
        Q(filter=filter_id) & Q(status__in=["done", "failed"])
    ).count()

    Filter.objects(id=filter_id).update_one(
        set__totalUrls=total_urls,
        set__totalScrapedUrls=total_scraped,
        set__updatedAt=datetime.now(timezone.utc),
    )
