import json
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Union

from mongoengine import Document, connect, disconnect

from ..services.utils.log import logger


class MongoDBConnection:
    """
    MongoDB session manager:
    - Creates connection on demand
    - Auto-disconnects after idle timeout
    - Reconnects if a query is made after disconnect
    """

    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(MongoDBConnection, cls).__new__(cls)
        return cls._instance

    def __init__(
        self,
        host: str,
        alias: str = "default",
        idle_timeout: int = 300,
    ):
        self.host = host
        self.alias = alias
        self.idle_timeout = idle_timeout
        self.connection = None
        self._idle_timer: threading.Timer = None

    def _start_idle_timer(self):
        """Start/reset idle timer to auto disconnect"""
        if self._idle_timer:
            self._idle_timer.cancel()
        self._idle_timer = threading.Timer(self.idle_timeout, self.disconnect)
        self._idle_timer.start()

    def connect(self):
        """Establish MongoDB connection if not connected"""
        if self.connection is None:
            try:
                self.connection = connect(
                    host=self.host,
                    alias=self.alias,
                )
                logger.debug("Connected to database..")
            except Exception as e:
                logger.error(f"Error connecting to database >> {e}")
                self.connection = None

        self._start_idle_timer()
        return self.connection

    def disconnect(self):
        """Disconnect MongoDB if connected"""
        if self.connection:
            try:
                disconnect(alias=self.alias)
                self.connection = None
                logger.debug("Disconnected from database...")
            except Exception as e:
                logger.error(f"Error while disconnecting >> {e}")

    def is_connected(self) -> bool:
        try:
            if self.connection:
                logger.debug("MongoDB is connected.")
                return True
            logger.debug("MongoDB is not connected.")
            return False
        except Exception as e:
            logger.error(f"Error while check availability of database >> {e}")

    def _create_new_document(
        self, collection_object, identifier_field, identifier_value, fields_data
    ):
        init_data = {
            identifier_field: identifier_value,
            "createdAt": datetime.now(timezone.utc),
            "updatedAt": datetime.now(timezone.utc),
        }
        init_data.update(self._prepare_fields(fields_data))

        new_doc = collection_object(**init_data)
        new_doc.save()
        logger.info(f"New document created with ID: {new_doc.id}")

    def _update_existing_document(
        self, doc, identifier_field, identifier_value, fields_data
    ):
        logger.info(
            f"Updating existing document for {identifier_field}={identifier_value}"
        )

        for key, value in self._prepare_fields(fields_data).items():
            setattr(doc, key, value)

        doc.updatedAt = datetime.now(timezone.utc)
        doc.save()

    def _prepare_fields(self, fields_data):
        processed = {}
        for key, value in fields_data.items():
            processed[key] = (
                json.dumps(value, indent=4)
                if isinstance(value, (dict, list))
                else value
            )
        return processed

    def update_db(
        self,
        fields_data: Dict[str, Union[List, Dict, str, Any]],
        collection_object: Document,
        identifier_field: str,
        identifier_value: str,
    ):
        try:
            if not self.is_connected():
                self.connect()

            doc = collection_object.objects(
                **{identifier_field: identifier_value}
            ).first()

            if not doc:
                self._create_new_document(
                    collection_object, identifier_field, identifier_value, fields_data
                )
            else:
                self._update_existing_document(
                    doc, identifier_field, identifier_value, fields_data
                )

        except Exception as e:
            logger.error(f"Error while updating MongoDB: {e}")
