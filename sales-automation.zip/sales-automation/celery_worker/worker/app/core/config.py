import os

import google.generativeai as genai
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI

from ..services.utils.load_env import environment

load_dotenv()

genai.configure(api_key=environment.GENAI_API_KEY)

model = genai.GenerativeModel(model_name=environment.MODEL_NAME)

PASSWORD = os.getenv("LOGIN_PASSWORD")

llm = ChatGoogleGenerativeAI(
    api_key=environment.GENAI_API_KEY,
    model=environment.MODEL_NAME,
    temperature=0.5,
    top_p=0.3,
    max_tokens=1500,
)
