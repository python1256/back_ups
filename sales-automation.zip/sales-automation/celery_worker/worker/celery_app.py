from celery import Celery

from .app.services.utils.load_env import environment
from .task import scrape_linkedin_profile

celery_app = Celery(
    "worker",
    broker=environment.CELERY_BROKER_URL,
    backend=environment.CELERY_RESULT_BACKEND,
)
celery_app.autodiscover_tasks(["worker"])

celery_app.conf.task_routes = {
    "scrape_linkedin_profile": {"queue": "linkedin_queue"},
}

celery_app.conf.update(
    task_serializer="json",
    result_serializer="json",
    accept_content=["json"],
    timezone="UTC",
    enable_utc=True,
)
