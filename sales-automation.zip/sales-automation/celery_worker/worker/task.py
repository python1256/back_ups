import json
import threading
from datetime import datetime, timezone
from urllib.parse import urlparse
from uuid import uuid1

from celery import shared_task

from .app.database.mongo_database import MongoDBConnection
from .app.database.profile_data_schema import Account, LinkedInURL, ProfileScraping
from .app.services.scrapper_service.traditional_scrapper.profile_scrapper_service import (
    TraditionalProfileScrapper,
)
from .app.services.utils.load_env import environment
from .app.services.utils.log import logger

db_conn = MongoDBConnection(host=environment.MONGO_HOST)


def get_name(url: str) -> str:
    """
    Extracts the profile name from a LinkedIn profile URL.
    """
    parsed_url = urlparse(url=url)
    path_parts = parsed_url.path.strip("/").split("/")

    if len(path_parts) >= 2 and path_parts[0] == "in":
        return path_parts[1]

    return "unknown"


@shared_task(name="scrape_linkedin_profile")
def scrape_linkedin_profile(url_id: str, update: bool):
    """
    Celery Worker task to scrape LinkedIn profiles using threading.
    Task returns immediately; thread updates DB when done.
    """
    try:
        if not db_conn.is_connected():
            db_conn.connect()

        url_doc: LinkedInURL = LinkedInURL.objects(id=url_id).first()
        if not url_doc:
            logger.debug(f"url is not found for id >> {url_id}")
            return f"URL with id {url_id} not found"

        account: Account = Account.objects(id=str(url_doc.account.id)).first()

        client_profile_name = get_name(url=account.linkedin_url)
        client_profile_details: ProfileScraping = ProfileScraping.objects(
            profile_name=client_profile_name
        ).first()
        client_company_details = client_profile_details.companyData

        if not account:
            logger.debug(f"No account associated with id >> {url_doc.account.id}")
            url_doc.update_doc(status="failed", updatedAt=datetime.now(timezone.utc))
            return f"No account found for url {url_doc.url}"

        profile_doc = ProfileScraping.objects(
            profile_name=get_name(url_doc.url)
        ).first()

        if profile_doc and not update:
            url_doc.update_doc(
                status="done",
                updatedAt=datetime.now(timezone.utc),
            )
            return {"message": "Profile already present in database..."}
        else:
            cookies = json.loads(account.cookies)
            logger.info(
                f"Worker scraping {url_doc.url} using account {account.username}"
            )

            logger.debug(f"Set status in_progress for url >> {url_doc.url}")
            url_doc.update(status="in_progress", updatedAt=datetime.now(timezone.utc))

            def run_scraper():
                try:
                    _ = TraditionalProfileScrapper()(
                        cookies=cookies,
                        login_url="https://www.linkedin.com/login",
                        profile_url=url_doc.url,
                        session_name=str(uuid1()),
                        document_id=str(url_doc.id),
                        headless=True,
                        is_login_required=True,
                        filter_id=str(url_doc.filter.id),
                        client_company_details=client_company_details,
                    )

                    logger.info(f"Scraping finished for {url_doc.url}")

                except Exception as e:
                    logger.error(f"Error inside scraper thread >> {e}")
                    url_doc.update_doc(
                        status="failed",
                        updatedAt=datetime.now(timezone.utc),
                    )

            run_scraper()

            # Task returns immediately
            return {"status": "accepted", "url_id": url_id}

    except Exception as e:
        logger.error(f"Error in celery worker >> {e}")
        url_doc.update_doc(status="failed", updatedAt=datetime.now(timezone.utc))
        return {"status": "failed", "error": str(e)}
