import json
from datetime import datetime, timezone
from typing import List, Optional

from bson import ObjectId
from mongoengine.errors import DoesNotExist, NotUniqueError

from ..database.profile_data_schema import Account  # adjust path as needed


class AccountRepository:
    """
    Repository for managing Account documents.
    """

    @staticmethod
    def create_account(
        username: str,
        email: str,
        password_hash: str,
        cookies: str,
        linkedin_url: str,
        status: str = "freeze",
    ) -> Account:
        """
        Create a new LinkedIn account document.
        """
        try:
            account = Account(
                username=username,
                email=email,
                cookies=cookies,
                linkedin_url=linkedin_url,
                password_hash=password_hash,  # leave blank if login via LinkedIn only
                status=status,
                createdAt=datetime.now(timezone.utc),
                updatedAt=datetime.now(timezone.utc),
            )
            account.save()
            return account
        except NotUniqueError:
            raise ValueError("Username or email already exists")

    # ----------------------------------------------------------
    @staticmethod
    def get_by_id(id: str) -> Optional[Account]:
        """
        Get an account by user id
        """
        #  Account.objects(id=ObjectId(user_id), is_delete=False).first()
        try:
            return Account.objects(id=ObjectId(id), is_delete=False).first()
        except DoesNotExist:
            return None

    @staticmethod
    def get_by_username(username: str) -> Optional[Account]:
        """
        Get an account by username.
        """
        try:
            return Account.objects.get(username=username, is_delete=False)
        except DoesNotExist:
            return None

    # ----------------------------------------------------------

    @staticmethod
    def get_by_email(email: str) -> Optional[Account]:
        """
        Get an account by email.
        """
        try:
            return Account.objects.get(email=email, is_delete=False)
        except DoesNotExist:
            return None

    # ----------------------------------------------------------

    @staticmethod
    def get_all(active_only: bool = True) -> List[Account]:
        """
        Get all accounts, optionally only active ones.
        """
        query = Account.objects(is_delete=False)
        if active_only:
            query = query.filter(is_active=True)
        return list(query)

    # ----------------------------------------------------------

    @staticmethod
    def update_account(username: str, **updates) -> Optional[Account]:
        """
        Update fields of an account and return the updated document.
        """
        account = AccountRepository.get_by_username(username)
        if not account:
            return None

        for key, value in updates.items():
            if hasattr(account, key):
                setattr(account, key, value)

        account.updatedAt = datetime.now(timezone.utc)
        account.save()
        return account

    # ----------------------------------------------------------

    @staticmethod
    def delete_account(username: str) -> bool:
        """
        Soft delete an account (set is_delete=True).
        """
        account = AccountRepository.get_by_username(username)
        if not account:
            return False

        account.is_delete = True
        account.is_active = False
        account.updatedAt = datetime.now(timezone.utc)
        account.save()
        return True

    # ----------------------------------------------------------

    @staticmethod
    def update_status(username: str, status: str) -> bool:
        """
        Update LinkedIn account status.
        """
        if status not in ["active", "expired", "banned"]:
            raise ValueError("Invalid status value")

        account = AccountRepository.get_by_username(username)
        if not account:
            return False

        account.status = status
        account.updatedAt = datetime.now(timezone.utc)
        account.save()
        return True
