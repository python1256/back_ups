import shutil
import tempfile
import uuid

from selenium import webdriver
from selenium.webdriver.chrome.options import Options


class SeleniumSession:
    def __init__(self, headless: bool = False, is_login_required: bool = True):
        self._user_data_dir = tempfile.mkdtemp(prefix="chrome-ud-")
        self._profile_dir = f"Profile-{uuid.uuid4()}"

        chrome_options = Options()

        if headless:
            chrome_options.add_argument("--headless=new")

        if not is_login_required:
            chrome_options.add_argument(
                "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
                "AppleWebKit/537.36 (KHTML, like Gecko)"
                "Chrome/115.0.0.0 Safari/537.36"
            )
            chrome_options.add_argument(
                "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121 Safari/537.36"
            )

        # Stable for containers
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")

        # Nice-to-have flags
        chrome_options.add_argument("--disable-popup-blocking")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--disable-infobars")
        chrome_options.add_argument("--mute-audio")

        # Avoid port collisions
        chrome_options.add_argument("--remote-debugging-port=0")

        # Give this session its own profile dir
        chrome_options.add_argument(f"--user-data-dir={self._user_data_dir}")
        chrome_options.add_argument(f"--profile-directory={self._profile_dir}")

        # You can keep Selenium Manager (no explicit Service needed)
        self.driver = webdriver.Chrome(options=chrome_options)

    def close(self):
        try:
            self.driver.quit()
        finally:
            shutil.rmtree(self._user_data_dir, ignore_errors=True)


class SeleniumManager:
    def __init__(self):
        self.sessions = {}

    def create_session(
        self,
        is_login_required: bool,
        session_name: str,
        headless: bool = True,
    ):
        """Create a new independent browser session or return existing one if name matches."""
        # If a session with the same name exists, return its driver
        if session_name in self.sessions:
            return self.sessions[session_name].driver

        # Otherwise, create a new session
        session = SeleniumSession(
            headless=headless, is_login_required=is_login_required
        )
        self.sessions[session_name] = session
        return session.driver

    def get_session(self, session_name: str):
        """Retrieve a session by name."""
        s = self.sessions.get(session_name)
        return s.driver if s else None

    def close_session(self, session_name: str):
        """Close and remove a session."""
        s = self.sessions.pop(session_name, None)
        if s:
            s.close()

    def close_all(self):
        """Close all sessions."""
        for name in list(self.sessions.keys()):
            self.close_session(name)
