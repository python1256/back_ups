import os

import google.generativeai as genai
from dotenv import load_dotenv
from fastapi import Response
from langchain_google_genai import ChatGoogleGenerativeAI

from ..database.mongo_database import MongoDBConnection
from ..services.utils.load_env import environment

load_dotenv()

genai.configure(api_key=environment.GENAI_API_KEY)

model = genai.GenerativeModel(model_name=environment.MODEL_NAME)

PASSWORD = os.getenv("LOGIN_PASSWORD")

CLIENT_ID = os.getenv("LINKEDIN_CLIENT_ID")
CLIENT_SECRET = os.getenv("LINKEDIN_CLIENT_SECRET")
URL_REDIRECT = os.getenv("REDIRECT")
REDIRECT_URI = f"{URL_REDIRECT}/linkdin-auth-callback"
KEY_NAME = environment.TOKEN_NAME
ALLOWED_ORIGINS = environment.ALLOWED_ORIGINS
llm = ChatGoogleGenerativeAI(
    api_key=environment.GENAI_API_KEY, model=environment.MODEL_NAME
)

db_conn = MongoDBConnection(host=environment.MONGO_HOST)

ENV = os.getenv("ENV", "local")  # "local" or "prod"


def set_access_cookie(response: Response, access_token: str):
    response.set_cookie(
        KEY_NAME,
        access_token,
        httponly=True,
        samesite="none" if ENV == "prod" else "lax",
        secure=True if ENV == "prod" else False,
        path="/",
    )
