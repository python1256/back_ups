import json
import math

from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import JSONResponse
from mongoengine.errors import DoesNotExist

from ......core.config import db_conn
from ......database.models.content import PersonaLibrary
from ......database.profile_data_schema import DecisionData, Filter, ProfileScraping
from ......services.utils.log import logger
from .....v1.controllers.extension.authrouter import verify_token

router = APIRouter()


def safe_json_loads(data):
    if not data:
        return {}
    if isinstance(data, dict):
        return data
    try:
        return json.loads(data)
    except json.JSONDecodeError:
        return {}
    except TypeError:
        return {}


@router.get("/profiles/{profile_id}")
def get_profile_by_id(profile_id: str, user_data=Depends(verify_token)):
    """
    Get a single profile by its ID.
    """
    # ---- DB CONNECT ----
    try:
        if not db_conn.is_connected():
            db_conn.connect()
    except Exception:
        raise HTTPException(status_code=500, detail="Database connection error")

    # ---- Validate ID ----
    if not ObjectId.is_valid(profile_id):
        logger.error("Invalid profile ID")
        raise HTTPException(status_code=400, detail="Invalid profile ID")

    try:
        # ---- Fetch Profile ----
        profile: ProfileScraping = ProfileScraping.objects.get(
            id=ObjectId(profile_id), is_delete=False
        )

        # ---- Safe JSON ----
        profile_data = safe_json_loads(profile.profileData)
        scoring_data_all = safe_json_loads(profile.scoringData)

        # ---- Fetch related DecisionData ----
        decision_entry = DecisionData.objects(
            profile=ObjectId(profile_id), is_delete=False
        ).first()

        if decision_entry:
            decision_data_all = safe_json_loads(decision_entry.decisionData)

        # ---- Final Output (unchanged structure) ----
        return {
            "id": str(profile.id),
            "profile_name": profile.profile_name,
            "profileData": profile_data,
            "scoringData": scoring_data_all,
            "decisionData": decision_data_all,
            "decision_score": decision_entry.decision_score,
            "filter_id": str(decision_entry.filter),
            "createdAt": profile.createdAt.isoformat(),
            "updatedAt": profile.updatedAt.isoformat(),
        }

    except DoesNotExist:
        logger.error("Profile not found")
        raise HTTPException(status_code=404, detail="Profile not found")
    except Exception as e:
        logger.error(f"Error fetching profile: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/profiles")
def get_profiles_by_filter(
    filter_id: str,
    q: str = "",
    page: int = 1,
    user_data=Depends(verify_token),
):
    try:
        if not db_conn.is_connected():
            db_conn.connect()
    except Exception:
        raise HTTPException(status_code=500, detail="Database connection error")

    # Validate filter ID
    if not ObjectId.is_valid(filter_id):
        logger.error("Invalid filter ID")
        raise HTTPException(status_code=400, detail="Invalid filter ID")

    filter_obj: Filter = Filter.objects(id=ObjectId(filter_id), is_delete=False).first()
    if not filter_obj:
        logger.error("Filter not found.")
        return JSONResponse(status_code=400, content={"message": "Filter not found."})

    # --- Fetch DecisionData entries for this filter ---
    decision_entries = DecisionData.objects(
        filter=ObjectId(filter_obj.id), is_delete=False
    )

    if not decision_entries:
        return {
            "filter_name": filter_obj.filterName,
            "filter_id": filter_id,
            "profiles": [],
            "page": 1,
            "page_size": 5,
            "total_profiles": 0,
            "totalPages": 1,
        }

    # Extract profile IDs linked to this filter
    profile_ids = [entry.profile.id for entry in decision_entries if entry.profile]

    # --- Query ProfileScraping documents ---
    query = ProfileScraping.objects(id__in=profile_ids, is_delete=False)
    # Search filter
    if q:
        query = query.filter(profile_name__icontains=q)

    total_profiles = query.count()

    # Pagination
    page_size = 5
    total_pages = max(1, math.ceil(total_profiles / page_size))
    page = min(page, total_pages)
    skip = (page - 1) * page_size
    profiles = query.skip(skip).limit(page_size)

    # --- Prepare response data ---
    profile_list = []
    for i, p in enumerate(profiles):
        profile_data = safe_json_loads(p.profileData)
        scoring_data = safe_json_loads(p.scoringData)

        # Find matching decision entry for this profile
        decision_entry = next(
            (d for d in decision_entries if d.profile.id == p.id), None
        )
        decision_data = (
            safe_json_loads(decision_entry.decisionData)
            if decision_entry and decision_entry.decisionData
            else {}
        )

        profile_list.append(
            {
                "id": str(p.id),
                "profile_name": p.profile_name,
                "profileData": profile_data,
                "scoringData": {
                    "role": scoring_data.get("role", ""),
                    "overall_match_score": scoring_data.get(
                        "overall_strength_score", ""
                    ),
                },
                "decisionData": {
                    "decision": decision_data.get("decision", ""),
                },
                # "score": decision_entry.decision_score if decision_entry else 0.0,
                "filter_id": str(filter_obj.id),
                "createdAt": p.createdAt.isoformat(),
                "updatedAt": p.updatedAt.isoformat(),
            }
        )

    return {
        "filter_name": filter_obj.filterName,
        "filter_id": filter_id,
        "profiles": profile_list,
        "page": page,
        "page_size": page_size,
        "total_profiles": total_profiles,
        "totalPages": total_pages,
    }


@router.get("/persona-library")
def get_persona_library_grouped(
    user_data=Depends(verify_token),
):
    """
    Fetch all entries from persona_library and group by type:
    - department
    - industries
    - persona
    """
    try:
        # Initialize result
        result = {
            "department": [],
            "industries": [],
            "persona": [],
            "seniority_level": [],
        }

        # Fetch all entries
        entries = PersonaLibrary.objects().order_by("-createdAt")

        # Group entries by type
        for e in entries:
            entry_dict = {
                "id": str(e.id),
                "title": e.title,
                "description": e.description,
                "createdAt": e.createdAt.isoformat(),
                "updatedAt": e.updatedAt.isoformat(),
            }

            # Map types to response keys
            if e.type == "department":
                result["department"].append(entry_dict)
            elif e.type == "industries":
                result["industries"].append(entry_dict)
            elif e.type == "persona":
                result["persona"].append(entry_dict)
            elif e.type == "seniority_level":
                result["seniority_level"].append(entry_dict)

        return result

    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Failed to fetch entries: {str(e)}"
        )
