from typing import List, Literal, Optional

from pydantic import BaseModel, EmailStr, HttpUrl


class BusinessModel(BaseModel):
    business_model: str


class PhoneNumbers(BaseModel):
    sales_us: Optional[str]
    sales_india: Optional[str]
    hr: Optional[str]


class Address(BaseModel):
    country: str
    type: str
    address: str


class SocialMedia(BaseModel):
    linkedin: Optional[HttpUrl]
    twitter: Optional[HttpUrl]
    behance: Optional[HttpUrl]
    youtube: Optional[HttpUrl]
    instagram: Optional[HttpUrl]
    facebook: Optional[HttpUrl]


class CompanyDetailsInner(BaseModel):
    name: str
    contact_email: Optional[EmailStr]
    phone_numbers: PhoneNumbers
    addresses: List[Address]
    social_media: SocialMedia
    website: HttpUrl


class CompanyDetails(BaseModel):
    company_details: CompanyDetailsInner


class TechStack(BaseModel):
    tech_stack: List[str]


class Clients(BaseModel):
    clients: List[HttpUrl]


class DataResponse(BaseModel):
    business_model: BusinessModel
    company_details: CompanyDetails
    tech_stack: TechStack
    clients: Clients


class CompanyResponse(BaseModel):
    data: DataResponse


# score response model


class FactorScores(BaseModel):
    experience: int
    technologies_skills: int
    projects: int
    company_fit: int
    tech_stack_alignment: int


class Insights(BaseModel):
    total_found: int
    selected_for_content: int
    with_talking_points_saved: int
    sales_assets_selected: int
    additional_info_added: bool
    value_prop_used: str


class Tip(BaseModel):
    tip: str
    value: int
    example: str


class ScoreResponse(BaseModel):
    role: str
    analysis: Literal["Excellent", "Good", "Average", "Poor"]
    overall_match_score: int
    overview: str
    factor_scores: FactorScores
    insights: Insights
    description: str
    persona: str
    writing_style_used: str
    created_by: List[str]
    tips_to_improve: List[Tip]


class MatchResponse(BaseModel):
    score: ScoreResponse
