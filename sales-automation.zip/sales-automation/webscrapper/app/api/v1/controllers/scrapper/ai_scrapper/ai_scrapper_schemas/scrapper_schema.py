from typing import Dict, List, Optional, Union
from urllib.parse import urlparse

from pydantic import BaseModel, field_validator


class AIscrapperRequest(BaseModel):
    request_url: str
    profile_name: str
    profile_data: Dict
    company_name: str

    @field_validator("request_url", mode="before")
    def verify_url(cls, v: str):
        parsed = urlparse(v)
        if not parsed.scheme or not parsed.netloc:
            raise ValueError("Invalid URL: must include scheme (http/https) and domain")
        return v

    class Config:
        json_schema_extra = {
            "example": {
                "request_url": "https://www.aspiresoftserv.com/",
                "profile_name": "aspire",
                "profile_data": dict({}),
                "company_name": "aspiresoftserv",
            }
        }


class AIscoreRequest(BaseModel):
    profile_data: Optional[Union[Dict, List]]
    company_data: Optional[Union[Dict, List]]
    profile_name: str

    class Config:
        json_schema_extra = {"example": {"profile_data": {}, "company_data": {}}}
