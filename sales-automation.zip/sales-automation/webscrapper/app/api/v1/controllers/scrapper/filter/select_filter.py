import json
import math
import threading
from datetime import datetime, timezone
from functools import partial
from typing import Dict, List
from urllib.parse import urljoin
from uuid import uuid1

import httpx
from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Path, Query, status
from fastapi.responses import JSONResponse
from mongoengine import DoesNotExist, connect

from ......core.config import db_conn
from ......database.profile_data_schema import Account, Filter, ProfileScraping
from ......repository.account_repository import AccountRepository
from ......services.filter_services.filter_service import FilterSelection
from ......services.scrapper_service.traditional_scrapper.profile_scrapper_service import (
    TraditionalProfileScrapper,
)
from ......services.utils.load_env import environment
from ......services.utils.log import logger
from .....v1.controllers.extension.authrouter import verify_token
from .filter_schemas.filter_request_schema import (
    CookieUpdateRequest,
    DeleteFilters,
    EditFilter,
    FilterBody,
    FilterRequest,
)
from .url_routes import URLRequest, add_urls

router = APIRouter()

ACCOUNT_ERROR_MESSAGE = "Account not found."

headers = {
    "accept": "application/json",
    "Cache-Control": "no-cache",
    "Content-Type": "application/json",
    "x-api-key": environment.APOLLO_API_KEY,
}


def get_selection():
    return FilterSelection()


def get_scrapper():
    return TraditionalProfileScrapper()


async def get_profiles(api_data: Dict) -> List:
    url_set = set()
    try:
        if "people" in api_data:
            people_data = api_data["people"]
            for person in people_data:
                if "linkedin_url" in person:
                    url_set.add(person["linkedin_url"])
        return list(url_set)
    except Exception as e:
        logger.error(f"Error while get profile url from api response >> {e}")
        return []


@router.get("/filters/{account_id}")
def get_filters_by_account(
    account_id: str = Path(..., description="MongoDB Account ID")
):
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        # Validate account exists
        account = Account.objects.get(id=ObjectId(account_id))
    except DoesNotExist:
        logger.error(ACCOUNT_ERROR_MESSAGE)
        raise HTTPException(status_code=404, detail=ACCOUNT_ERROR_MESSAGE)

    # Fetch filters associated with this account
    filters = Filter.objects(account_id=account, is_delete=False)

    # Convert to JSON-friendly format
    filter_list = []
    for f in filters:
        filter_list.append(
            {
                "id": str(f.id),
                "user_id": str(f.user.id),
                "filterData": f.filterData,
                "createdAt": f.createdAt.isoformat(),
                "updatedAt": f.updatedAt.isoformat(),
            }
        )

    return {"account_id": account_id, "filters": filter_list}


@router.post("/filters")
async def select_filter(
    request: FilterBody,
    params: FilterRequest = Query(...),
    filter_selection: FilterSelection = Depends(get_selection),
    profile_scrapper: TraditionalProfileScrapper = Depends(get_scrapper),
    user_data=Depends(verify_token),
):
    try:
        if not db_conn.is_connected():
            db_conn.connect()

        # Build Apollo API URL
        base_url = urljoin(environment.APOLLO_API_URL, "mixed_people/search")
        query_string = filter_selection.build_query(params=params)
        url = f"{base_url}?{query_string}"

        company_requirements = params.model_dump(exclude_none=True)

        if isinstance(user_data, JSONResponse):
            user_data = json.loads(user_data.body)
            logger.debug(user_data)

        account_doc = AccountRepository.get_by_email(user_data.get("email"))
        profile_name = profile_scrapper._get_name(account_doc.linkedin_url)
        profile_doc: ProfileScraping = ProfileScraping.objects(
            profile_name=profile_name
        ).first()

        # Start profile scraping if not found
        scraping_started = False
        if profile_doc and profile_doc.profileData:
            logger.info(f"Profile found in database >> {profile_name}")
        else:
            scraping_started = True
            logger.debug("Start person profile scraping...")
            threading.Thread(
                target=partial(
                    profile_scrapper,
                    cookies=json.loads(account_doc.cookies),
                    login_url="https://www.linkedin.com/login",
                    profile_url=account_doc.linkedin_url,
                    session_name=str(uuid1()),
                    headless=True,
                    is_login_required=True,
                ),
                daemon=True,
            ).start()

        # Call Apollo API
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url=url, headers=headers)
            response.raise_for_status()

        linkedin_urls = await get_profiles(api_data=response.json())

        # Add URLs to scraping queue
        try:
            await add_urls(
                request=URLRequest(
                    profile_url=linkedin_urls,
                    is_update=False,
                    filter_name=request.filter_name,
                    company_requirements=company_requirements,
                    account_id=str(account_doc.id),
                )
            )
            logger.debug("URLs set for scraping...")
        except Exception as e:
            logger.error(f"Error while adding LinkedIn URLs to scraping queue >> {e}")

        # Return structured response to the client
        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "message": "Filter applied successfully",
                "filter_name": request.filter_name,
                "total_urls_found": len(linkedin_urls),
                "linkedin_urls": linkedin_urls,
                "scraping_started": scraping_started,
                "company_requirements": company_requirements,
            },
        )

    except httpx.HTTPStatusError as e:
        logger.error(f"Apollo API error: {e}")
        return JSONResponse(
            status_code=status.HTTP_502_BAD_GATEWAY,
            content={"message": "Failed to fetch data from Apollo API"},
        )
    except Exception as e:
        logger.error(f"Error while applying filter >> {e}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"message": str(e)},
        )


@router.put("/filters")
async def select_filter(
    request: EditFilter,
    params: FilterRequest = Query(...),
    filter_selection: FilterSelection = Depends(get_selection),
    profile_scrapper: TraditionalProfileScrapper = Depends(get_scrapper),
    user_data=Depends(verify_token),
):
    try:
        if not db_conn.is_connected():
            db_conn.connect()

        # Fetch filter document
        filter_doc = Filter.objects(id=ObjectId(request.filter_id)).first()
        if not filter_doc:
            raise HTTPException(status_code=404, detail="Filter not found")

        # Load existing filterData (if any)
        existing_filter_data = {}
        if filter_doc.filterData:
            try:
                existing_filter_data = json.loads(filter_doc.filterData)
            except json.JSONDecodeError:
                existing_filter_data = {}

        # New data from query params
        new_filter_data = params.model_dump(exclude_none=True)

        # Merge old + new
        merged_filter_data = {**existing_filter_data, **new_filter_data}

        # Build Apollo query
        base_url = urljoin(environment.APOLLO_API_URL, "mixed_people/search")
        query_string = filter_selection.build_query(params=params)
        url = f"{base_url}?{query_string}"

        # Call Apollo API
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url=url, headers=headers)
            response.raise_for_status()

        linkedin_urls = await get_profiles(api_data=response.json())
        # Update filter document
        filter_doc.totalUrls = len(linkedin_urls)
        filter_doc.totalScrapedUrls = 0
        filter_doc.updatedAt = datetime.now(timezone.utc)
        filter_doc.filterData = json.dumps(merged_filter_data, indent=2)
        filter_doc.save()

        # Add URLs to scraping queue
        try:
            await add_urls(
                request=URLRequest(
                    profile_url=linkedin_urls,
                    is_update=False,
                    filter_name=request.filter_name,
                    company_requirements=merged_filter_data,
                    account_id=user_data.get("id"),
                )
            )
            logger.debug("URLs set for scraping...")
        except Exception as e:
            logger.error(f"Error while setting LinkedIn URLs for scraping queue >> {e}")

        return JSONResponse(
            status_code=200,
            content={
                "message": "Filter updated successfully",
                "url": url,
                "filterData": merged_filter_data,
                "total_urls": len(linkedin_urls),
            },
        )

    except Exception as e:
        logger.error(f"Error while updating filter >> {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/filters")
def get_filters_by_account(
    page: int = 1,
    q: str = Query(None),
    user_data=Depends(verify_token),
):
    email = user_data.get("email")

    try:
        if not db_conn.is_connected():
            db_conn.connect()
    except DoesNotExist:
        raise HTTPException(status_code=404, detail="User not found")

    # Base query
    account = Account.objects(is_delete=False, email=email).first()
    if not account:
        logger.error(ACCOUNT_ERROR_MESSAGE)
        return JSONResponse(status_code=400, content={"message": ACCOUNT_ERROR_MESSAGE})

    query = Filter.objects(account_id=ObjectId(account.id), is_delete=False).order_by(
        "-updatedAt"
    )
    print("q")

    # Apply search filter if q is provided
    if q:
        query = query.filter(filterName__icontains=q)

    # Pagination setup
    page_size = 5
    total_filters = query.count()
    total_pages = max(1, math.ceil(total_filters / page_size))
    page = min(page, total_pages)
    skip = (page - 1) * page_size

    filters = query.skip(skip).limit(page_size)

    # Convert to JSON-friendly format
    filter_list = [
        {
            "createdBy": account.username,
            "id": str(f.id),
            "filterData": json.loads(f.filterData),
            "filterName": f.filterName,
            "isEmailSent": f.isEmailSent,
            "createdAt": f.createdAt.isoformat(),
            "updatedAt": f.updatedAt.isoformat(),
            "totalUrls": f.totalUrls,
            "totalScrapedUrls": f.totalScrapedUrls,
        }
        for f in filters
    ]
    print("donw")
    return {
        "account_id": str(account.id),
        "filters": filter_list,
        "page": page,
        "page_size": page_size,
        "total_filters": total_filters,
        "totalPages": total_pages,
    }


@router.get("/filter/{filter_id}")
def get_filter_by_id(filter_id: str, user_data=Depends(verify_token)):
    """Fetch a single filter by its ID."""
    account_id = user_data.get("id")

    try:
        if not db_conn.is_connected():
            db_conn.connect()
    except Exception as e:
        logger.error(f"DB connection error: {e}")
        raise HTTPException(status_code=500, detail="Database connection error")

    # Validate filter_id
    if not ObjectId.is_valid(filter_id):
        raise HTTPException(status_code=400, detail="Invalid filter ID")

    # Fetch filter for this account
    account: Account = Account.objects(id=ObjectId(account_id), is_delete=False).first()

    filter_obj = Filter.objects(
        id=ObjectId(filter_id), account_id=ObjectId(account_id), is_delete=False
    ).first()
    if not filter_obj:
        raise HTTPException(status_code=404, detail="Filter not found")

    return {
        "createdBy": account.username,
        "id": str(filter_obj.id),
        "filterData": json.loads(filter_obj.filterData),
        "filterName": filter_obj.filterName,
        "isEmailSent": filter_obj.isEmailSent,
        "createdAt": filter_obj.createdAt.isoformat(),
        "updatedAt": filter_obj.updatedAt.isoformat(),
        "totalUrls": filter_obj.totalUrls,
        "totalScrapedUrls": filter_obj.totalScrapedUrls,
    }


@router.delete("/filters")
def delete_filters(filters: DeleteFilters, user_data=Depends(verify_token)):
    try:
        deleted_count = 0

        for f_id in filters.filters_ids:
            try:
                # Safely fetch filter
                filter_obj = Filter.objects(
                    id=ObjectId(f_id), account_id=user_data.get("id"), is_delete=False
                ).first()

                if not filter_obj:
                    continue

                # Soft delete filter
                filter_obj.is_delete = True
                filter_obj.save()

                # Unlink from ProfileScraping
                profile_docs = ProfileScraping.objects(filter_obj=filter_obj.id)
                for p in profile_docs:
                    p.filter = None
                    p.save()

                deleted_count += 1

            except Exception as e:
                logger.error(f"Error deleting filter {f_id}: {e}")
                continue

        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "message": "Filters deleted successfully.",
                "deleted_count": deleted_count,
            },
        )

    except Exception as e:
        logger.error(f"Unexpected error while deleting filters: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete filters.")


@router.patch("/cookies")
def add_or_update_cookies(
    request: CookieUpdateRequest, user_data=Depends(verify_token)
):
    """
    Create or update the 'cookies' field for an Account.
    If the account doesn't exist, create a new one with the provided data.
    """
    try:
        account = Account.objects(
            username=user_data.get("sub"), is_delete=False
        ).first()

        if not account:
            logger.error(ACCOUNT_ERROR_MESSAGE)
            return {"message": ACCOUNT_ERROR_MESSAGE, "status": 400}

        # Update existing account cookies
        account.cookies = json.dumps(request.cookies, indent=4)
        if request.linkedin_url:
            account.linkedin_url = request.linkedin_url
        account.updatedAt = datetime.now(timezone.utc)
        account.save()

        return {"message": "Cookies updated successfully", "id": str(account.id)}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
