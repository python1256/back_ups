import asyncio
from functools import partial
from typing import Any, Dict

from fastapi import APIRouter, status
from fastapi.exceptions import HTTPException

from ......services.scrapper_service.traditional_scrapper.scrapper_service import (
    LinkedInScraper,
    gen_connection_request,
    gen_mail,
)
from ......services.utils.log import logger
from .profile_scrapper_schemas.profile_scrapper_schema import ProfileRequest

router = APIRouter()


@router.post("/scrape-and-generate")
async def scrape_and_generate(data: ProfileRequest) -> Dict[str, Any]:
    """
    Extract details from sales navigator profile.
    """
    try:
        logger.debug(f"Received request to scrape profile: {data.profile_url}")

        scraper = LinkedInScraper()
        logger.debug("Scraper object initialized")

        try:
            logger.debug("Scraping profile data")
            profile_data = await asyncio.to_thread(
                partial(scraper, profile_url=data.profile_url, cookies=data.cookies)
            )

            if "error" in profile_data:
                logger.error(f"Scraping failed: {profile_data['error']}")
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=profile_data["error"],
                )

            logger.debug("Generating email and connection request content")
            email_content = gen_mail(profile_data)
            connection_request_content = gen_connection_request(profile_data)

            logger.info("Successfully generated profile data and content")
            return {
                "profile_data": profile_data,
                "email_content": email_content,
                "connection_request_content": connection_request_content,
            }

        except Exception as scraping_error:
            logger.error(
                f"Error during scraping/generation: {str(scraping_error)}",
                exc_info=True,
            )
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Failed to process profile: {str(scraping_error)}",
            )

    except HTTPException:
        raise
    except Exception as e:
        logger.critical(
            f"Unexpected error in scrape-and-generate: {str(e)}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An unexpected error occurred while processing your request",
        )
