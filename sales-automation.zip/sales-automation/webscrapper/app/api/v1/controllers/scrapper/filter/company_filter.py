from urllib.parse import urljoin

import httpx
from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse

from ......services.filter_services.filter_service import FilterSelection
from ......services.utils.load_env import environment
from ......services.utils.log import logger
from .filter_schemas.filter_request_schema import CompanySearchParams

router = APIRouter()


def get_selection():
    return FilterSelection()


@router.get("/company-filter")
async def company_filter(
    request: CompanySearchParams = Query(...),
    filter_selection: FilterSelection = Depends(get_selection),
):
    try:
        base_url = urljoin(environment.APOLLO_API_URL, "mixed_companies/search")
        query_string = filter_selection.to_query(params=request)

        url = f"{base_url}?{query_string}"
        headers = {
            "accept": "application/json",
            "Cache-Control": "no-cache",
            "Content-Type": "application/json",
            "x-api-key": environment.APOLLO_API_KEY,
        }

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(url=url, headers=headers)

        return JSONResponse({"url": url, "response": response.json()})
    except Exception as e:
        logger.error(f"Error while select filter >> {e}")
