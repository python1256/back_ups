import asyncio
from functools import partial

from fastapi import APIRouter, Depends, status
from fastapi.responses import JSONResponse

from ......services.scrapper_service.ai_scrapper_service.score_service import (
    AIScoreGenerator,
)
from ......services.utils.log import logger
from .ai_scrapper_schemas.ai_response_schema import MatchResponse
from .ai_scrapper_schemas.scrapper_schema import AIscoreRequest

router = APIRouter()


def get_score_generator():
    return AIScoreGenerator()


@router.post(
    "/score",
    response_model=MatchResponse,
    responses={
        500: {
            "description": "Internal Server Error",
            "content": {
                "application/json": {"example": {"detail": "Something went wrong"}}
            },
        },
        400: {
            "description": "Bad Request",
            "content": {"application/json": {"example": {"detail": "Invalid input"}}},
        },
    },
)
async def score_route(
    request: AIscoreRequest,
    score_generator: AIScoreGenerator = Depends(get_score_generator),
):
    """
    Generate profile score based on achievement and company details.
    """
    try:
        profile_data = request.profile_data
        company_data = request.company_data
        profile_name = request.profile_name

        logger.debug("Generating profile score...")
        response = await asyncio.to_thread(
            partial(
                score_generator,
                profile_name=profile_name,
                candidate_profile=profile_data,
                company_details=company_data,
            )
        )

        return JSONResponse({"score": response}, status_code=status.HTTP_200_OK)
    except Exception as e:
        logger.error(f"Error while generate score >> {e}")
        return JSONResponse(
            {"message": str(e)}, status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
