from typing import Dict, List, Optional

from pydantic import BaseModel, HttpUrl


class ContactInfo(BaseModel):
    linkedin_profile: Optional[str]


class About(BaseModel):
    overview: Optional[str]
    website: Optional[HttpUrl]
    phone: Optional[str]
    industry: Optional[str]
    company_size: Optional[str]
    headquarters: Optional[str]
    founded: Optional[str]
    specialties: Optional[str]


class ExperiencePosition(BaseModel):
    position: Optional[str]
    duration: Optional[str]
    location: Optional[str]
    description: Optional[str]


class ExperienceItem(BaseModel):
    company_name: str
    position: Optional[str] = None
    duration: Optional[str] = None
    location: Optional[str] = None
    description: Optional[str] = None
    positions: Optional[List[ExperiencePosition]] = None  # for nested internship case


class ProfileData(BaseModel):
    name: str
    headline: Optional[str]
    location: Optional[str]
    connections: Optional[str]
    contact_info: Optional[ContactInfo]
    linkedin_company_url: Optional[HttpUrl]
    about: Optional[About]
    experience: List[ExperienceItem]
    education: List[Dict]


class ProfileResponse(BaseModel):
    profile_data: ProfileData
    company_data: Dict
    score_data: Dict
