import asyncio
from functools import partial

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import JSONResponse

from ......services.scrapper_service.ai_scrapper_service.ai_scrapper_service import (
    AIScraper,
)
from ......services.utils.log import logger
from .ai_scrapper_schemas.ai_response_schema import CompanyResponse
from .ai_scrapper_schemas.scrapper_schema import AIscrapperRequest

router = APIRouter()


def get_ai_scrapper():
    return AIScraper()


@router.post(
    "/company-profile",
    response_model=CompanyResponse,
    responses={
        500: {
            "description": "Internal Server Error",
            "content": {
                "application/json": {"example": {"detail": "Something went wrong"}}
            },
        },
        400: {
            "description": "Bad Request",
            "content": {"application/json": {"example": {"detail": "Invalid input"}}},
        },
    },
)
async def ai_scrapper(
    request: AIscrapperRequest, scrapper: AIScraper = Depends(get_ai_scrapper)
):
    """
    Scrap company details from website.
    """
    try:
        request_url = request.request_url
        profile_name = request.profile_name
        profile_data = request.profile_data

        logger.debug("Getting insights")
        insights = await asyncio.to_thread(
            partial(
                scrapper,
                request_url=request_url,
                session_name="test",
                is_login_required=False,
                headless=True,
                profile_name=profile_name,
                profile_data=profile_data,
                company_name=request.company_name,
            )
        )

        return JSONResponse({"data": insights}, status_code=status.HTTP_200_OK)
    except Exception as e:
        logger.error(f"Error while scrap with AI >> {e}")
        raise HTTPException(status_code=500, detail="Something went wrong")
