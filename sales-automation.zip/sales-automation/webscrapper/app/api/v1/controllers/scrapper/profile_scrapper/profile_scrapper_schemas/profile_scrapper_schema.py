from typing import Any, Dict, List

from pydantic import BaseModel


class ProfileRequest(BaseModel):
    profile_url: str
    cookies: List[Dict[str, Any]]

    class Config:
        json_schema_extra = {
            "example": {
                "profile_url": "https://www.linkedin.com/in/jaydip-savaliya-21b19b246/",
                "cookies": [],
            }
        }
