import json
from datetime import datetime, timezone
from typing import Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import JSONResponse
from mongoengine import DoesNotExist
from mongoengine import ValidationError as MongoValidationError
from pydantic import BaseModel, HttpUrl

from ......core.config import db_conn
from ......database.profile_data_schema import Account, Filter, LinkedInURL
from ......services.utils.log import logger
from ....controllers.extension.authrouter import verify_token

router = APIRouter()


class URLRequest(BaseModel):
    profile_url: List[HttpUrl]
    filter_name: str
    is_update: bool
    company_requirements: Dict
    account_id: str

    class Config:
        json_schema_extra = {
            "example": {
                "filter_name": "aspire",
                "profile_url": [
                    "https://www.linkedin.com/in/prajjwal-bhojak/",
                    "https://www.linkedin.com/in/another-user/",
                ],
                "is_update": False,
                "company_requirements": {},
                "account_id": "",
            }
        }


@router.post("/add-urls/")
async def add_urls(request: URLRequest):
    try:
        if not db_conn.is_connected():
            db_conn.connect()

        inserted, updated, skipped = [], [], []

        account = Account.objects(id=request.account_id).first()
        if not account:
            return JSONResponse({"message": "No account found..."}, status_code=404)

        filter_doc = Filter.upsert_from_request(request)

        url_list = [str(u) for u in request.profile_url]
        existing_docs = {
            (doc.url, str(doc.filter.id)): doc
            for doc in LinkedInURL.objects(url__in=url_list, filter=filter_doc)
        }

        for url_str in url_list:
            key = (url_str, str(filter_doc.id))
            url_doc = existing_docs.get(key)

            if not url_doc:
                LinkedInURL(
                    url=url_str,
                    account=account,
                    filter=filter_doc,
                    is_update=request.is_update,
                ).save()
                inserted.append(url_str)

            else:
                if request.is_update:
                    url_doc.update(
                        set__status="draft",
                        set__updatedAt=datetime.now(timezone.utc),
                        set__is_update=True,
                        set__filter=filter_doc,
                    )
                    updated.append(url_str)
                else:
                    skipped.append(url_str)

        return JSONResponse(
            {
                "account": request.account_id,
                "filter": request.filter_name,
                "inserted_urls": inserted,
                "updated_urls": updated,
                "skipped_urls": skipped,
            },
            status_code=200,
        )

    except Exception as e:
        logger.error(f"Error while adding URLs >> {e}")
        return JSONResponse({"message": str(e)}, status_code=500)


@router.patch("/execute-filter")
def execute_filter(
    request: Request,
    filter_id: Optional[str] = None,
    user_data: dict = Depends(verify_token),
):
    """
    Execute filter: sets LinkedInURL status to 'pending' for all matching records.
    """
    try:
        # 🧩 Validate required params
        if not filter_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Missing required parameter: filter_id",
            )

        # 🧠 Query all LinkedIn URLs with this filter_id
        links = LinkedInURL.objects(filter=filter_id)

        if not links:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No LinkedInURL entries found for filter_id: {filter_id}",
            )

        # ⚙️ Bulk update all matching links to 'pending'
        updated_count = links.update(set__status="pending")

        logger.info(
            f"User {user_data.get('email', 'unknown')} executed filter {filter_id}: "
            f"{updated_count} links marked as pending"
        )

        return {
            "status": "success",
            "message": f"{updated_count} links marked as pending",
            "filter_id": filter_id,
        }

    except MongoValidationError as e:
        logger.error(f"Mongo validation error while executing filter {filter_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid data in LinkedInURL collection: {str(e)}",
        )

    except DoesNotExist:
        logger.warning(f"No LinkedInURL found for filter_id: {filter_id}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No LinkedInURL found for filter_id {filter_id}",
        )

    except Exception as e:
        logger.exception(f"Unexpected error executing filter {filter_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while executing filter",
        )


# 🧱 Pydantic model for body validation
class ExecuteProfilesRequest(BaseModel):
    profile_ids: List[str]


@router.patch("/execute-profiles")
def execute_profiles(
    body: ExecuteProfilesRequest,
    user_data: dict = Depends(verify_token),
):
    """
    Execute profiles: sets LinkedInProfile status to 'pending' for given profile IDs.
    """
    try:
        # 🧩 Validate input
        if not body.profile_ids:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="No profile IDs provided in the request body.",
            )

        # 🧠 Fetch all matching profiles
        profiles = LinkedInURL.objects(id__in=body.profile_ids)

        if not profiles:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="No profiles found for the given IDs.",
            )

        # ⚙️ Bulk update
        updated_count = profiles.update(set__status="pending")

        logger.info(
            f"User {user_data.get('email', 'unknown')} executed profile update: "
            f"{updated_count} profiles marked as pending"
        )

        return {
            "status": "success",
            "message": f"{updated_count} profiles marked as pending",
            "updated_count": updated_count,
            "profile_ids": body.profile_ids,
        }

    except MongoValidationError as e:
        logger.error(f"Mongo validation error while executing profile update: {e}")
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid data in LinkedInProfile collection: {str(e)}",
        )

    except DoesNotExist:
        logger.warning("Some provided profile IDs do not exist.")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="One or more profile IDs not found.",
        )

    except Exception as e:
        logger.exception(f"Unexpected error executing profile update: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Internal server error while executing profile update.",
        )
