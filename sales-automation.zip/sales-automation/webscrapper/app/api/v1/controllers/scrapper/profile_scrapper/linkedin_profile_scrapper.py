import asyncio
import json
from functools import partial
from uuid import uuid1

from fastapi import APIRouter, Depends, status
from fastapi.responses import JSONResponse

from ......core.config import db_conn
from ......database.profile_data_schema import ProfileScraping
from ......services.scrapper_service.traditional_scrapper.profile_scrapper_service import (
    TraditionalProfileScrapper,
)
from ......services.utils.log import logger
from .profile_scrapper_schemas.profile_response_schema import ProfileResponse
from .profile_scrapper_schemas.profile_scrapper_schema import ProfileRequest

router = APIRouter()


def get_scrapper():
    return TraditionalProfileScrapper()


@router.post(
    "/profile-scrapper",
    response_model=ProfileResponse,
    responses={
        500: {
            "description": "Internal Server Error",
            "content": {
                "application/json": {"example": {"detail": "Something went wrong"}}
            },
        },
        400: {
            "description": "Bad Request",
            "content": {"application/json": {"example": {"detail": "Invalid input"}}},
        },
    },
)
async def linkedin_scrapper(
    request: ProfileRequest,
    profile_scrapper: TraditionalProfileScrapper = Depends(get_scrapper),
):
    """
    Extract details from a LinkedIn profile.
    """
    url = request.profile_url
    cookies = request.cookies

    try:
        if not db_conn.is_connected():
            db_conn.connect()

        logger.debug(f"Checking profile availability in database for URL >> {url}")
        profile_name = profile_scrapper._get_name(url)
        profile_doc = ProfileScraping.objects(profile_name=profile_name).first()

        if profile_doc and profile_doc.profileData:
            logger.info(f"Profile found in database >> {profile_name}")
            try:
                company_data = (
                    json.loads(profile_doc.companyData)
                    if profile_doc.companyData
                    else {}
                )
                score_data = (
                    json.loads(profile_doc.scoringData)
                    if profile_doc.scoringData
                    else {}
                )

                logger.debug(
                    f"Returning cached profile data for profile >> {profile_name}"
                )
                return JSONResponse(
                    {
                        "profile_data": json.loads(profile_doc.profileData),
                        "company_data": company_data,
                        "score_data": score_data,
                    },
                    status_code=status.HTTP_200_OK,
                )
            except Exception as e:
                logger.error(
                    f"Error while parsing cached profile data for {profile_name} >> {e}"
                )
                return JSONResponse(
                    {"message": "Failed to fetch profile data from database."},
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                )

        logger.info(f"Profile not found in database. Triggering scrapper for >> {url}")
        profile_data = await asyncio.to_thread(
            partial(
                profile_scrapper,
                cookies=cookies,
                login_url="https://www.linkedin.com/login",
                profile_url=url,
                session_name=str(uuid1()),
                headless=True,
                is_login_required=True,
            )
        )

        logger.info(f"Scraping completed successfully for profile >> {url}")
        return JSONResponse(
            {
                "profile_data": profile_data,
                "company_data": {},
                "score_data": {},
            },
            status_code=status.HTTP_200_OK,
        )

    except Exception as e:
        logger.error(f"Unhandled error while scraping LinkedIn profile {url} >> {e}")
        return JSONResponse(
            {"message": "Something went wrong while processing the profile."},
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        )
