from datetime import date
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class CookieUpdateRequest(BaseModel):
    username: Optional[str] = Field(
        None, description="Username of the LinkedIn account"
    )
    cookies: List[Dict[str, Any]] = Field(..., description="List of LinkedIn cookies")
    linkedin_url: Optional[str] = Field(
        "", description="LinkedIn profile URL (optional)"
    )


class FilterBody(BaseModel):
    filter_name: str

    class Config:
        json_schema_extra = {"example": {"filter_name": ""}}


class EditFilter(BaseModel):
    filter_name: str
    filter_id: str

    class Config:
        json_schema_extra = {
            "example": {
                "filter_name": "",
                "filter_id": "",
            }
        }


class DeleteFilters(BaseModel):
    filters_ids: List[str] = Field(
        ..., description="List of filter IDs to delete"  # required
    )


class FilterRequest(BaseModel):
    person_titles: Optional[List[str]] = Field(
        default=None,
        description="Job titles held by the people you want to find. For a person to be included in search results, they only need to match 1 of the job titles you add. Adding more job titles expands your search results.",
    )
    include_similar_titles: Optional[bool] = None
    q_keywords: Optional[str] = None
    person_locations: Optional[List[str]] = None
    person_seniorities: Optional[List[str]] = None
    q_organization_domains_list: Optional[List[str]] = None
    contact_email_status: Optional[List[str]] = None
    organization_ids: Optional[List[str]] = None
    organization_num_employees_ranges: Optional[List[str]] = None
    revenue_range_min: Optional[int] = None
    revenue_range_max: Optional[int] = None
    currently_using_all_of_technology_uids: Optional[List[str]] = None
    currently_using_any_of_technology_uids: Optional[List[str]] = None
    currently_not_using_any_of_technology_uids: Optional[List[str]] = None
    q_organization_job_titles: Optional[List[str]] = None
    organization_job_locations: Optional[List[str]] = None
    organization_num_jobs_range_min: Optional[int] = None
    organization_num_jobs_range_max: Optional[int] = None
    organization_job_posted_at_range_min: Optional[str] = None
    organization_job_posted_at_range_max: Optional[str] = None
    page: Optional[int] = None
    per_page: Optional[int] = None


class RangeInt(BaseModel):
    min: Optional[int] = None
    max: Optional[int] = None


class DateRange(BaseModel):
    min: Optional[date] = None
    max: Optional[date] = None


class CompanySearchParams(BaseModel):
    organization_num_employees_ranges: Optional[List[str]] = Field(default=None)
    organization_locations: Optional[List[str]] = None
    organization_not_locations: Optional[List[str]] = None

    revenue_range: Optional[RangeInt] = None
    currently_using_any_of_technology_uids: Optional[List[str]] = None

    q_organization_keyword_tags: Optional[List[str]] = None
    q_organization_name: Optional[str] = None
    organization_ids: Optional[List[str]] = None

    latest_funding_amount_range: Optional[RangeInt] = None
    total_funding_range: Optional[RangeInt] = None
    latest_funding_date_range: Optional[DateRange] = None

    q_organization_job_titles: Optional[List[str]] = None
    organization_job_locations: Optional[List[str]] = None
    organization_num_jobs_range: Optional[RangeInt] = None
    organization_job_posted_at_range: Optional[DateRange] = None

    page: int = 1
    per_page: int = 10
