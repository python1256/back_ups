from fastapi import APIRouter, Request
from fastapi.exceptions import FastAPIError, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from .....services.utils.log import logger

router = APIRouter()

templates = Jinja2Templates(directory="templates")


@router.get("/", response_class=HTMLResponse)
async def guidepage(request: Request):
    try:
        return templates.TemplateResponse("index.html", {"request": request})
    except FastAPIError as ferr:
        logger.error(ferr)
    except HTTPException as httperr:
        logger.error(httperr)
    except Exception as e:
        logger.error(e)
