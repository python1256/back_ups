from fastapi import APIRouter
from fastapi.responses import JSONResponse

router = APIRouter()


@router.get("/ready")
async def ready():
    """
    Readiness probe endpoint that checks critical dependencies.
    Returns 200 if the service is ready to accept traffic.
    Returns 503 if any critical dependency is unavailable.
    """

    return JSONResponse({"status": "ready"})


@router.get("/health")
async def health():
    """
    Health check endpoint that verifies service health.
    Returns 200 if the service is healthy.
    Always returns 200 unless the service itself has problems.
    """
    return JSONResponse({"status": "healthy"})
