from pydantic import BaseModel, EmailStr, Field


class ActivateAccountRequest(BaseModel):
    linkedin_url: str


class LoginData(BaseModel):
    email: str = Field(..., description="user name is user email.")
    password: str


class RegisterData(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(..., min_length=6)
    linkedin_url: str
    cookies: str = Field(default="{}")


class AuthResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = Field(default="bearer")


class RefreshTokenRequest(BaseModel):
    refresh_token: str
