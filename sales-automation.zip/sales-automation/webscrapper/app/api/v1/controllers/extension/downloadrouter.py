import os
import shutil

from fastapi import APIRouter, status
from fastapi.exceptions import HTTPException
from fastapi.responses import Response, StreamingResponse

from .....services.utils.log import logger

router = APIRouter()
BUILD_DIR = os.path.join(os.getcwd(), "extension")
ZIP_PATH = os.path.join(os.getcwd(), "extension.zip")


@router.get(
    "/download-extension",
    responses={
        200: {
            "content": {"application/zip": {}},
            "description": "Returns a ZIP file attachment",
            "headers": {
                "Content-Disposition": {
                    "description": "Attachment with filename",
                    "schema": {
                        "type": "string",
                        "example": "attachment; filename=extension.zip",
                    },
                }
            },
        }
    },
    # Prevent FastAPI from showing JSON response in docs
    response_class=StreamingResponse,
    tags=["Extension"],
    summary="Download Chrome Extension",
)
async def download_extension():
    try:
        logger.info("Received request to download chrome extension")
        try:
            shutil.make_archive(ZIP_PATH.replace(".zip", ""), "zip", BUILD_DIR)
            with open(ZIP_PATH, "rb") as f:
                zip_data = f.read()
            logger.info("Successfully created and cached extension zip")
        except Exception as e:
            logger.error(f"Failed to create extension archive: {str(e)}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create extension package",
            )

        if not zip_data:
            logger.error("Extension data not found..")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Extension not found"
            )

        logger.info("Successfully returning extension zip file")
        return Response(
            content=zip_data,
            media_type="application/zip",
            headers={"Content-Disposition": "attachment; filename=extension.zip"},
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.critical(
            f"Unexpected error in download-extension: {str(e)}", exc_info=True
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="An unexpected error occurred while processing your request",
        )
