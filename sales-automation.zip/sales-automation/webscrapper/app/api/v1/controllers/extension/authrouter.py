import json
from datetime import datetime, timezone

import requests
from bson import ObjectId
from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response
from fastapi.responses import JSONResponse, RedirectResponse

from .....core.config import (
    CLIENT_ID,
    CLIENT_SECRET,
    KEY_NAME,
    REDIRECT_URI,
    URL_REDIRECT,
    db_conn,
    set_access_cookie,
)
from .....database.profile_data_schema import Account
from .....repository.account_repository import AccountRepository
from .....services.auth_services.auth_service import (
    login_user,
    refresh_user_token,
    register_user,
    verify_user_token,
)
from .....services.utils.log import logger
from .extension_schema.auth_response_schema import (
    ActivateAccountRequest,
    AuthResponse,
    LoginData,
    RefreshTokenRequest,
    RegisterData,
)

router = APIRouter()


# @router.post(
#     "/login",
#     response_model=AuthResponse,
#     responses={
#         400: {"description": "Invalid input"},
#         401: {"description": "Invalid credentials"},
#         500: {"description": "Server error"},
#     },
# )
# def login(data: LoginData, response: Response):
#     """Generate access and refresh tokens."""
#     if not db_conn.is_connected():
#         db_conn.connect()

#     auth = login_user(data.email, data.password, "manual")

#     response.set_cookie(
#         key="access_token",
#         value=auth.get("access_token"),
#         httponly=True,
#         secure=False,  # True if using HTTPS
#         samesite="none",
#         max_age=3600,
#         domain="http://localhost:3157",
#     )

#     return auth


# @router.post("/register")
# def register(data: RegisterData):
#     """Register new user."""
#     if not db_conn.is_connected():
#         db_conn.connect()

#     return register_user(
#         data.username,
#         data.email,
#         data.password,
#         data.linkedin_url,
#         data.cookies,
#     )


LINKEDIN_USERINFO_URL = "https://api.linkedin.com/v2/userinfo"


@router.get("/me")
async def verify_token(request: Request):
    """Verify LinkedIn OAuth token or internal JWT token from cookie/header."""

    if not db_conn.is_connected():
        db_conn.connect()

    token = None
    # 1️⃣ Try header first
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        token = auth_header.split(" ")[1].strip()

    # 2️⃣ Then fallback to cookie (only if header missing or empty)
    if not token:
        cookie_token = request.cookies.get(KEY_NAME)
        if cookie_token and cookie_token.strip():
            token = cookie_token.strip()

    # 3️⃣ If still missing or empty, reject
    if not token:
        logger.error("Missing or empty token.")
        return JSONResponse(
            status_code=401, content={"message": "Missing or empty token."}
        )

    # 4️⃣ Validate LinkedIn token
    try:
        # linkedin_resp_me = requests.get(
        #     "https://api.linkedin.com/v2/me",
        #     headers={"Authorization": f"Bearer {token}"},
        #     timeout=5,
        # )

        # print("me api", linkedin_resp_me.json())

        linkedin_resp = requests.get(
            LINKEDIN_USERINFO_URL,
            headers={"Authorization": f"Bearer {token}"},
            timeout=5,
        )

        if linkedin_resp.status_code == 200:
            data = linkedin_resp.json()
            account_doc = AccountRepository.get_by_email(
                data["email"]
            )  # Account.objects(is_delete=False, email=data["email"]).first()

            if not account_doc:
                return JSONResponse(
                    status_code=404, content={"message": "Account not found."}
                )
            is_froze = False
            if account_doc.status == "freeze":
                is_froze = True

            return {
                "data": data,
                "email": account_doc.email,
                "id": str(account_doc.id),
                "is_frozen": is_froze,
            }

        # LinkedIn returned invalid/expired token
        return JSONResponse(
            status_code=401, content={"message": "Invalid or expired LinkedIn token"}
        )

    except requests.RequestException as e:
        logger.error(f"LinkedIn verification failed: {e}.")
        return JSONResponse(
            status_code=500, content={"message": f"LinkedIn verification failed: {e}."}
        )


# Define a request body model


@router.post(
    "/refresh",
    responses={
        400: {"description": "Invalid input"},
        401: {"description": "Invalid or expired refresh token"},
        500: {"description": "Server error"},
    },
)
def refresh_token(data: RefreshTokenRequest):
    """Refresh access token using refresh token."""
    if not db_conn.is_connected():
        db_conn.connect()

    try:
        return refresh_user_token(data.refresh_token)
    except Exception as e:
        logger.error(f"Token refresh failed: {e}")
        raise HTTPException(status_code=401, detail="Invalid or expired refresh token")


@router.get("/linkedin/login")
def linkedin_login():
    """Redirect user to LinkedIn authorization page."""

    linkedin_auth_url = (
        "https://www.linkedin.com/oauth/v2/authorization"
        f"?response_type=code"
        f"&client_id={CLIENT_ID}"
        f"&redirect_uri={REDIRECT_URI}"
        f"&scope=email%20profile%20openid%20"
    )
    return {"auth_url": linkedin_auth_url}


@router.get("/linkdin-auth-callback")
def linkedin_callback(code: str = Query(...)):
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        # Step 1: Exchange authorization code for access token
        token_response = requests.post(
            "https://www.linkedin.com/oauth/v2/accessToken",
            data={
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": REDIRECT_URI,
                "client_id": CLIENT_ID,
                "client_secret": CLIENT_SECRET,
            },
        )
        token_data = token_response.json()
        access_token = token_data.get(KEY_NAME)

        if not access_token:
            raise HTTPException(
                status_code=400, detail="Failed to obtain LinkedIn access token"
            )

        # Step 2: Fetch user profile data
        headers = {"Authorization": f"Bearer {access_token}"}

        profile_res = requests.get(
            "https://api.linkedin.com/v2/userinfo",  # new LinkedIn OpenID Connect endpoint
            headers=headers,
        )

        if profile_res.status_code != 200:
            raise HTTPException(
                status_code=400, detail="Failed to fetch LinkedIn user info"
            )

        profile_data = profile_res.json()
        email = profile_data.get("email")
        username = (
            profile_data.get("name") or profile_data.get("email", "").split("@")[0]
        )

        # Step 3: Check if account exists
        account = AccountRepository.get_by_email(
            email=email
        )  # Account.objects(email=email, is_delete=False).first()

        if not account:
            # 🆕 New user → create entry
            account = AccountRepository.create_account(
                username=username,
                email=email,
                cookies=json.dumps({}),
                linkedin_url="",
                password_hash="",  # leave blank if login via LinkedIn only
                status="freeze",
                createdAt=datetime.now(timezone.utc),
                updatedAt=datetime.now(timezone.utc),
            )
            account.save()
        else:
            account.updatedAt = datetime.now(timezone.utc)
            account.save()

        # Step 4: Redirect back to frontend with cookie set
        redirect_url = f"{URL_REDIRECT}/linkedin-success"
        response = RedirectResponse(url=redirect_url, status_code=302)

        set_access_cookie(response=response, access_token=access_token)

        return response

    except Exception as e:
        import logging

        logger = logging.getLogger(__name__)
        logger.error(f"LinkedIn auth error: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get("/linkedin-success")
def linkedin_success():
    return RedirectResponse(
        "https://salesfrontend.aspiresoftware.in/linkedin-auth-success"
    )


@router.patch("/account-activate")
def account_activate(body: ActivateAccountRequest, user_data=Depends(verify_token)):
    # Validate ObjectId
    if not db_conn.is_connected():
            db_conn.connect()
    user_id = user_data.get("id")
    if not ObjectId.is_valid(user_id):
        logger.error("Invalid account ID.")
        return JSONResponse(status_code=400, content={"message": "Invalid account ID"})

    # Fetch the account document
    account_doc = AccountRepository.get_by_id(id=user_id)
    if not account_doc:
        logger.error("Account not found.")
        return JSONResponse(status_code=404, content={"message": "Account not found."})

    # Update account fields
    account_doc.status = "active"
    account_doc.linkedin_url = body.linkedin_url
    account_doc.save()

    return JSONResponse(
        status_code=200,
        content={
            "message": "Account activated successfully.",
            "account_id": str(account_doc.id),
            "status": account_doc.status,
            "linkedin_url": account_doc.linkedin_url,
        },
    )


@router.post("/logout")
def logout():
    """
    Log out the user by clearing the access_token cookie.
    """
    response = JSONResponse(content={"message": "Logged out successfully"})

    # Clear the cookie by setting it to empty and expiring immediately
    response.delete_cookie(
        key=KEY_NAME,
        httponly=True,
        samesite="lax",
        secure=False,  # set to True if using HTTPS
        path="/",
    )

    return response


@router.delete("/account-delete")
def account_delete(user_data=Depends(verify_token)):
    """Soft delete the currently authenticated user's account."""
    user_id = user_data.get("id")

    # Validate ID
    if not ObjectId.is_valid(user_id):
        raise HTTPException(status_code=400, detail="Invalid account ID")

    # Fetch account
    account_doc = AccountRepository.get_by_id(id=user_id)
    if not account_doc:
        raise HTTPException(
            status_code=404, detail="Account not found or already deleted"
        )

    # Soft delete
    account_doc.is_delete = True
    account_doc.status = "freeze"
    account_doc.updatedAt = datetime.now(timezone.utc)
    account_doc.save()
    response = JSONResponse(
        status_code=200,
        content={
            "message": "Account soft deleted successfully.",
        },
    )
    response.delete_cookie(
        key=KEY_NAME,
        httponly=True,
        samesite="lax",
        secure=False,  # set to True if using HTTPS
        path="/",
    )

    return response
