import asyncio
import json
from datetime import datetime, timezone
from functools import partial
from urllib.parse import urlparse

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import JSONResponse
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

from .....core.config import db_conn, llm
from .....database.profile_data_schema import ProfileScraping
from .....services.scrapper_service.ai_scrapper_service.score_service import (
    AIScoreGenerator,
)
from .....services.utils.log import logger
from .content_writer_schemas.content_writer_schema import (
    ContentRequest,
    DecisionRequest,
)

router = APIRouter()


def _get_generator():
    return AIScoreGenerator()


def get_name(url: str) -> str:
    """
    Extracts the profile name from a LinkedIn profile URL.
    """
    parsed_url = urlparse(url=url)
    path_parts = parsed_url.path.strip("/").split("/")

    if len(path_parts) >= 2 and path_parts[0] == "in":
        return path_parts[1]

    return ""


@router.post("/write-content")
async def content_write(request: ContentRequest):
    try:
        logger.info("Received content generation request")
        print(request.content_type)

        # Define dynamic content-specific instructions
        CONTENT_TYPE_INSTRUCTIONS = {
            "e-mail": """
**Format for Email:**
- Include: Subject, Greeting, Body, CTA, and Closing.
- Maintain a professional but warm tone.
- Make it persuasive, value-driven, and relevant to the recipient's role.
""",
            "blog": """
**Format for Blog:**
- Include: Title, Introduction, Subheadings, and Conclusion.
- Informative and structured; maintain flow and readability.
- Focus on storytelling, examples, and insights.
""",
            "ads": """
**Format for Advertisement/Social Media:**
- Short, catchy, and benefit-driven (1–3 lines max).
- Highlight key value or offer.
- Friendly, energetic tone.
""",
            "whatsapp": """
**Format for WhatsApp Message:**
- Short (2–4 sentences max), conversational tone.
- Start with a quick greeting, mention a value or offer, and end with a CTA.
- Use emojis sparingly if tone allows.
""",
            "sms": """
**Format for SMS:**
- Very short (max 160 characters, 1–2 sentences).
- No emojis or greetings unless essential.
- Clear CTA (e.g., link or contact action).
""",
        }

        # 🔹 Pick instruction dynamically (default to email format)
        content_type_key = request.content_type.lower().strip()
        content_instruction = CONTENT_TYPE_INSTRUCTIONS.get(
            content_type_key, CONTENT_TYPE_INSTRUCTIONS["e-mail"]
        )

        content_writer_template = f"""
You are a professional business content creator.
Generate personalized business content using the input JSON below.

### Input JSON:
"tone": {{tone}},
"content_type": {{content_type}},
"content_length": {{content_length}},
"company_details": {{company_details}},
"person_details": {{person_details}},
"value_propositions": {{value_propositions}},
"writing_styles": {{writing_styles}},
"sales_assets": {{sales_assets}}

### General Instructions:
1. Tailor the message for the person in **person_details**.
2. Use **company_details** to align product/services with their pain points.
3. Optionally integrate **value_propositions**, **writing_styles**, and **sales_assets**.
4. Match the **tone** and **content_length** properly.

### Content-Type Specific Rules:
{content_instruction}

Return only a valid JSON object — no explanations, notes, or Markdown code fences.
Use this exact structure:
```json
{{{{ 
    "title": "<Title or Subject if applicable>",
    "content": "<Generated Content>"
}}}}
"""

        # 🔹 Build LLM chain
        content_writer_prompt = ChatPromptTemplate.from_messages(
            [("system", content_writer_template), ("user", "{company_details}")]
        )
        content_writer_chain = content_writer_prompt | llm | StrOutputParser()

        logger.debug(
            f"Invoking LLM with tone={request.tone}, type={request.content_type}"
        )

        # 🔹 Convert MongoEngine docs safely to dicts
        value_props_json = [
            vp.to_mongo().to_dict() for vp in request.value_propositions
        ]
        writing_styles_json = [ws.to_mongo().to_dict() for ws in request.writing_styles]
        sales_assets_json = [sa.to_mongo().to_dict() for sa in request.sales_assets]

        # 🔹 Invoke model
        content_response = content_writer_chain.invoke(
            {
                "tone": request.tone,
                "content_type": request.content_type,
                "content_length": request.content_length,
                "company_details": json.dumps(request.company_details),
                "person_details": json.dumps(request.person_details),
                "value_propositions": json.dumps(value_props_json),
                "writing_styles": json.dumps(writing_styles_json),
                "sales_assets": json.dumps(sales_assets_json),
            }
        )

        logger.debug(f"Raw LLM response: {content_response}")

        # 🔹 Parse clean JSON safely
        json_content_response = json.loads(
            content_response.replace("```", "").replace("json", "").strip()
        )

        logger.info("Content generation successful")
        return JSONResponse(
            {"data": json_content_response}, status_code=status.HTTP_200_OK
        )

    except Exception as e:
        logger.error(f"Error while generating content: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error while generating content: {e}",
        )


@router.post("/predict-descision")
async def generate_decision(
    request: DecisionRequest, ai_generator: AIScoreGenerator = Depends(_get_generator)
):
    try:
        result = await asyncio.to_thread(
            partial(
                ai_generator._generate_business_decision,
                person_company=request.person_company,
                person_profile=request.person_profile,
                client_requirements=request.client_requirements,
                client_company=request.client_company,
            )
        )

        if not db_conn.is_connected():
            db_conn.connect()

        profile_name = get_name(url=request.profile_linkedin_url)
        _ = ProfileScraping.objects(profile_name=profile_name).modify(
            set__updatedAt=datetime.now(timezone.utc),
            set__decisionData=json.dumps(result, indent=4),
            set__decision_score=float(result["score"]),
            upsert=True,
        )
        return JSONResponse({"data": result}, status_code=status.HTTP_200_OK)
    except Exception as e:
        logger.error(f"Error while generate sales decision >> {e}")
        return JSONResponse(
            {"message": str(e)}, status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )
