import math
from typing import List, Optional

from bson import ObjectId
from fastapi import APIRouter, Body, Depends, HTTPException, Query
from mongoengine.errors import DoesNotExist, NotUniqueError

from .....core.config import db_conn
from .....database.models.content import SalesAssests
from .....services.utils.log import logger
from ..extension.authrouter import verify_token
from .content_writer_schemas.content_writer_schema import (
    SalesAssetCreateSchema,
    SalesAssetUpdateSchema,
)

router = APIRouter(prefix="/sales-assets", tags=["Sales Assets"])
ASSEST_NOT_FOUND = "Sales Asset not found."
NAME_ALREADY_EXITIS = "Sales Asset with this name already exists."


# ---------- UPDATE SALES ASSET (PARTIAL) ----------
@router.patch("/{sa_id}")
def update_sales_asset(
    sa_id: str,
    data: SalesAssetUpdateSchema = Body(...),
    user_data=Depends(verify_token),
):
    """
    Partially update an existing Sales Asset by ID.
    """
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        sa: SalesAssests = SalesAssests.objects.get(id=ObjectId(sa_id), is_delete=False)

        # Apply only provided fields
        update_fields = {}
        if data.name is not None:
            update_fields["name"] = data.name
        if data.content is not None:
            update_fields["content"] = data.content
        if data.description is not None:
            update_fields["description"] = data.description

        # If nothing provided, return early
        if not update_fields:
            raise HTTPException(
                status_code=400, detail="No valid fields provided for update"
            )

        # Update in database
        for field, value in update_fields.items():
            setattr(sa, field, value)

        sa.save()

        return {
            "message": "Sales Asset updated successfully",
            "data": {
                "id": str(sa.id),
                "name": sa.name,
                "content": sa.content,
                "createdAt": sa.createdAt.isoformat(),
                "updatedAt": sa.updatedAt.isoformat(),
            },
        }

    except DoesNotExist:
        logger.error(ASSEST_NOT_FOUND)
        raise HTTPException(status_code=404, detail=ASSEST_NOT_FOUND)
    except NotUniqueError:
        logger.error(NAME_ALREADY_EXITIS)
        raise HTTPException(status_code=400, detail=NAME_ALREADY_EXITIS)
    except Exception as e:
        logger.error(f"Error updating Sales Asset: {str(e)}.")
        raise HTTPException(status_code=400, detail=str(e))


# ---------- CREATE SALES ASSET ----------
@router.post("/")
def create_sales_asset(
    data: SalesAssetCreateSchema = Body(...), user_data=Depends(verify_token)
):
    """
    Create a new Sales Asset.
    """
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        sa: SalesAssests = SalesAssests(
            name=data.name, content=data.content, is_delete=False
        )
        sa.save()

        return {
            "message": "Sales Asset created successfully",
            "data": {
                "id": str(sa.id),
                "name": sa.name,
                "content": sa.content,
                "createdAt": sa.createdAt.isoformat(),
                "updatedAt": sa.updatedAt.isoformat(),
            },
        }

    except NotUniqueError:
        logger.error(NAME_ALREADY_EXITIS)
        raise HTTPException(status_code=400, detail=NAME_ALREADY_EXITIS)
    except Exception as e:
        logger.error(f"Error creating Sales Asset: {str(e)}.")
        raise HTTPException(status_code=400, detail=str(e))


# ---------- GET ALL SALES ASSETS ----------
@router.get("/")
def get_all_sales_assets(
    page: Optional[int] = Query(None, description="Page number for pagination"),
    q: Optional[str] = Query(None, description="Search by name or content"),
    user_data=Depends(verify_token),
):
    """
    Fetch all Sales Assets (for the authenticated user's account).
    - If 'page' is provided → paginated response.
    - If 'page' is None → return all.
    Supports optional search (q).
    """
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        # Base query
        query = SalesAssests.objects(is_delete=False).order_by("-createdAt")

        # Optional search filter
        if q and q.strip():
            query = query.filter(
                __raw__={
                    "$or": [
                        {"name": {"$regex": q, "$options": "i"}},
                        {"content": {"$regex": q, "$options": "i"}},
                    ]
                }
            )

        # If no 'page' param → return all records
        if page is None:
            assets = query
            data = [
                {
                    "id": str(sa.id),
                    "name": sa.name,
                    "content": sa.content,
                    "createdAt": sa.createdAt.isoformat(),
                    "updatedAt": sa.updatedAt.isoformat(),
                }
                for sa in assets
            ]
            return {
                "total_sales_assets": len(data),
                "data": data,
            }

        # Paginated response
        page_size = 5
        total_assets = query.count()
        total_pages = max(1, math.ceil(total_assets / page_size))
        page = min(page, total_pages)
        skip = (page - 1) * page_size

        assets = query.skip(skip).limit(page_size)

        data = [
            {
                "id": str(sa.id),
                "name": sa.name,
                "content": sa.content,
                "createdAt": sa.createdAt.isoformat(),
                "updatedAt": sa.updatedAt.isoformat(),
            }
            for sa in assets
        ]

        return {
            "page": page,
            "page_size": page_size,
            "total_sales_assets": total_assets,
            "totalPages": total_pages,
            "data": data,
        }

    except Exception as e:
        logger.error(f"Error fetching Sales Assets: {str(e)}.")
        raise HTTPException(status_code=500, detail="Failed to fetch sales assets")


# ---------- GET SINGLE SALES ASSET BY ID ----------
@router.get("/{sa_id}")
def get_sales_asset_by_id(sa_id: str, user_data=Depends(verify_token)):
    """
    Get a single Sales Asset by ID.
    """
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        sa: SalesAssests = SalesAssests.objects.get(is_delete=False, id=ObjectId(sa_id))
        return {
            "id": str(sa.id),
            "name": sa.name,
            "content": sa.content,
            "createdAt": sa.createdAt.isoformat(),
            "updatedAt": sa.updatedAt.isoformat(),
        }

    except DoesNotExist:
        logger.error(ASSEST_NOT_FOUND)
        raise HTTPException(status_code=404, detail=ASSEST_NOT_FOUND)
    except Exception as e:
        logger.error(f"Error fetching Sales Asset: {str(e)}.")
        raise HTTPException(status_code=400, detail=str(e))


# ---------- DELETE MULTIPLE SALES ASSETS ----------
@router.delete("/")
def delete_sales_assets(
    ids: List[str] = Body(..., embed=True), user_data=Depends(verify_token)
):
    """
    Soft delete multiple Sales Assets by IDs.
    Example request body:
    {
        "sa_ids": ["6720e93dcf245f84b9cc40d2", "6720e93dcf245f84b9cc40d3"]
    }
    """
    try:
        updated_count = 0
        for sa_id in ids:
            try:
                sa = SalesAssests.objects.get(id=ObjectId(sa_id))
                sa.is_delete = True
                sa.save()
                updated_count += 1
            except DoesNotExist:
                logger.warning(f"Sales Asset not found: {sa_id}")
                continue

        if updated_count == 0:
            raise HTTPException(
                status_code=404, detail="No valid Sales Assets found to delete."
            )

        return {"message": f"{updated_count} Sales Asset(s) deleted successfully."}

    except Exception as e:
        logger.error(f"Error deleting Sales Assets: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
