import math
from typing import List, Optional

from bson import ObjectId
from fastapi import APIRouter, Body, Depends, HTTPException, Query
from mongoengine.errors import DoesNotExist

from .....core.config import db_conn
from .....database.models.content import ValueProposition, ValuePropositionFilter
from .....services.utils.log import logger
from ..extension.authrouter import verify_token
from .content_writer_schemas.content_writer_schema import (
    ValuePropositionCreateSchema,
    ValuePropositionUpdateSchema,
)

router = APIRouter(prefix="/value-propositions", tags=["Value Proposition"])

VP_NOT_FOUND = "Value Proposition not found."


# ---------- UPDATE VALUE PROPOSITION (PARTIAL UPDATE) ----------
@router.patch("/{vp_id}")
def update_value_proposition(
    vp_id: str,
    data: ValuePropositionUpdateSchema = Body(...),
    user_data=Depends(verify_token),
):
    """
    Partially update a Value Proposition document.
    Only provided fields will be updated.
    """
    account_id = user_data.get("id")

    try:
        if not db_conn.is_connected():
            db_conn.connect()
        vp = ValueProposition.objects.get(
            id=ObjectId(vp_id), account_id=ObjectId(account_id), is_delete=False
        )

        # Apply updates only for fields present in request body
        if "persona" in data:
            vp.persona = data["persona"]

        if "buyer" in data:
            vp.buyer = data["buyer"]

        if "description" in data:
            vp.description = data["description"]

        if "filters" in data:
            # Support partial updates for filters subfields
            if not vp.filters:
                vp.filters = {}

            for key, value in data["filters"].items():
                if hasattr(vp.filters, key):
                    setattr(vp.filters, key, value)

        vp.save()

        return {
            "message": "Value Proposition updated successfully",
            "data": {
                "id": str(vp.id),
                "persona": vp.persona,
                "buyer": vp.buyer,
                "description": vp.description,
                "filters": vp.filters.to_mongo() if vp.filters else None,
                "updatedAt": vp.updatedAt.isoformat(),
            },
        }

    except DoesNotExist:
        raise HTTPException(status_code=404, detail="Value Proposition not found")
    except Exception as e:
        logger.error(f"Error updating Value Proposition: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/")
def create_value_proposition(
    data: ValuePropositionCreateSchema = Body(...), user_data=Depends(verify_token)
):
    """
    Create a new Value Proposition document.
    """
    account_id = user_data.get("id")

    try:
        if not db_conn.is_connected():
            db_conn.connect()
        vp: ValueProposition = ValueProposition(
            persona=data.persona,
            buyer=data.buyer,
            filters=(
                ValuePropositionFilter(**data.filters.model_dump())
                if data.filters
                else None
            ),
            account_id=account_id,
            description=data.description,
        )
        vp.save()

        return {
            "message": "Value Proposition created successfully",
            "data": {
                "id": str(vp.id),
                "persona": vp.persona,
                "buyer": vp.buyer,
                "description": vp.description,
                "createdAt": vp.createdAt.isoformat(),
            },
        }
    except Exception as e:
        logger.error(f"Error creating Value Proposition: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))


# ---------- GET ALL VALUE PROPOSITIONS ----------
@router.get("/")
def get_all_value_propositions(
    page: Optional[int] = Query(None, description="Page number for pagination"),
    q: Optional[str] = Query(
        None, description="Search by persona, buyer, or description"
    ),
    user_data=Depends(verify_token),
):
    """
    Fetch Value Propositions for the authenticated user's account.
    - If 'page' is provided → paginated response.
    - If 'page' is None → return all.
    Supports optional search (q).
    """
    account_id = user_data.get("id")

    try:
        # Base query
        if not db_conn.is_connected():
            db_conn.connect()
        query = ValueProposition.objects(account_id=ObjectId(account_id))

        # Apply search filter if 'q' is provided
        REGEX = "$regex"
        REGEX_OPTIONS = "$options"

        if q and q.strip():
            filter_value = {REGEX: q, REGEX_OPTIONS: "i"}
            query = query.filter(
                __raw__={
                    "$or": [
                        {"persona": filter_value},
                        {"buyer": filter_value},
                        {"description": filter_value},
                    ]
                }
            )

        # If no 'page' param → return all records
        if page is None:
            vps = query.order_by("-createdAt")
            data = [
                {
                    "id": str(vp.id),
                    "persona": vp.persona,
                    "buyer": vp.buyer,
                    "description": vp.description,
                    "filters": vp.filters.to_mongo() if vp.filters else None,
                    "createdAt": vp.createdAt.isoformat(),
                    "updatedAt": vp.updatedAt.isoformat(),
                }
                for vp in vps
            ]
            return {
                "account_id": account_id,
                "total_value_propositions": len(data),
                "data": data,
            }

        # Paginated response
        page_size = 5
        total_vps = query.count()
        total_pages = max(1, math.ceil(total_vps / page_size))
        page = min(page, total_pages)
        skip = (page - 1) * page_size

        vps = query.order_by("-createdAt").skip(skip).limit(page_size)

        data = [
            {
                "id": str(vp.id),
                "persona": vp.persona,
                "buyer": vp.buyer,
                "description": vp.description,
                "filters": vp.filters.to_mongo() if vp.filters else None,
                "createdAt": vp.createdAt.isoformat(),
                "updatedAt": vp.updatedAt.isoformat(),
            }
            for vp in vps
        ]

        return {
            "account_id": account_id,
            "page": page,
            "page_size": page_size,
            "total_value_propositions": total_vps,
            "totalPages": total_pages,
            "data": data,
        }

    except Exception as e:
        logger.error(f"Error fetching Value Propositions: {str(e)}")
        raise HTTPException(
            status_code=500, detail="Failed to fetch value propositions"
        )


# ---------- GET SINGLE VALUE PROPOSITION BY ID ----------
@router.get("/{vp_id}")
def get_value_proposition_by_id(vp_id: str, user_data=Depends(verify_token)):
    """
    Get a single Value Proposition by ID.
    """
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        vp: ValueProposition = ValueProposition.objects.get(
            id=ObjectId(vp_id), is_delete=False
        )
        return {
            "id": str(vp.id),
            "persona": vp.persona,
            "buyer": vp.buyer,
            "description": vp.description,
            "filters": vp.filters.to_mongo() if vp.filters else None,
            "createdAt": vp.createdAt.isoformat(),
            "updatedAt": vp.updatedAt.isoformat(),
        }

    except DoesNotExist:
        logger.error(VP_NOT_FOUND)
        raise HTTPException(status_code=404, detail=VP_NOT_FOUND)
    except Exception as e:
        logger.error(f"Error fetching Value Proposition: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))


@router.delete("/")
def delete_value_propositions(
    ids: List[str] = Body(..., embed=True), user_data=Depends(verify_token)
):
    """
    Soft delete multiple Value Propositions by IDs.
    Example request body:
    {
        "vp_ids": ["6720e93dcf245f84b9cc40d2", "6720e93dcf245f84b9cc40d3"]
    }
    """
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        updated_count = ValueProposition.objects(
            id__in=[ObjectId(vp_id) for vp_id in ids]
        ).update(set__is_delete=True)

        if updated_count == 0:
            raise HTTPException(
                status_code=404, detail="No valid Value Propositions found to delete"
            )

        return {"message": f"{updated_count} Value Proposition(s) deleted successfully"}

    except Exception as e:
        logger.error(f"Error deleting Value Propositions: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
