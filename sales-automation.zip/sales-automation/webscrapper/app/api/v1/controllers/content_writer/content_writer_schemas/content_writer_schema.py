import re
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field, field_validator


class ValuePropSchema(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None


class WritingStyleSchema(BaseModel):
    style: Optional[str] = None
    sample_content: Optional[str] = None
    audience: Optional[str] = None
    max_words: Optional[str] = None


class SalesAssetSchema(BaseModel):
    name: Optional[str] = None
    content: Optional[str] = None


class ContentRequest(BaseModel):
    company_details: Dict
    person_details: Dict
    tone: str = Field(default="professional")
    content_type: str = Field(default="e-mail")
    content_length: str = Field(default="medium")

    value_propositions: Optional[List[ValuePropSchema]] = Field(default_factory=list)
    writing_styles: Optional[List[WritingStyleSchema]] = Field(default_factory=list)
    sales_assets: Optional[List[SalesAssetSchema]] = Field(default_factory=list)

    class Config:
        json_schema_extra = {
            "example": {
                "tone": "professional",
                "content_type": "e-mail",
                "content_length": "medium",
                "company_details": {},
                "person_details": {},
                "value_propositions": [{"title": "Time-saving", "description": ""}],
                "writing_styles": [
                    {
                        "style": "Formal",
                        "sample_content": " ",
                        "audience": "",
                        "max_words": 34,
                    }
                ],
                "sales_assets": [{"name": "Product Brochure", "content": ""}],
            }
        }


def sanitize_value(value: Any) -> Any:
    """Sanitize individual values recursively."""
    if isinstance(value, dict):
        return sanitize_dict(value)
    elif isinstance(value, list):
        return [sanitize_value(v) for v in value]
    elif isinstance(value, str):
        # Strip out HTML/script tags
        safe_val = re.sub(r"<[^>]*>", "", value)
        return safe_val.strip()
    elif isinstance(value, (int, float, bool, type(None))):
        return value
    else:
        raise ValueError(f"Invalid value type: {type(value)}")


def sanitize_dict(data: Dict[str, Any]) -> Dict[str, Any]:
    """Sanitize dict keys and values recursively."""
    if not isinstance(data, dict):
        raise ValueError("Expected a dictionary")

    clean_dict = {}
    for k, v in data.items():
        if not isinstance(k, str):
            raise ValueError("Keys must be strings")

        # Sanitize key
        safe_key = re.sub(r"[<>]", "", k)
        clean_dict[safe_key] = sanitize_value(v)

    return clean_dict


class DecisionRequest(BaseModel):
    person_company: Dict[str, Any]
    person_profile: Dict[str, Any]
    client_requirements: Dict[str, Any]
    client_company: Dict[str, Any]
    profile_linkedin_url: str

    @field_validator(
        "person_company",
        "person_profile",
        "client_requirements",
        "client_company",
        mode="before",
    )
    def validate_and_sanitize(cls, v):
        return sanitize_dict(v)

    class Config:
        json_schema_extra = {
            "example": {
                "profile_linkedin_url": "<linkedin profile url>",
                "person_company": {"name": "Acme Corp", "industry": "Software"},
                "person_profile": {"name": "John Doe", "skills": ["AI", "ML"]},
                "client_requirements": {
                    "technology_stack": {
                        "primary": ["MERN (MongoDB, Express, React, Node.js)"],
                        "secondary": ["System Integration (SI) technologies"],
                    },
                    "company_values": {
                        "enthusiasm": "We love building innovative products.",
                        "collaboration": "We welcome new clients and partnerships.",
                    },
                },
                "client_company": {"name": "Tech Innovators", "location": "India"},
            }
        }


class SalesAssetCreateSchema(BaseModel):
    name: str = Field(..., description="Name of the sales asset")
    content: Optional[str] = Field(
        None, description="Content or description of the sales asset"
    )


# ------------------------------
# Update Schema
# ------------------------------
class SalesAssetUpdateSchema(BaseModel):
    name: Optional[str] = Field(None, description="Name of the sales asset")
    content: Optional[str] = Field(
        None, description="Content or description of the sales asset"
    )


class ValuePropositionFilterSchema(BaseModel):
    job_title: Optional[Union[str, List[str]]] = Field(
        default_factory=list, description="Job title or list of job titles"
    )
    department: Optional[List[str]] = Field(
        default_factory=list, description="Departments"
    )
    seniority_level: Optional[List[str]] = Field(
        default_factory=list, description="Seniority levels"
    )
    industry: Optional[List[str]] = Field(
        default_factory=list, description="Industries"
    )


# ------------------------------
# Create Schema
# ------------------------------
class ValuePropositionCreateSchema(BaseModel):
    persona: Optional[List[str]] = Field(
        default_factory=list,
        description="Personas associated with the value proposition",
    )
    buyer: str = Field(..., description="Buyer persona or type")
    filters: Optional[ValuePropositionFilterSchema] = None
    description: Optional[str] = Field(
        None, description="Description of the value proposition"
    )


# ------------------------------
# Update Schema
# ------------------------------
class ValuePropositionUpdateSchema(BaseModel):
    persona: Optional[List[str]] = Field(
        default=None, description="Personas associated with the value proposition"
    )
    buyer: Optional[str] = Field(None, description="Buyer persona or type")
    filters: Optional[ValuePropositionFilterSchema] = None
    description: Optional[str] = Field(
        None, description="Description of the value proposition"
    )


class WritingStyleCreateSchema(BaseModel):
    style: Optional[str] = Field(None, description="The name or type of writing style")
    sample_content: Optional[str] = Field(
        None, description="Example content for this style"
    )
    audience: Optional[str] = Field(None, description="Target audience")
    max_words: Optional[int] = Field(None, description="Maximum allowed words")


# ------------------------------
# Update Schema
# ------------------------------
class WritingStyleUpdateSchema(BaseModel):
    style: Optional[str] = Field(None, description="The name or type of writing style")
    sample_content: Optional[str] = Field(
        None, description="Example content for this style"
    )
    audience: Optional[str] = Field(None, description="Target audience")
    max_words: Optional[int] = Field(None, description="Maximum allowed words")
