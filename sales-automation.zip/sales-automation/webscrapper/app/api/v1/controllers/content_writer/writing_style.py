import math
from typing import List, Optional

from bson import ObjectId
from fastapi import APIRouter, Body, Depends, HTTPException, Query
from mongoengine.errors import DoesNotExist

from .....core.config import db_conn
from .....database.models.content import WritingStyle
from .....services.utils.log import logger
from ....v1.controllers.extension.authrouter import verify_token  # Adjust if needed
from .content_writer_schemas.content_writer_schema import (
    WritingStyleCreateSchema,
    WritingStyleUpdateSchema,
)

router = APIRouter(prefix="/writing-styles", tags=["Writing Style"])
WS_NOT_FOUND = "Writing Style not found."


@router.patch("/{ws_id}")
def update_writing_style(
    ws_id: str,
    data: WritingStyleUpdateSchema = Body(...),
    user_data=Depends(verify_token),
):
    """
    Partially update a Writing Style by ID.
    Only the provided fields will be updated.
    """
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        ws: WritingStyle = WritingStyle.objects.get(id=ObjectId(ws_id), is_delete=False)

        update_data = data.dict(exclude_unset=True)  # only update fields provided

        for field, value in update_data.items():
            setattr(ws, field, value)

        ws.save()

        return {
            "message": "Writing Style updated successfully",
            "data": {
                "id": str(ws.id),
                "style": ws.style,
                "sample_content": ws.sample_content,
                "audience": ws.audience,
                "max_words": ws.max_words,
                "createdAt": ws.createdAt.isoformat(),
                "updatedAt": ws.updatedAt.isoformat(),
            },
        }

    except DoesNotExist:
        logger.error(WS_NOT_FOUND)
        raise HTTPException(status_code=404, detail=WS_NOT_FOUND)
    except Exception as e:
        logger.error(f"Error updating Writing Style: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))


# ---------- CREATE WRITING STYLE ----------
@router.post("/")
def create_writing_style(
    data: WritingStyleCreateSchema = Body(...), user_data=Depends(verify_token)
):
    """
    Create a new Writing Style document.
    """
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        ws = WritingStyle(
            style=data.style,
            sample_content=data.sample_content,
            audience=data.audience,
            max_words=data.max_words,
            is_delete=False,
        )
        ws.save()

        return {
            "message": "Writing Style created successfully",
            "data": {
                "id": str(ws.id),
                "style": ws.style,
                "sample_content": ws.sample_content,
                "audience": ws.audience,
                "max_words": ws.max_words,
                "createdAt": ws.createdAt.isoformat(),
            },
        }

    except Exception as e:
        logger.error(f"Error creating Writing Style: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))


# ---------- GET ALL WRITING STYLES ----------
@router.get("/")
def get_all_writing_styles(
    page: Optional[int] = Query(None, description="Page number for pagination"),
    q: Optional[str] = Query(
        None, description="Search by style, audience, or sample content"
    ),
    user_data=Depends(verify_token),
):
    """
    Fetch all Writing Styles.
    - If 'page' is provided → paginated response.
    - If 'page' is None → return all.
    Supports optional search (q).
    """
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        # Base query
        query = WritingStyle.objects(is_delete=False).order_by("-createdAt")

        # Optional search filter
        REGEX = "$regex"
        REGEX_OPTIONS = "$options"

        filter_value = {REGEX: q, REGEX_OPTIONS: "i"}

        if q and q.strip():
            query = query.filter(
                __raw__={
                    "$or": [
                        {"style": filter_value},
                        {"audience": filter_value},
                        {"sample_content": filter_value},
                    ]
                }
            )

        # If no 'page' param → return all records
        if page is None:
            styles = query
            data = [
                {
                    "id": str(ws.id),
                    "style": ws.style,
                    "sample_content": ws.sample_content,
                    "audience": ws.audience,
                    "max_words": ws.max_words,
                    "createdAt": ws.createdAt.isoformat(),
                    "updatedAt": ws.updatedAt.isoformat(),
                }
                for ws in styles
            ]
            return {
                "total_writing_styles": len(data),
                "data": data,
            }

        # Paginated response
        page_size = 5
        total_styles = query.count()
        total_pages = max(1, math.ceil(total_styles / page_size))
        page = min(page, total_pages)
        skip = (page - 1) * page_size

        styles = query.skip(skip).limit(page_size)

        data = [
            {
                "id": str(ws.id),
                "style": ws.style,
                "sample_content": ws.sample_content,
                "audience": ws.audience,
                "max_words": ws.max_words,
                "createdAt": ws.createdAt.isoformat(),
                "updatedAt": ws.updatedAt.isoformat(),
            }
            for ws in styles
        ]

        return {
            "page": page,
            "page_size": page_size,
            "total_writing_styles": total_styles,
            "totalPages": total_pages,
            "data": data,
        }

    except Exception as e:
        logger.error(f"Error fetching Writing Styles: {str(e)}")
        raise HTTPException(status_code=500, detail="Failed to fetch writing styles")


# ---------- GET SINGLE WRITING STYLE BY ID ----------
@router.get("/{ws_id}")
def get_writing_style_by_id(ws_id: str, user_data=Depends(verify_token)):
    """
    Get a single Writing Style by ID.
    """
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        ws: WritingStyle = WritingStyle.objects.get(id=ObjectId(ws_id), is_delete=False)
        return {
            "id": str(ws.id),
            "style": ws.style,
            "sample_content": ws.sample_content,
            "audience": ws.audience,
            "max_words": ws.max_words,
            "createdAt": ws.createdAt.isoformat(),
            "updatedAt": ws.updatedAt.isoformat(),
        }

    except DoesNotExist:
        logger.error(WS_NOT_FOUND)
        raise HTTPException(status_code=404, detail=WS_NOT_FOUND)
    except Exception as e:
        logger.error(f"Error fetching Writing Style: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))


# ---------- DELETE WRITING STYLE ----------


@router.delete("/")
def delete_writing_styles(
    ids: List[str] = Body(..., embed=True), user_data=Depends(verify_token)
):
    """
    Soft delete multiple Writing Styles by IDs.
    Example request body:
    {
        "ws_ids": ["6720e93dcf245f84b9cc40d2", "6720e93dcf245f84b9cc40d3"]
    }
    """
    try:
        if not db_conn.is_connected():
            db_conn.connect()
        updated_count = 0
        for ws_id in ids:
            try:
                ws = WritingStyle.objects.get(id=ObjectId(ws_id))
                ws.is_delete = True
                ws.save()
                updated_count += 1
            except DoesNotExist:
                logger.warning(f"Writing Style not found: {ws_id}")
                continue

        if updated_count == 0:
            raise HTTPException(
                status_code=404, detail="No valid Writing Styles found to delete"
            )

        return {"message": f"{updated_count} Writing Style(s) deleted successfully"}

    except Exception as e:
        logger.error(f"Error deleting Writing Styles: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
