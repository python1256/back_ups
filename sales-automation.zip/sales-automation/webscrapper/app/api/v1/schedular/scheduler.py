from datetime import datetime, timezone

from apscheduler.events import EVENT_SCHEDULER_SHUTDOWN
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from ....database.mongo_database import MongoDBConnection
from ....database.profile_data_schema import Account, LinkedInURL
from ....services.utils.load_env import environment
from ....services.utils.log import logger
from .celery_client import celery_client


class LinkedInScheduler:
    def __init__(self, interval_minutes: int = 5):
        self.scheduler = AsyncIOScheduler()
        self.interval_minutes = interval_minutes
        self.scheduler.add_listener(self.on_shutdown, EVENT_SCHEDULER_SHUTDOWN)
        self.db_conn = MongoDBConnection(host=environment.MONGO_HOST)
        self.celery_client = celery_client.celery_client

    async def process_url(self):
        try:
            if not self.db_conn.is_connected():
                self.db_conn.connect()

            worker_count = celery_client._get_worker_count()
            if worker_count == 0:
                logger.warning("No Celery workers available. Skipping run.")
                return

            url_docs = (
                LinkedInURL.objects(status="pending")
                .order_by("updatedAt")
                .limit(worker_count)
            )
            logger.info(f"Fetched {len(url_docs)} pending URLs for processing.")
        except Exception as e:
            logger.error(f"Database connection error in scheduler: {e}")
            return

        for url_doc in url_docs:
            try:
                account = Account.objects(id=str(url_doc.account.id)).first()
                if not account or not account.cookies:
                    logger.error(
                        f"Account {url_doc.account.id} has no valid cookies. Marking URL as failed."
                    )
                    url_doc.update(
                        status="failed", updatedAt=datetime.now(timezone.utc)
                    )
                    continue

                logger.info(f"Dispatching scraping task for URL: {url_doc.url}")
                task = self.celery_client.send_task(
                    "scrape_linkedin_profile",
                    args=[str(url_doc.id), url_doc.is_update],
                )
                logger.info(f"Task {task.id} assigned for URL: {url_doc.url}")
                url_doc.update(
                    status="processing", updatedAt=datetime.now(timezone.utc)
                )
            except Exception as e:
                logger.error(
                    f"Failed scheduling scraping task for URL {url_doc.url}: {e}"
                )
                url_doc.update(status="failed", updatedAt=datetime.now(timezone.utc))

    def on_shutdown(self, event):
        logger.info("LinkedInScheduler is shutting down.")

    def start(self):
        self.scheduler.add_job(
            self._async_job_wrapper, "interval", minutes=self.interval_minutes
        )
        self.scheduler.start()
        logger.info(
            f"LinkedInScheduler started with interval {self.interval_minutes} minutes."
        )

    async def _async_job_wrapper(self):
        await self.process_url()

    def stop(self):
        self.scheduler.shutdown(wait=False)
        logger.info("LinkedInScheduler stopped.")
