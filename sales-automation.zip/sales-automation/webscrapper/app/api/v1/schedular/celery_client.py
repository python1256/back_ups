from celery import Celery

from ....services.utils.load_env import environment
from ....services.utils.log import logger


class CeleryClient:
    def __init__(self):
        self.celery_client = Celery(
            "worker",
            broker=environment.CELERY_BROKER_URL,
            backend=environment.CELERY_RESULT_BACKEND,
        )
        self.inspector = self.celery_client.control.inspect()

    def _get_worker_count(self) -> int:
        try:
            active_workers = self.inspector.ping()

            return len(active_workers)
        except Exception as e:
            logger.error(f"Error while get celery worker count >> {e}")
            return 0


celery_client = CeleryClient()
