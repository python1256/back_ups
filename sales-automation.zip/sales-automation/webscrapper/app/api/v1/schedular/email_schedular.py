import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from apscheduler.events import EVENT_SCHEDULER_SHUTDOWN
from apscheduler.schedulers.asyncio import AsyncIOScheduler

from ....core.config import db_conn
from ....database.mongo_database import MongoDBConnection
from ....database.profile_data_schema import Account, Filter, LinkedInURL
from ....services.utils.load_env import environment
from ....services.utils.log import logger


class EmailScheduler:
    def __init__(self, interval_minutes: int = 30):
        self.scheduler = AsyncIOScheduler()
        self.interval_minutes = interval_minutes
        self.scheduler.add_listener(self.on_shutdown, EVENT_SCHEDULER_SHUTDOWN)
        self.db_conn = MongoDBConnection(host=environment.MONGO_HOST)

    def send_email(self, filter_id: str, receiver_mail: str):
        """
        Sends a professional HTML email notifying the user that their
        lead generation filter data is ready to view on the dashboard.
        """
        try:
            # Fetch filter and scraping details
            filter_obj = Filter.objects(id=filter_id).first()
            if not filter_obj:
                logger.warning(f"Filter not found for ID: {filter_id}")
                return

            total = filter_obj.totalUrls
            successful = LinkedInURL.objects(filter=filter_id, status="done").count()
            failed = LinkedInURL.objects(filter=filter_id, status="failed").count()

            website_link = f"https://sales-automation/filters/{filter_id}"

            html_content = f"""
            <html>
            <head>
                <style>
                    body {{
                        font-family: 'Segoe UI', Arial, sans-serif;
                        background-color: #f6f9fc;
                        color: #333;
                        margin: 0;
                        padding: 0;
                    }}
                    .container {{
                        width: 90%;
                        max-width: 600px;
                        margin: 40px auto;
                        background: #ffffff;
                        border-radius: 10px;
                        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
                        padding: 30px;
                    }}
                    .header {{
                        text-align: center;
                        border-bottom: 3px solid #007bff;
                        padding-bottom: 15px;
                        margin-bottom: 25px;
                    }}
                    .header h2 {{
                        color: #007bff;
                        font-size: 22px;
                        margin: 0;
                    }}
                    .content {{
                        font-size: 15px;
                        line-height: 1.7;
                        color: #444;
                    }}
                    .stats {{
                        background: #f1f7ff;
                        padding: 15px;
                        border-radius: 8px;
                        margin: 20px 0;
                        border-left: 4px solid #007bff;
                    }}
                    .stats p {{
                        margin: 6px 0;
                        font-size: 15px;
                    }}
                    .button {{
                        display: inline-block;
                        margin-top: 25px;
                        padding: 12px 24px;
                        background-color: #007bff;
                        color: #fff !important;
                        text-decoration: none;
                        border-radius: 6px;
                        font-weight: 600;
                    }}
                    .footer {{
                        margin-top: 35px;
                        font-size: 13px;
                        color: #777;
                        text-align: center;
                        border-top: 1px solid #eee;
                        padding-top: 15px;
                    }}
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h2>Your Lead Generation Results Are Ready</h2>
                    </div>

                    <div class="content">
                        <p>Hello,</p>
                        <p>Your LinkedIn scraping process is complete. Below is a summary of the results:</p>

                        <div class="stats">
                            <p><strong>Total Profiles:</strong> {total}</p>
                            <p style="color:green;"><strong>Successfully Scraped:</strong> {successful}</p>
                            <p style="color:red;"><strong>Failed to Scrape:</strong> {failed}</p>
                        </div>

                        <p>Click the button below to review detailed results on your dashboard.</p>

                        <p style="text-align:center;">
                            <a href="{website_link}" class="button" target="_blank">View Results</a>
                        </p>

                        <p>If you didn't request this scrape or believe this email was sent in error, please ignore it.</p>
                        <p>Thanks for using our service!</p>
                    </div>

                    <div class="footer">
                        <p>© 2025 Your Company Name. All rights reserved.<br>
                        <a href="https://www.aspiresoftserv.com/" style="color:#007bff;">Visit Website</a></p>
                    </div>
                </div>
            </body>
            </html>
            """

            msg = MIMEMultipart("alternative")
            msg["Subject"] = "Your Lead Generation Filter Data is Ready"
            msg["From"] = environment.SMTP_USER
            msg["To"] = receiver_mail
            msg.attach(MIMEText(html_content, "html"))

            with smtplib.SMTP("smtp.gmail.com", 587, timeout=30) as server:
                server.starttls()
                server.login(
                    user=environment.SMTP_USER, password=environment.SMTP_PASSWORD
                )
                server.sendmail(msg["From"], [msg["To"]], msg.as_string())

            Filter.objects(id=filter_id).update_one(set__isEmailSent=True)
            logger.info(
                f"Email sent successfully to {receiver_mail} for Filter ID: {filter_id}"
            )

        except Exception as e:
            logger.exception(
                f"Unexpected error while sending email to {receiver_mail}: {e}"
            )

    def email_checker(self):
        try:
            if not db_conn.is_connected():
                db_conn.connect()

            filters_ready = Filter.objects.aggregate(
                [
                    {
                        "$match": {
                            "$expr": {
                                "$and": [
                                    {"$eq": ["$totalUrls", "$totalScrapedUrls"]},
                                    {"$gt": ["$totalUrls", 0]},
                                ]
                            },
                            "isEmailSent": False,
                        }
                    },
                    {"$project": {"_id": 1, "account_id": 1}},
                ]
            )

            count = 0
            for filters in filters_ready:
                account_id = filters.get("account_id")
                if not account_id:
                    logger.warning("Filter missing account_id field.")
                    continue

                account = Account.objects(id=account_id).first()
                if not account or not getattr(account, "email", None):
                    logger.warning(f"No valid email found for Account ID: {account_id}")
                    continue

                email_address = account.email
                filter_id = filters.get("_id")
                self.send_email(filter_id=filter_id, receiver_mail=email_address)
                count += 1

            logger.info(f"Email check completed. Processed {count} ready filters.")
        except Exception as e:
            logger.exception(f"Error while checking filters for email: {e}")

    def on_shutdown(self, event):
        logger.info("EmailScheduler shutting down gracefully.")

    def start(self):
        try:
            self.scheduler.add_job(
                self._async_job_wrapper, "interval", minutes=self.interval_minutes
            )
            self.scheduler.start()
            logger.info(
                f"EmailScheduler started with {self.interval_minutes}-minute interval."
            )
        except Exception as e:
            logger.exception(f"Failed to start EmailScheduler: {e}")

    async def _async_job_wrapper(self):
        try:
            self.email_checker()
        except Exception as e:
            logger.exception(f"Error in scheduled job execution: {e}")

    def stop(self):
        try:
            self.scheduler.shutdown(wait=False)
            logger.info("EmailScheduler stopped successfully.")
        except Exception as e:
            logger.exception(f"Error while stopping EmailScheduler: {e}")
