from fastapi import APIRouter, Depends

from ...services.auth_services.auth_service import JWTBearer
from .controllers.check.rediness import router as rediness_router
from .controllers.content_writer.content import router as value_propostion_router
from .controllers.content_writer.content_writer import router as content_writer_router
from .controllers.content_writer.sales_assests import router as sales_assest_router
from .controllers.content_writer.writing_style import router as writing_style_router
from .controllers.extension.authrouter import router as auth_router
from .controllers.extension.downloadrouter import router as download_router
from .controllers.scrapper.ai_scrapper.ai_scrapper import router as ai_scrapper_router
from .controllers.scrapper.ai_scrapper.score_router import router as score_router
from .controllers.scrapper.filter.company_filter import router as company_filter_router
from .controllers.scrapper.filter.select_filter import router as filter_router
from .controllers.scrapper.filter.url_routes import router as url_router
from .controllers.scrapper.profile_scrapper.linkedin_profile_scrapper import (
    router as linkedin_profile_scrapper_router,
)
from .controllers.scrapper.profile_scrapper.profiles import router as profiles_router
from .controllers.scrapper.profile_scrapper.scrapperouter import (
    router as scrapper_router,
)
from .controllers.view.guidepage import router as ui_router

# Create main router with global configurations
router = APIRouter()

router.include_router(profiles_router)
router.include_router(sales_assest_router)
router.include_router(writing_style_router)
router.include_router(value_propostion_router)
router.include_router(ui_router, include_in_schema=False)
router.include_router(rediness_router)
router.include_router(auth_router)
router.include_router(download_router, include_in_schema=False)
router.include_router(content_writer_router)
router.include_router(scrapper_router, dependencies=[Depends(JWTBearer())])
router.include_router(
    linkedin_profile_scrapper_router, dependencies=[Depends(JWTBearer())]
)
router.include_router(
    ai_scrapper_router,
    include_in_schema=False,
    prefix="/ai",
    dependencies=[Depends(JWTBearer())],
)
router.include_router(
    score_router,
    include_in_schema=False,
    prefix="/ai",
    dependencies=[Depends(JWTBearer())],
)
router.include_router(filter_router)
router.include_router(company_filter_router, include_in_schema=False)
router.include_router(url_router)
