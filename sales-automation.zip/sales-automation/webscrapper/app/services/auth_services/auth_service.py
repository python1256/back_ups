from fastapi import HTTPException, Request, status
from fastapi.responses import JSONResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt

from ...core.security import create_access_token, create_refresh_token, verify_token
from ...repository.account_repository import AccountRepository
from ...services.utils.log import logger
from ..utils.hash_password import check_password_hash, generate_password_hash
from ..utils.load_env import environment


def refresh_user_token(refresh_token: str):
    """Validate refresh token and issue a new access token."""
    try:
        payload = verify_user_token(refresh_token)
        user_id = payload.get("id")
        if not user_id:
            raise JWTError("Invalid refresh token")

        new_access_token = create_access_token(
            {"sub": payload.get("sub"), "email": payload.get("email"), "id": user_id}
        )

        return {"access_token": new_access_token, "refresh_token": refresh_token}
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired refresh token")


def register_user(
    username: str, email: str, password: str, linkedin_url: str, cookies: str = "{}"
):
    """Handle user registration."""
    try:
        # Hash password securely
        password_hash = generate_password_hash(password)

        # Create account document
        user = AccountRepository.create_account(
            username=username,
            email=email,
            password_hash=password_hash,
            cookies=cookies,
            linkedin_url=linkedin_url,
        )

        return {
            "id": str(user.id),
            "username": user.username,
            "email": user.email,
            "linkedin_url": user.linkedin_url,
        }

    except ValueError as e:
        # Raised from repository (e.g., duplicate username/email)
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error registering user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


def authenticate_user(email: str, password: str, type: str):
    """Authenticate user credentials and return tuple (is_auth, linkedin_url, username)."""
    user = AccountRepository.get_by_email(email)

    if not user:
        logger.warning(f"Invalid email: {email}")
        return False, "", ""

    # Validate password
    if type == "mannual" and not check_password_hash(user.password_hash, password):
        logger.warning(f"Invalid password for user: {email}")
        return False, "", ""

    # Check active/deleted status
    if not user.is_active or user.is_delete:
        logger.warning(f"Inactive or deleted user: {email}")
        return False, "", ""

    # Authentication successful
    return True, str(user.id), user.username


def login_user(email: str, password: str, type: str = "mannual"):
    """Generate access and refresh tokens for valid user."""
    try:
        is_auth, user_id, username = authenticate_user(email, password, type)
        if is_auth:
            access_token = create_access_token(
                {"sub": username, "email": email, "id": user_id}
            )
            refresh_token = create_refresh_token(
                {"sub": username, "email": email, "id": user_id}
            )
            return {
                "access_token": access_token,
                "refresh_token": refresh_token,
                "token_type": "bearer",
            }
        return JSONResponse(
            status_code=status.HTTP_401_UNAUTHORIZED,
            content={"message": "Invalid Email or Password."},
        )
    except HTTPException:
        logger.error("")
        raise
    except Exception as e:
        logger.error(f"Error generating token >> {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Something went wrong",
        )


def verify_user_token(token: str):
    """Verify user from token."""
    payload = verify_token(token)
    email = payload.get("email")

    users_db = AccountRepository.get_by_email(email)

    if email != users_db.email:
        logger.error("Invalid user.")
        raise HTTPException(status_code=401, detail="Invalid user")
    return payload


async def verify_jwt_token(token: str) -> dict:
    """
    Verify JWT token using public key from SSM.
    Returns the decoded payload if valid, raises HTTPException if not.
    """
    try:
        # Verify and decode the token
        payload = jwt.decode(
            token, environment.SECRET_KEY, algorithms=[environment.ALGORITHM]
        )
        return payload

    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve JWT public key",
        )
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token verification failed",
            headers={"WWW-Authenticate": "Bearer"},
        )


class JWTBearer(HTTPBearer):
    def __init__(self, auto_error: bool = True):
        super(JWTBearer, self).__init__(auto_error=auto_error)

    async def __call__(self, request: Request):
        credentials: HTTPAuthorizationCredentials = await super(
            JWTBearer, self
        ).__call__(request)
        if credentials:
            if credentials.scheme != "Bearer":
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Invalid authentication scheme",
                )
            if not await verify_jwt_token(credentials.credentials):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Invalid token or expired token",
                )
            return credentials.credentials
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Invalid authorization code",
            )
