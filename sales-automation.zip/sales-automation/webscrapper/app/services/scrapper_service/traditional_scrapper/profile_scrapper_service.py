import json
import re
import secrets
import threading
import time
import warnings
from collections import defaultdict
from contextlib import contextmanager
from functools import partial
from typing import Any, Dict, Generator, List, Optional, Tuple, Union
from urllib.parse import urljoin, urlparse

import tldextract
from bs4 import BeautifulSoup, Tag
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from ....core.config import llm
from ....core.selenium_session import SeleniumManager
from ....database.mongo_database import MongoDBConnection
from ....database.profile_data_schema import Company, ProfileScraping
from ...utils.load_env import environment
from ...utils.log import logger
from ..ai_scrapper_service.ai_scrapper_service import AIScraper
from ..ai_scrapper_service.score_service import AIScoreGenerator

warnings.filterwarnings("ignore")

# Global storage
profile_data = {}


class TraditionalProfileScrapper:
    def __init__(self):
        self.manager = SeleniumManager()
        self.db_conn = MongoDBConnection(host=environment.MONGO_HOST)
        self.session = None
        self.profile_name = None
        self.SKILLS_PREFIX = "Skills:"
        self.OTHER_CONTRIBUTORS_TEXT = "Other contributors"
        self.HTML_PARSER = "html.parser"

    def _login(
        self,
        url: str,
        session_name: str,
        is_login_required: bool,
        cookies: List[Dict[str, Union[Dict, str, List, Any]]],
        headless: bool,
    ):
        try:
            self.session = self.manager.create_session(
                session_name=session_name,
                headless=headless,
                is_login_required=is_login_required,
            )
            self.session.get(url)
            WebDriverWait(self.session, 10).until(
                EC.visibility_of_element_located((By.TAG_NAME, "body"))
            )
            if not cookies:
                logger.debug("⚠️ No cookies provided in the request.")
                return False

            try:
                # Convert the cookie data to a format that can be added to Selenium
                selenium_cookies = []
                for cookie in cookies:
                    selenium_cookie = {
                        "name": cookie["name"],
                        "value": cookie["value"],
                        "domain": cookie["domain"],
                        "path": cookie["path"],
                        "secure": cookie.get("secure", False),
                        "httpOnly": cookie.get("httpOnly", False),
                    }
                    selenium_cookies.append(selenium_cookie)

                for desired_cookie in selenium_cookies:
                    self.session.add_cookie(desired_cookie)

            except Exception as e:
                logger.error(f"cookie_error:>> {e}")
        except Exception as e:
            logger.error(f"Error while login >> {e}")

    def get_logged_in_user_profile_url(self, driver: webdriver.Chrome, timeout=15):
        try:
            # Wait for sidebar region
            WebDriverWait(driver, timeout).until(
                EC.presence_of_element_located(
                    (By.CSS_SELECTOR, "div[role='region'][aria-label='Side Bar']")
                )
            )

            # Allow JS to load profile link
            time.sleep(2)

            # Parse page
            soup = BeautifulSoup(driver.page_source, self.HTML_PARSER)
            region = soup.find("div", {"role": "region", "aria-label": "Side Bar"})
            if not region:
                return None

            # Get FIRST <a> with href
            first_a = region.find("a", href=True)
            if not first_a:
                return None

            # Convert to absolute URL
            profile_url = urljoin(driver.current_url, first_a["href"])

            return profile_url

        except TimeoutException:
            logger.error("Timeout: Sidebar region not found.")
            return None
        except Exception as e:
            logger.error(f"Error extracting profile URL: {e}")
            return None

    def extract_text(
        self, element: Tag, selector=None, class_filter=None, string_filter=None
    ):
        """Find element and return stripped text if exists."""
        if selector:
            el = element.select_one(selector)
        elif class_filter:
            el = element.find(class_=class_filter)
        elif string_filter:
            el = element.find(string=string_filter)
        else:
            return ""
        return el.get_text(strip=True) if el else ""

    def get_text_or_empty(self, element: Tag):
        return element.get_text(strip=True) if element else ""

    def safe_find(self, container: Tag, tag, **kwargs):
        return container.find(tag, **kwargs) if container else None

    def safe_select_one(self, container: Tag, selector):
        return container.select_one(selector) if container else None

    def _extract_connections(self, top_card) -> str:
        connections_li = self.safe_find(
            top_card, "li", class_=lambda x: x and "text-body-small" in x
        )
        if connections_li:
            span = self.safe_find(
                connections_li, "span", class_=lambda x: x and "t-bold" in x
            )
            if span:
                return f"{self.get_text_or_empty(span)} connections"

        fallback = top_card.find(
            "span", string=lambda x: x and "connections" in x.lower()
        )
        return self.get_text_or_empty(fallback)

    def get_personal_info(self, driver: webdriver.Chrome) -> dict:
        try:
            driver.execute_script("window.scrollTo(0, 200);")
            time.sleep(1)

            WebDriverWait(driver, 15).until(
                EC.presence_of_element_located(
                    (By.CSS_SELECTOR, "section[data-member-id] h1")
                )
            )

            soup = BeautifulSoup(driver.page_source, self.HTML_PARSER)
            top_card = self.safe_select_one(soup, "section[data-member-id]")

            data = {
                "name": "",
                "headline": "",
                "location": "",
                "connections": "",
                "profile_image_url": "",
            }

            if not top_card:
                logger.debug("Top card section not found")
                return data

            # --- Name ---
            data["name"] = self.get_text_or_empty(self.safe_find(top_card, "h1"))

            # --- Headline ---
            headline = self.safe_find(
                top_card, "div", class_=lambda x: x and "text-body-medium" in x
            )
            data["headline"] = self.get_text_or_empty(headline)

            # --- Location ---
            location = self.safe_find(
                top_card,
                "span",
                class_=lambda x: x and "text-body-small" in x and "inline" in x,
            )
            data["location"] = self.get_text_or_empty(location)

            # --- Connections (moved to helper) ---
            data["connections"] = self._extract_connections(top_card)

            # --- Profile Image URL ---
            if data["name"]:
                lower_name = data["name"].strip().lower()
                img_tag = soup.find(
                    "img", attrs={"title": lambda t: t and t.lower() == lower_name}
                ) or soup.find(
                    "img", attrs={"alt": lambda a: a and a.lower() == lower_name}
                )
                data["profile_image_url"] = img_tag.get("src", "") if img_tag else ""

            return data

        except Exception as e:
            logger.debug(f"Error scraping personal info: {e}")
            return {}

    def back_to_main_page(self, driver: webdriver.Chrome, url: str):
        driver.get(url)

    def scroll_to_bottom(self, driver: webdriver.Chrome, pause_time: float = 0.5):
        """
        Scrolls the page to the bottom.

        Args:
            driver: Selenium WebDriver instance
            pause_time: Seconds to wait after each scroll for the page to load (default: 3)
        """
        scroll_count = 0
        last_height = driver.execute_script("return document.body.scrollHeight")

        while True:
            # Scroll to bottom
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            scroll_count += 1
            logger.debug(f"Scrolled down {scroll_count} time(s)")

            # Wait for page load
            time.sleep(pause_time)

            new_height = driver.execute_script("return document.body.scrollHeight")
            if new_height == last_height:
                logger.debug("Reached the bottom of the page.")
                break
            last_height = new_height

    def get_about_data(self, sections: List[Tag]):
        for section in sections:
            about_div = section.find("div", id="about")
            if about_div:
                spans = about_div.find_all_next("span", class_="visually-hidden")
                if len(spans) >= 2:
                    second_span = spans[1]
                    about_hidden_text = second_span.get_text(separator=" ", strip=True)
                    clean_about = " ".join(about_hidden_text.splitlines())
                    clean_about = re.sub(r"\s+", " ", clean_about).strip()

                    logger.debug(f"About Section {about_hidden_text}")
                    return {"about": clean_about}
                else:
                    logger.debug(
                        "Less than 2 visually-hidden spans found after About div."
                    )
                    return {}
        return {}

    def get_post_text(self, li_tag: Tag) -> str | None:
        """Extract text from a single li_tag."""
        update_text_container = li_tag.find("div", class_="update-components-text")
        if not update_text_container:
            return None
        span_tag = update_text_container.find("span")
        return span_tag.get_text(" ", strip=True) if span_tag else None

    def extract_activities(self, sections: List[Tag]) -> dict:
        posts = [
            post_text
            for section in sections
            if (ul_tag := section.find("ul"))
            for li_tag in ul_tag.find_all("li", recursive=False)
            if (post_text := self.get_post_text(li_tag))
        ]

        if posts:
            return {"posts": posts}

        logger.debug("No posts found.")
        return {}

    def extract_followers_text(self, section: Tag) -> str | None:
        """Extract followers text from a given section if available."""
        if not section.find("div", {"id": "content_collections"}):
            return None

        for h2_tag in section.find_all("h2"):
            if "Activity" not in h2_tag.get_text(strip=True):
                continue

            parent_div = h2_tag.find_parent("div")
            if not parent_div:
                continue

            p_tag = parent_div.find("p")
            if not p_tag:
                continue

            span_tag = p_tag.find("span", class_="visually-hidden") or p_tag.find(
                "span", aria_hidden="true"
            )
            if span_tag:
                return span_tag.get_text(strip=True)
        return None

    def get_activities(self, driver: webdriver.Chrome, sections: List[Tag]) -> dict:
        result = {}
        try:
            # Extract followers info
            for section in sections:
                followers_text = self.extract_followers_text(section)
                if followers_text:
                    logger.debug(followers_text)

            # Try clicking "Show all posts"
            try:
                show_posts_link = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable(
                        (By.XPATH, "//a[.//span[text()='Show all posts']]")
                    )
                )
            except Exception as e:
                logger.error(f"Error clicking 'Show all posts' link: {e}")
                show_posts_link = None

            if show_posts_link:
                show_posts_link.click()
                logger.debug("Clicked 'Show all posts' link successfully")
                time.sleep(3)
                activity_sections = self.get_current_page_sections(driver)
                result = self.extract_activities(activity_sections)
            else:
                logger.debug("No posts yet.")
                result = {}

        except Exception as e:
            logger.error(f"Error scraping activities: {e}")
            result = {}

        return result

    def is_likely_position_list(self, nested_ul: Tag):
        pos_items = nested_ul.find_all("li", recursive=False)
        if not pos_items:
            return False
        if len(pos_items) == 1:
            span = pos_items[0].find("span", class_="visually-hidden")
            if span:
                text = span.get_text(strip=True)
                if len(text.split()) > 20:
                    return False
        first_span = pos_items[0].find("span", class_="visually-hidden")
        if first_span:
            text = first_span.get_text(strip=True)
            if len(text.split()) <= 6 and text == text.title():
                return True
        return False

    def extract_spans_text(self, li_tag: Tag) -> list[str]:
        """Extract text from all visually-hidden spans in a li_tag."""
        return [
            s.get_text(" ", strip=True)
            for s in li_tag.find_all("span", class_="visually-hidden")
        ]

    def parse_position_li(self, pos_li: Tag) -> dict:
        pos_spans = self.extract_spans_text(pos_li)
        if not pos_spans:
            return {}
        return {
            "position": pos_spans[0],
            "duration": pos_spans[1] if len(pos_spans) > 1 else "",
            "location": pos_spans[2] if len(pos_spans) > 2 else "",
            "description": "\n".join(pos_spans[3:]),
        }

    def parse_company_li(self, company_li: Tag) -> dict | None:
        company_spans = self.extract_spans_text(company_li)
        if not company_spans:
            return None

        position_ul = company_li.find("ul")
        if position_ul and self.is_likely_position_list(position_ul):
            company_entry = {
                "company_name": company_spans[0].split("·")[0].strip(),
                "duration": company_spans[1] if len(company_spans) > 1 else "",
                "positions": [],
            }
            for pos_li in position_ul.find_all("li", recursive=False):
                pos_entry = self.parse_position_li(pos_li)
                if pos_entry:
                    company_entry["positions"].append(pos_entry)
            return company_entry
        elif len(company_spans) >= 4:
            return {
                "company_name": company_spans[1].split("·")[0].strip(),
                "position": company_spans[0],
                "duration": company_spans[2],
                "location": company_spans[3],
                "description": "\n".join(company_spans[4:]),
            }
        return None

    def parse_experience(self, sections: List[Tag]) -> list:
        experiences = []
        for section in sections:
            exp_div = section.find("div", id="experience")
            if not exp_div:
                continue
            ul = exp_div.find_next("ul")
            if not ul:
                continue
            for company_li in ul.find_all("li", recursive=False):
                company_entry = self.parse_company_li(company_li)
                if company_entry:
                    experiences.append(company_entry)
            break  # Only process the first experience section

        return experiences

    def show_all_exp_parse_experience(self, sections: List[Tag]):
        experiences = []
        for section in sections:
            ul = section.find_next("ul")
            if not ul:
                continue
            for company_li in ul.find_all("li", recursive=False):
                company_entry = self.parse_company_li(company_li)
                if company_entry:
                    experiences.append(company_entry)
            break  # Only process the first section

        return experiences

    def get_experience(self, driver: webdriver.Chrome, sections: List[Tag], url: str):
        soup = BeautifulSoup(driver.page_source, "lxml")
        experience_link = soup.find("a", {"id": "navigation-index-see-all-experiences"})

        if experience_link:
            result = {}
            try:
                button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable(
                        (By.ID, "navigation-index-see-all-experiences")
                    )
                )
                button.click()

                WebDriverWait(driver, 10).until(
                    EC.visibility_of_element_located((By.TAG_NAME, "body"))
                )
                exp_sections = self.get_current_page_sections(driver)
                result = {
                    "experience": self.show_all_exp_parse_experience(exp_sections)
                }
            except Exception as e:
                logger.error(f"❌ Failed to click button: {e}")
                result = {}
            finally:
                self.back_to_main_page(driver, url)
            return result
        else:
            return {"experience": self.parse_experience(sections)}

    def extract_description(self, li_tag: Tag) -> str:
        """Extract unique description texts from nested ULs."""
        description_texts = []
        for nested_ul in li_tag.find_all("ul", recursive=True):
            for sp in nested_ul.find_all("span", class_="visually-hidden"):
                text = sp.get_text(strip=True)
                if text and text not in description_texts:
                    description_texts.append(text)
        return "\n\n".join(description_texts) if description_texts else ""

    def extract_education_from_section(self, section: Tag) -> list[dict]:
        education_data = []
        education_div = section.find("div", id="education")
        if not education_div:
            return education_data

        ul = education_div.find_next("ul")
        if not ul:
            return education_data

        for li in ul.find_all("li", recursive=False):
            spans = self.extract_spans_text(li)
            if not spans:
                continue

            education_data.append(
                {
                    "institution_name": spans[0] if len(spans) > 0 else None,
                    "degree_name": spans[1] if len(spans) > 1 else None,
                    "study_duration": spans[2] if len(spans) > 2 else None,
                    "description": self.extract_description(li),
                }
            )
        return education_data

    def get_education(self, sections: List[Tag]) -> dict:
        """Extract education information from given sections."""

        education_data = []
        try:
            for section in sections:
                section_education = self.extract_education_from_section(section)
                if section_education:
                    education_data.extend(section_education)
                    break  # Only process the first education section
        except Exception as e:
            logger.error(f"Error scraping education: {e}")

        return {"education": education_data}

    def scroll_and_convert_sections(self, sections: List[Tag]):
        """
        Scroll each Selenium WebElement into view and convert it to a BeautifulSoup Tag.
        Returns a list of BeautifulSoup objects (one per section).
        """
        soup_sections = []
        for section in sections:
            try:
                html = section.get_attribute("outerHTML")
                # Convert to BeautifulSoup
                soup_sections.append(BeautifulSoup(html, "lxml"))
            except Exception as e:
                logger.debug(f"Error converting section: {e}")
        return soup_sections

    def extract_cert_from_li(self, li: Tag) -> dict:
        """Extract a single certificate from a list item."""
        spans = li.find_all("span", class_="visually-hidden", recursive=True)
        certificate_name = spans[0].get_text(strip=True) if len(spans) > 0 else None
        issuing_organization = spans[1].get_text(strip=True) if len(spans) > 1 else None
        issue_date = spans[2].get_text(strip=True) if len(spans) > 2 else None

        # Extract nested description spans
        description_texts = []
        for nested_ul in li.find_all("ul", recursive=True):
            for sp in nested_ul.find_all("span", class_="visually-hidden"):
                text = sp.get_text(strip=True)
                if text and text not in description_texts:
                    description_texts.append(text)

        description = "\n\n".join(description_texts) if description_texts else ""
        return {
            "certificate_name": certificate_name,
            "issuing_organization": issuing_organization,
            "issue_date": issue_date,
            "description": description,
        }

    def extract_licenses_and_certifications(self, sections: List[Tag]):
        """Extract licenses and certifications from sections."""
        all_certs = []
        for section in sections:
            div = section.find("div", id="licenses_and_certifications")
            if not div:
                continue
            ul = div.find_next("ul")
            if not ul:
                continue

            for li in ul.find_all("li", recursive=False):
                all_certs.append(self.extract_cert_from_li(li))
            break  # Only process the first licenses_and_certifications section

        return all_certs

    def show_more_extract_licenses_and_certifications(self, sections: List[Tag]):
        """Extract certificates and licenses from given sections (show more variant)."""
        all_certs = []
        for section in sections:
            ul = section.find_next("ul")
            if not ul:
                continue
            for li in ul.find_all("li", recursive=False):
                all_certs.append(self.extract_cert_from_li(li))
            break  # Only process the first relevant <ul>

        return all_certs

    def get_licenses_and_certifications(
        self, driver: webdriver.Chrome, sections: List[Tag], url: str
    ):
        result = {}
        try:
            licenses_and_certifications_div = None

            # Locate licenses section
            for section in sections:
                licenses_and_certifications_div = section.find(
                    "div", id="licenses_and_certifications"
                )
                if licenses_and_certifications_div:
                    break

            if not licenses_and_certifications_div:
                logger.debug("Licenses and certifications section not found.")
                result = {}
            else:
                # Check if "Show all" button is available
                elements = driver.find_elements(
                    By.XPATH,
                    "//a[@id='navigation-index-see-all-licenses-and-certifications']",
                )
                if elements:
                    try:
                        show_btn = WebDriverWait(driver, 10).until(
                            EC.element_to_be_clickable(
                                (
                                    By.XPATH,
                                    "//a[@id='navigation-index-see-all-licenses-and-certifications']",
                                )
                            )
                        )
                        show_btn.click()
                        logger.debug("Clicked 'Show all Licenses & Certificates'")
                        time.sleep(3)

                        # Expanded page
                        expanded_sections = self.get_current_page_sections(driver)
                        result = {
                            "licenses_and_certifications": self.show_more_extract_licenses_and_certifications(
                                expanded_sections
                            )
                        }
                    except Exception as e:
                        logger.debug(
                            f"Failed to click 'Show all Licenses & Certificates': {e}"
                        )
                        result = {
                            "licenses_and_certifications": self.extract_licenses_and_certifications(
                                sections
                            )
                        }
                    finally:
                        # ensure we always navigate back to the main profile page
                        self.back_to_main_page(driver, url)
                else:
                    logger.debug(
                        "ℹ️ No 'Show all Licenses & Certificates' button found, scraping main page..."
                    )
                    result = {
                        "licenses_and_certifications": self.extract_licenses_and_certifications(
                            sections
                        )
                    }

        except Exception as e:
            logger.error(f"Error scraping licenses & certifications: {e}")
            result = {}

        return result

    def extract_project_from_li(self, li: Tag) -> dict:
        """Extract project info from a single <li> element."""
        spans = li.find_all("span", class_="visually-hidden", recursive=True)
        project_name = spans[0].get_text(strip=True) if len(spans) > 0 else None
        project_duration = spans[1].get_text(strip=True) if len(spans) > 1 else None

        # Extract nested description texts
        description_texts = [
            sp.get_text(strip=True)
            for nested_ul in li.find_all("ul", recursive=True)
            for sp in nested_ul.find_all("span", class_="visually-hidden")
            if sp.get_text(strip=True)
        ]
        # Remove duplicates
        description_texts = list(dict.fromkeys(description_texts))
        description = "\n\n".join(description_texts) if description_texts else ""

        # Clean description
        description = (
            description.replace("Other contributors", "").replace(",", "").strip()
        )

        project_skills = None

        if self.SKILLS_PREFIX in description:
            parts = description.split(self.SKILLS_PREFIX)
            description = parts[0].strip()
            project_skills = parts[1].strip() if len(parts) > 1 else None

        return {
            "project_name": project_name,
            "project_duration": project_duration,
            "project_description": description,
            "project_skills": project_skills,
        }

    def extract_projects(self, sections: List[Tag]):
        """Extract projects from the main page sections."""

        all_projects = []
        for section in sections:
            projects_div = section.find("div", id="projects")
            if not projects_div:
                continue

            ul = projects_div.find_next("ul")
            if not ul:
                continue

            for li in ul.find_all("li", recursive=False):
                all_projects.append(self.extract_project_from_li(li))
            break  # Only process the first projects section

        return all_projects

    def show_more_extract_projects(self, sections: List[Tag]):
        """Extract projects from expanded 'Show all' page."""
        all_projects = []
        for section in sections:
            ul = section.find_next("ul")
            if not ul:
                continue

            for li in ul.find_all("li", recursive=False):
                all_projects.append(self.extract_project_from_li(li))
            break  # Only process the first <ul> section

        return all_projects

    def get_projects(self, driver: webdriver.Chrome, sections: List[Tag], url: str):
        """Main function to get projects and handle 'Show all' logic"""
        result = {}
        try:
            projects_div = None
            for section in sections:
                projects_div = section.find("div", id="projects")
                if projects_div:
                    break

            if not projects_div:
                logger.warning("❌ Projects section not found.")
                result = {}
            else:
                elements = driver.find_elements(
                    By.XPATH, "//a[@id='navigation-index-see-all-projects']"
                )
                if elements:
                    try:
                        show_btn = WebDriverWait(driver, 10).until(
                            EC.element_to_be_clickable(
                                (
                                    By.XPATH,
                                    "//a[@id='navigation-index-see-all-projects']",
                                )
                            )
                        )
                        show_btn.click()
                        logger.debug("✅ Clicked 'Show all Projects'")
                        time.sleep(3)

                        # Expanded page
                        expanded_sections = self.get_current_page_sections(driver)
                        result = {
                            "projects": self.show_more_extract_projects(
                                expanded_sections
                            )
                        }

                    except Exception as e:
                        logger.error(f"❌ Failed to click 'Show all Projects': {e}")
                        result = {"projects": self.extract_projects(sections)}
                    finally:
                        self.back_to_main_page(driver, url)
                else:
                    logger.debug(
                        "ℹ️ No 'Show all Projects' button found, scraping main page..."
                    )
                    result = {"projects": self.extract_projects(sections)}

        except Exception as e:
            logger.error(f"⚠️ Error scraping projects: {e}")
            result = {}

        return result

    def extract_skill_from_li(self, li: Tag) -> dict:
        """Extract a single skill from a <li> element."""
        spans = li.find_all("span", class_="visually-hidden", recursive=True)
        skill_name = spans[0].get_text(strip=True) if len(spans) > 0 else None

        # Extract nested skill sources
        skill_source_texts = [
            sp.get_text(strip=True)
            for nested_ul in li.find_all("ul", recursive=True)
            for sp in nested_ul.find_all("span", class_="visually-hidden")
            if sp.get_text(strip=True)
        ]
        # Remove duplicates
        skill_source_texts = list(dict.fromkeys(skill_source_texts))
        skill_source = ", ".join(skill_source_texts) if skill_source_texts else ""

        return {"skill_name": skill_name, "skill_source": skill_source}

    def extract_skills(self, sections: List[Tag]):
        """Extract skills from the main page sections."""

        all_skills = []
        for section in sections:
            skills_div = section.find("div", id="skills")
            if not skills_div:
                continue

            ul = skills_div.find_next("ul")
            if not ul:
                continue

            for li in ul.find_all("li", recursive=False):
                all_skills.append(self.extract_skill_from_li(li))
            break  # Only process the first skills section

        return all_skills

    def _extract_skill_sources(self, li_tag: Tag) -> str:
        """Helper to get skill sources from nested lists within a single <li> tag."""
        source_texts = set()
        nested_uls = li_tag.find_all("ul", recursive=True)
        for nested_ul in nested_uls:
            nested_spans = nested_ul.find_all("span", class_="visually-hidden")
            for span in nested_spans:
                text = span.get_text(strip=True)
                if text:
                    source_texts.add(text)
        return ", ".join(sorted(list(source_texts)))

    def _extract_skill_from_li(self, li_tag: Tag) -> Optional[Dict[str, str]]:
        """Helper to process a single <li> tag into a skill dictionary."""
        spans = li_tag.find_all("span", class_="visually-hidden", recursive=True)
        if not spans:
            return None

        skill_name = spans[0].get_text(strip=True)
        skill_source = self._extract_skill_sources(li_tag)

        return {"skill_name": skill_name, "skill_source": skill_source}

    def show_more_extract_skills(self, sections: List[Tag]) -> List[Dict[str, str]]:
        """Extract skills from an expanded 'Show all' page."""
        # The original loop only ever processed the first section with a `ul`,
        # so we find it directly instead of looping and breaking.
        first_ul = next(
            (s.find_next("ul") for s in sections if s.find_next("ul")), None
        )

        if not first_ul:
            return []

        top_level_list_items = first_ul.find_all("li", recursive=False)

        # Use a list comprehension and the helper function to process each item.
        # This is flatter and easier to read than the original nested loops.
        all_skills = [
            skill
            for li in top_level_list_items
            if (skill := self._extract_skill_from_li(li)) is not None
        ]

        return all_skills

    def get_current_page_sections(self, driver: webdriver.Chrome):
        try:
            soup = BeautifulSoup(driver.page_source, "lxml")
            return soup.find_all("section", {"class": "artdeco-card"})
        except Exception as e:
            logger.error(f"Error while get current page section >> {e}")

    def get_skills(self, driver: webdriver.Chrome, sections: List[Tag], url: str):
        """Main function to get skills and handle 'Show all' logic"""
        result = {}
        try:
            skills_div = None
            for section in sections:
                skills_div = section.find("div", id="skills")
                if skills_div:
                    break

            if not skills_div:
                logger.debug("❌ Skills section not found.")
                result = {}
            else:
                elements = driver.find_elements(
                    By.XPATH, "//a[contains(., 'Show all') and contains(., 'skills')]"
                )
                if elements:
                    try:
                        show_all_skills_link = WebDriverWait(driver, 10).until(
                            EC.element_to_be_clickable(
                                (
                                    By.XPATH,
                                    "//a[contains(., 'Show all') and contains(., 'skills')]",
                                )
                            )
                        )
                        show_all_skills_link.click()
                        logger.debug("✅ Clicked 'Show all skills' link successfully")
                        time.sleep(3)

                        self.scroll_to_bottom(driver)

                        # Expanded page
                        expanded_sections = self.get_current_page_sections(driver)
                        result = {
                            "skills": self.show_more_extract_skills(expanded_sections)
                        }

                    except Exception as e:
                        logger.error(f"❌ Failed to click 'Show all skills': {e}")
                        result = {"skills": self.extract_skills(sections)}

                    finally:
                        self.back_to_main_page(driver, url)
                else:
                    logger.debug(
                        "ℹ️ No 'Show all skills' button found, scraping main page..."
                    )
                    result = {"skills": self.extract_skills(sections)}

        except Exception as e:
            logger.error(f"⚠️ Error scraping skills: {e}")
            result = {}

        return result

    @contextmanager
    def _handle_contact_popup(
        self, driver: webdriver.Chrome
    ) -> Generator[Optional[BeautifulSoup], None, None]:
        """A context manager to open and reliably close the contact info popup."""
        try:
            # 1. Open the popup
            wait = WebDriverWait(driver, 10)
            contact_info_button = wait.until(
                EC.element_to_be_clickable(
                    (By.ID, "top-card-text-details-contact-info")
                )
            )
            contact_info_button.click()
            logger.debug("Clicked on contact_info_button")
            time.sleep(2)  # Allow modal content to render

            soup = BeautifulSoup(driver.page_source, self.HTML_PARSER)
            yield soup.find("div", {"role": "dialog"})

        finally:
            # 2. Close the popup, regardless of what happened
            try:
                close_btn = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable(
                        (By.CSS_SELECTOR, "button.artdeco-modal__dismiss")
                    )
                )
                close_btn.click()
            except Exception:
                logger.warning(
                    "Could not find or click the close button for contact info popup."
                )

    def _parse_simple_field(self, text: str, keyword: str) -> Tuple[Optional[str], str]:
        """Generic parser for simple fields like Birthday and Connected date."""
        if keyword in text:
            try:
                # Isolate the text after the keyword and before the next keyword
                after_keyword = text.split(keyword, 1)[1].strip()
                next_keyword_index = next(
                    (
                        after_keyword.find(k)
                        for k in ["Websites", "Birthday", "Connected"]
                        if k in after_keyword
                    ),
                    -1,
                )

                value_part = (
                    after_keyword[:next_keyword_index].strip()
                    if next_keyword_index != -1
                    else after_keyword
                )

                # Logic for birthday and connected date
                if keyword == "Birthday":
                    value = " ".join(value_part.split()[:2])
                elif keyword == "Connected":
                    value = " ".join(value_part.split()[:3])
                else:  # Profile
                    value = value_part.split()[0]

                # Return the found value and the remaining text for subsequent parsers
                return value, text.replace(f"{keyword}{value_part}", "")
            except IndexError:
                pass
        return None, text

    def _parse_websites(self, text: str) -> Tuple[Optional[Dict], str]:
        """Parses the 'Websites' section specifically."""
        if "Websites" not in text:
            return None, text

        websites_section_raw = text.split("Websites", 1)[1]

        # Isolate the section before the next major keyword
        next_keyword_index = next(
            (
                websites_section_raw.find(k)
                for k in ["Birthday", "Connected"]
                if k in websites_section_raw
            ),
            -1,
        )
        websites_section = (
            websites_section_raw[:next_keyword_index].strip()
            if next_keyword_index != -1
            else websites_section_raw.strip()
        )

        # Use defaultdict to simplify appending, removing nested ifs from the loop
        websites_lists = defaultdict(list)
        tokens = websites_section.split()
        i = 0
        while i < len(tokens) - 1:
            # A URL is followed by its type in parentheses, e.g., "example.com (Company)"
            if tokens[i + 1].startswith("(") and tokens[i + 1].endswith(")"):
                url = tokens[i]
                category = tokens[i + 1].strip("()").lower()
                websites_lists[category].append(url)
                i += 2
            else:
                i += 1

        # After collecting all URLs, format the dictionary to match the original logic
        # (single items as strings, multiple items as lists).
        websites = {
            cat: urls[0] if len(urls) == 1 else urls
            for cat, urls in websites_lists.items()
        }

        return websites, text.replace(f"Websites{websites_section_raw}", "")

    def get_contact_info(self, driver: webdriver.Chrome) -> Dict:
        """Opens contact info, scrapes details, and closes the modal."""
        try:
            with self._handle_contact_popup(driver) as popup:
                if not popup:
                    return {"contact_info": "No Data Found In Contact Info"}

                raw_text = popup.get_text(" ", strip=True)
                # Clean up text by removing the header
                if "Contact Info" in raw_text:
                    raw_text = raw_text.split("Contact Info", 1)[1]

                text = " ".join(raw_text.split())
                contact_info = {}

                # Sequentially parse each section from the text
                profile_url, text = self._parse_simple_field(text, "Profile")
                if profile_url:
                    contact_info["linkedin_profile"] = profile_url

                websites, text = self._parse_websites(text)
                if websites:
                    contact_info["websites"] = websites

                birthday, text = self._parse_simple_field(text, "Birthday")
                if birthday:
                    contact_info["birthday"] = birthday

                connected, text = self._parse_simple_field(text, "Connected")
                if connected:
                    contact_info["connected"] = connected

                return {"contact_info": contact_info}

        except Exception as e:
            logger.error(f"An error occurred while getting contact info: {e}")
            return {"contact_info": "Failed to retrieve data"}

    def _parse_overview(self, section: Tag) -> Optional[Dict[str, Optional[str]]]:
        """Parses the 'Overview' h2 and its corresponding p tag from a section."""
        h2 = section.find("h2")
        # Guard clause to exit early if this is not the overview section
        if not (h2 and h2.get_text(strip=True).lower() == "overview"):
            return None

        key = h2.get_text(strip=True).lower()
        p_tag = section.find("p")
        value = p_tag.get_text(" ", strip=True) if p_tag else None
        return {key: value}

    def _extract_dd_value(self, dd: Tag) -> str:
        """Extracts the text value from a <dd> tag based on specific child tags."""
        a_tag = dd.find("a")
        if not a_tag:
            return dd.get_text(" ", strip=True)

        span_ltr = a_tag.find("span", attrs={"dir": "ltr"})
        return span_ltr.get_text(strip=True) if span_ltr else a_tag.get_text(strip=True)

    def _parse_details_list(self, dl: Tag) -> Dict[str, str]:
        """Parses all dt/dd pairs within a <dl> tag and returns a dictionary."""
        details = {}
        for dt in dl.find_all("dt"):
            h3 = dt.find("h3")
            dd = dt.find_next_sibling("dd")

            # Use guard clauses to skip incomplete pairs
            if not (h3 and dd):
                continue

            key = h3.get_text(strip=True).lower()
            value = self._extract_dd_value(dd)
            details[key] = value
        return details

    def scrap_company_about_data(self, sections: List[Tag]) -> Dict:
        """
        From a company's About page, extracts 'Overview' and other details.
        """
        company_about_data = {}
        try:
            for section in sections:
                # 1. Attempt to parse an overview from the current section
                if overview := self._parse_overview(section):
                    company_about_data.update(overview)

                # 2. Attempt to parse a details list from the current section
                if dl_tag := section.find("dl"):
                    company_about_data.update(self._parse_details_list(dl_tag))

            return company_about_data

        except Exception as e:
            logger.error(f"Error scraping company about data: {e}")
            return {}

    def click_about_in_company_page(self, driver: webdriver.Chrome):
        """
        On the current company page, find the <a> with text 'About'
        inside the Organization's page navigation and click it.
        """
        try:
            # wait for the nav to appear
            nav = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located(
                    (
                        By.CSS_SELECTOR,
                        "nav[aria-label='Organization’s page navigation']",
                    )
                )
            )

            # find all <a> inside that nav
            links = nav.find_elements(By.TAG_NAME, "a")
            driver.execute_script(
                "window.scrollBy(0, arguments[0]);", secrets.randbelow(201) + 150
            )
            for link in links:
                if link.text.strip().lower() == "about":
                    WebDriverWait(driver, 10).until(EC.element_to_be_clickable(link))
                    link.click()
                    logger.debug("Clicked on 'About' link")
                    time.sleep(3)
                    active_page_sections = self.get_current_page_sections(driver)
                    data = self.scrap_company_about_data(active_page_sections)

                    return data

            logger.debug("No 'About' link found in nav.")
            return False

        except Exception as e:
            logger.error(f"Error clicking 'About': {e}")
            return False

    def current_company_info(
        self, driver: webdriver.Chrome, sections: List[Tag], url: str
    ):
        """Find the first company link in Experience and return it (and click it)."""
        try:
            first_company_link = self._get_first_company_link(sections)
            if not first_company_link:
                return None

            return self._click_and_scrape_company(driver, first_company_link, url)

        except Exception as e:
            logger.error(f"Error scraping experience: {e}")
            return None

    def _get_first_company_link(self, sections: List[Tag]) -> str | None:
        """Return the href of the first company link found in experience section."""
        for section in sections:
            exp_div = section.find(id="experience")
            if not exp_div:
                continue

            ul = exp_div.find_next("ul")
            if not ul:
                continue

            first_li = ul.find("li", recursive=False)
            if not first_li:
                continue

            company_a = first_li.find(
                "a", attrs={"data-field": "experience_company_logo"}
            )
            if company_a and company_a.has_attr("href"):
                return company_a["href"]

        return None

    def _click_and_scrape_company(
        self, driver: webdriver.Chrome, company_link: str, url: str
    ) -> dict:
        """Click company link and scrape data."""
        current_company_data = {}
        try:
            link_element = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, f"//a[@href='{company_link}']"))
            )
            link_element.click()
            time.sleep(3)

            current_company_data["linkedin_company_url"] = driver.current_url
            current_company_data["about"] = self.click_about_in_company_page(driver)

            return current_company_data

        except Exception as e:
            logger.error(f"Error clicking company link: {e}")

        finally:
            self.back_to_main_page(driver, url)

        return {}

    def _get_name(self, url: str) -> str:
        """
        Extracts the profile name from a LinkedIn profile URL.
        """
        parsed_url = urlparse(url=url)
        path_parts = parsed_url.path.strip("/").split("/")

        if len(path_parts) >= 2 and path_parts[0] == "in":
            return path_parts[1]

        return "unknown"

    def get_company_name_from_url(self, url: str) -> str:
        """
        Extracts a company name from a website URL.
        Example:
            'https://cognixinsights.com/' -> 'Cognix Insights'
            'https://careers.activision.com/?utm_source=linkedin' -> 'Activision'
        """
        try:
            # Use tldextract to parse the URL
            extracted = tldextract.extract(url)
            domain_name = (
                extracted.domain
            )  # e.g., "activision" from careers.activision.com

            # Make it look like a company name (capitalize each word if needed)
            company_name = " ".join(
                part.capitalize() for part in domain_name.split("-")
            )

            return company_name

        except Exception as e:
            logger.error(f"Error while extracting company name >> {e}")
            return "unknown"

    def _handle_company_scraping(
        self, company_name: str, session_name: str, profile_data: Dict
    ) -> None:
        """Check if company exists in DB, else trigger scraping and scoring."""
        try:
            if not self.db_conn.is_connected():
                self.db_conn.connect()

            doc = Company.objects(company_name=company_name).first()

            if doc:
                logger.debug(
                    f"Company '{company_name}' already in DB. Generating score..."
                )
                company_data = getattr(doc, "companyData", None)
                if company_data:
                    threading.Thread(
                        target=partial(
                            AIScoreGenerator(),
                            profile_name=self.profile_name,
                            candidate_profile=profile_data,
                            company_details=json.loads(company_data),
                        ),
                        daemon=True,
                    ).start()

                logger.debug("Saving profile data to database...")
                self.db_conn.update_db(
                    identifier_field="profile_name",
                    identifier_value=self.profile_name,
                    fields_data={
                        ProfileScraping.profileData.name: profile_data,
                        ProfileScraping.companyData.name: json.loads(company_data),
                    },
                    collection_object=ProfileScraping,
                )
            else:
                logger.debug(f"Scraping company website for '{company_name}'...")
                threading.Thread(
                    target=partial(
                        AIScraper(),
                        headless=True,
                        is_login_required=False,
                        session_name=session_name,
                        profile_data=profile_data,
                        profile_name=self.profile_name,
                        company_name=company_name,
                        request_url=profile_data["about"]["website"],
                    ),
                    daemon=True,
                ).start()

                logger.debug("Saving profile data to database...")
                self.db_conn.update_db(
                    identifier_field="profile_name",
                    identifier_value=self.profile_name,
                    fields_data={
                        ProfileScraping.profileData.name: profile_data,
                    },
                    collection_object=ProfileScraping,
                )
        except Exception as e:
            logger.error(f"Error handling company scraping for {company_name} >> {e}")

    def _generate_tags(self, profile_data: Dict) -> Dict:
        try:
            tags_template = """
                You are given the json data of a LinkedIn profile. 
                Your task is to extract and classify key tags into the following categories:

                1. **Technical Tags** - Specific skills, tools, technologies, programming languages, frameworks, certifications, or domain expertise.  
                Example: Python, Machine Learning, ReactJS, AWS, Salesforce, Data Science, Cloud Computing.

                2. **Positional Tags** - Roles, job positions, or organizational functions.  
                Example: Software Engineer, Data Scientist, Product Manager, CTO, HR Executive, Marketing Specialist.

                3. **Profile Tags** - Broader descriptive labels that summarize the person’s professional identity, achievements, or focus areas.  
                Example: Leader, Innovator, Startup Enthusiast, Mentor, Researcher, Problem Solver.

                ### Input:
                {profile_data}

                ### Output (JSON format):
                ```json{{
                    "technical_tags": [...],
                    "positional_tags": [...],
                    "profile_tags": [...]
                }}```
            """
            tags_prompt = ChatPromptTemplate.from_messages(
                [("system", tags_template), ("user", "{profile_data}")]
            )
            tag_generation_chain = tags_prompt | llm | StrOutputParser()

            raw_response = tag_generation_chain.invoke(
                {"profile_data": json.dumps(profile_data)}
            )
            tags = json.loads(raw_response.replace("`", "").replace("json", ""))
            return tags

        except Exception as e:
            logger.error(f"Error while generate tags >> {e}")

    def __call__(
        self,
        login_url: str,
        session_name: str,
        profile_url: str,
        is_login_required: bool,
        cookies: List[Dict[str, Union[Dict, str, List, Any]]],
        headless: bool = True,
    ) -> Dict:
        try:
            profile_data = {}
            self.profile_name = self._get_name(url=profile_url)

            logger.debug(f"Login Profile >> {profile_url}")
            self._login(
                cookies=cookies,
                session_name=session_name,
                url=login_url,
                headless=headless,
                is_login_required=is_login_required,
            )

            self.session.get(profile_url)
            WebDriverWait(self.session, 10).until(
                EC.visibility_of_element_located((By.TAG_NAME, "body"))
            )

            logger.debug("Extract main page sections...")
            main_page_sections = self.get_current_page_sections(driver=self.session)

            logger.debug("Extract personal info...")
            personal_info = self.get_personal_info(driver=self.session)
            profile_data.update(personal_info)

            logger.debug("Extract contact info...")
            conact_info = self.get_contact_info(driver=self.session)
            profile_data.update(conact_info)

            logger.debug("Extract about details...")
            about_info = self.get_about_data(sections=main_page_sections)
            profile_data.update(about_info)

            logger.debug("Extracting company url...")
            try:
                main_page_sections = self.get_current_page_sections(driver=self.session)

                current_company_info = self.current_company_info(
                    driver=self.session, sections=main_page_sections, url=profile_url
                )
                profile_data.update(current_company_info)
            except Exception as e:
                pass

            logger.debug("Extracting experience...")
            experience_info = self.get_experience(
                driver=self.session, sections=main_page_sections, url=profile_url
            )
            profile_data.update(experience_info)

            main_page_sections = self.get_current_page_sections(driver=self.session)

            logger.debug("Extarcting education...")
            education_info = self.get_education(sections=main_page_sections)
            profile_data.update(education_info)

            tags = self._generate_tags(profile_data=profile_data)
            profile_data.update(tags)

            try:
                company_website = ""

                # Validate and extract website
                if isinstance(profile_data, Dict):
                    about_data = profile_data.get("about", {})
                    if isinstance(about_data, Dict):
                        company_website = about_data.get("website", "")

                # Handle company website scraping or log missing website
                if company_website:
                    company_name = self.get_company_name_from_url(url=company_website)
                    self._handle_company_scraping(
                        company_name=company_name,
                        session_name=session_name,
                        profile_data=profile_data,
                    )
                else:
                    logger.warning("No company website found in profile data.")
                    self.db_conn.update_db(
                        identifier_field="profile_name",
                        identifier_value=self.profile_name,
                        fields_data={ProfileScraping.profileData.name: profile_data},
                        collection_object=ProfileScraping,
                    )
                    threading.Thread(
                        target=partial(
                            AIScoreGenerator(),
                            profile_name=self.profile_name,
                            candidate_profile=profile_data,
                            company_details={},
                        ),
                        daemon=True,
                    ).start()

                return profile_data

            except Exception as e:
                logger.error(f"Error while running traditional profile scraper >> {e}")
                return {}

        except Exception as e:
            logger.error(f"Error while run traditional profile scrapper >> {e}")
            return {}
        finally:
            self.profile_name = None
