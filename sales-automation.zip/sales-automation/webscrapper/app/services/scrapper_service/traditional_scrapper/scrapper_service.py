import time
from typing import Any, Dict, List

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from ....core.config import model
from ....core.selenium_session import SeleniumManager
from ...utils.log import logger

BUSINESS_SUMMARY = """
    Aspire Softserv is a leading software development company offering tailored solutions to businesses globally.
    With over 14 years of experience, they specialize in digital product engineering, web and mobile development,
    digital transformation, and ERP solutions. They help businesses grow by automating processes, reducing costs,
    and creating scalable architectures. Aspire caters to various industries like healthcare, finance, telecom,
    e-commerce, and more, emphasizing operational scalability, legacy system modernization, and customer engagement.
    Technologies Used: Python, Odoo, React, AI, Cloud Services, ERP, Digital Transformation, Web & Mobile Development.
    Projects Accomplished:
    1. Custom Software Development Portals for Executive Search
    2. Legacy Systems Modernization for Fortune 500 Companies
    3. FinTech Client Portal for Investment & Security
    4. Automation of Business Processes for IT Companies
    5. Scalable Solutions for Global Operations Expansion
"""

SCROLL_INTO_VIEW_CENTER = "arguments[0].scrollIntoView({block:'center'});"
CLICK_BUTTON_ARGUMENT = "arguments[0].click();"
# LinkedIn Scraper Class (remains unchanged)


class LinkedInScraper:
    def __init__(self):
        self.driver = None
        self.manager = SeleniumManager()
        self.session_name = "sales_navigator"

    def setup_driver(self):
        self.driver = self.manager.create_session(
            headless=True, is_login_required=True, session_name=self.session_name
        )

    def clean(
        self, text, key=None
    ):  # This will replace 'word ... Show more' with just a '.'
        if isinstance(text, dict):
            text = text[key]
        return text.replace("Show less", " ")

    # Load cookies method
    def load_cookies(self, cookies: List[Dict[str, Any]]):
        if not cookies:
            logger.debug("⚠️ No cookies provided in the request.")
            return False

        try:
            # Convert the cookie data to a format that can be added to Selenium
            selenium_cookies = []
            for cookie in cookies:
                selenium_cookie = {
                    "name": cookie["name"],
                    "value": cookie["value"],
                    "domain": cookie["domain"],
                    "path": cookie["path"],
                    "secure": cookie.get("secure", False),
                    "httpOnly": cookie.get("httpOnly", False),
                }
                selenium_cookies.append(selenium_cookie)

            time.sleep(2)

            for desired_cookie in selenium_cookies:
                self.driver.add_cookie(desired_cookie)

        except Exception as e:
            logger.error(f"cookie_error:>> {e}")

    def extract_activity_data(self):
        try:
            # 1 Wait for the relationship/activity section
            activity_section = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "relationship-section"))
            )

            # 2️ Click 'See all activities' if the button exists
            try:
                see_all_btn = WebDriverWait(activity_section, 5).until(
                    EC.element_to_be_clickable(
                        (
                            By.XPATH,
                            ".//button[span[normalize-space()='See all activities']]",
                        )
                    )
                )
                self.driver.execute_script(SCROLL_INTO_VIEW_CENTER, see_all_btn)
                self.driver.execute_script(CLICK_BUTTON_ARGUMENT, see_all_btn)
                time.sleep(1)  # small pause so the list can render
            except Exception:
                logger.info(
                    "No 'See all activities' button found (maybe already expanded)"
                )

            # 3️ Wait for the UL that contains the activity items
            activity_ul = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located(
                    (
                        By.XPATH,
                        "//ul[contains(@class,'_list_f6tp8x') and contains(@class,'_looseSpacing_f6tp8x')]",
                    )
                )
            )

            # 4️ Gather each LI and parse the components
            post_data = []
            li_items = activity_ul.find_elements(By.TAG_NAME, "li")

            for li in li_items:
                try:
                    # Extract elements safely
                    name_action_elem = li.find_element(By.XPATH, ".//h4")
                    timestamp_elem = li.find_element(By.XPATH, ".//time")
                    comment_elem = li.find_element(
                        By.XPATH, ".//span[contains(@class,'_text-max-width_ulix4y')]"
                    )

                    name_action = name_action_elem.text.strip()
                    timestamp = timestamp_elem.text.strip()
                    comment = comment_elem.text.strip()

                    post_summary = f"{name_action} ({timestamp}): {comment}"
                    post_data.append(post_summary)

                except Exception as parse_err:
                    logger.warning(f"⚠️ Could not parse an activity item: {parse_err}")

            return {"posts": post_data}

        except Exception:
            logger.error("⚠️ Error extracting activity data", exc_info=True)
            return {"posts": []}

    def extract_education_data(self):
        try:
            education_sections = WebDriverWait(self.driver, 6).until(
                EC.presence_of_all_elements_located(
                    (By.XPATH, "//section[@data-sn-view-name='feature-lead-education']")
                )
            )

            education_list = []

            for section in education_sections:
                # Select each education block (not just h3)
                edu_blocks = section.find_elements(
                    By.XPATH,
                    ".//div[contains(@class, 'AcJrCRCVjmMebzrCRlyoYAFHplfwMYIk')]",
                )

                for block in edu_blocks:
                    try:
                        # University/Institute name
                        school = block.find_element(
                            By.XPATH, ".//h3[@data-anonymize='education-name']//a"
                        ).text.strip()

                        # Degree & Field (e.g., MPhil + Computer Science)
                        degree_field_spans = block.find_elements(
                            By.XPATH, ".//p[1]//span"
                        )
                        degree = (
                            degree_field_spans[0].text.strip()
                            if len(degree_field_spans) > 0
                            else ""
                        )
                        field = (
                            degree_field_spans[1].text.strip()
                            if len(degree_field_spans) > 1
                            else ""
                        )

                        # Time duration
                        date_span = block.find_element(
                            By.XPATH, ".//p[contains(@class, 'lowEmphasis')]//span"
                        )
                        duration = date_span.text.strip()

                        education_list.append(
                            {
                                "school": school,
                                "degree": degree,
                                "field": field,
                                "duration": duration,
                            }
                        )

                    except Exception as item_err:
                        logger.warning(
                            f"⚠️ Error parsing individual education entry: {item_err}"
                        )

            return {"education": education_list}

        except Exception as e:
            logger.error(f"⚠️ Error extracting education data: {e}")
            return {"education": []}

    def safe_find_text(self, selector, value, element):
        try:
            text = element.find_element(selector, value).text.strip()
            return text.replace("Show less", "")
        except Exception:
            return None

    def parse_experience_li(self, li_element):
        # Extract each field
        title = self.safe_find_text(
            By.XPATH, ".//h2[@data-anonymize='job-title']", li_element
        )
        company = self.safe_find_text(
            By.XPATH, ".//p[@data-anonymize='company-name']", li_element
        )
        date_and_tenure = self.safe_find_text(
            By.XPATH,
            ".//p[span[contains(@class,'EWcqvVrvmAxmAWAPhNQVtYrpqqtkAuFrXZy')]]",
            li_element,
        )
        location = self.safe_find_text(
            By.XPATH, ".//p[contains(@class,'_lowEmphasis') and not(span)]", li_element
        )
        description = self.safe_find_text(
            By.XPATH,
            ".//div[@data-anonymize='person-blurb'] | .//p[@data-anonymize='person-blurb']",
            li_element,
        )

        # Optional: Split date range and tenure
        if date_and_tenure and "–" in date_and_tenure:
            parts = date_and_tenure.split("\n")
            date_range = parts[0].strip()
            tenure = parts[1].strip() if len(parts) > 1 else None
        else:
            date_range = date_and_tenure
            tenure = None

        return {
            "title": title,
            "company": company,
            "date_range": date_range,
            "tenure": tenure,
            "location": location,
            "description": description,
        }

    def get_outer_li(self):
        experience_section = WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.ID, "experience-section"))
        )
        logger.info("Experience section found.")
        # 2️⃣ Click the “Show all positions” button if present
        try:
            show_all_btn = WebDriverWait(
                experience_section, 5
            ).until(  # Increased wait time slightly
                EC.element_to_be_clickable(
                    (
                        By.XPATH,
                        ".//button[contains(., 'Show all positions') or span[contains(normalize-space(.), 'Show all positions')]]",
                    )
                )
            )
            self.driver.execute_script(SCROLL_INTO_VIEW_CENTER, show_all_btn)
            self.driver.execute_script(CLICK_BUTTON_ARGUMENT, show_all_btn)
            logger.info("Clicked 'Show all positions' button.")
            time.sleep(2)  # Give LinkedIn more time to load new positions
        except Exception:
            logger.info("No 'Show all positions' button found or already expanded.")
        # 3️⃣ Click every collapsed “ellipsis‑button”
        # This XPath is more robust by looking for buttons with specific 'id' pattern
        # and visible text that implies "show more" functionality.
        ellipsis_buttons: List = experience_section.find_elements(
            By.XPATH,
            ".//button[contains(@id,'ellipsis-button-') and contains(@id,'-clamped-content') or contains(@aria-expanded, 'false')]",
        )
        logger.info(f"Found {len(ellipsis_buttons)} ellipsis buttons to click.")
        for btn in ellipsis_buttons:
            try:
                self.driver.execute_script(SCROLL_INTO_VIEW_CENTER, btn)
                self.driver.execute_script(CLICK_BUTTON_ARGUMENT, btn)
                time.sleep(0.5)  # Small delay for each click
            except Exception as click_err:
                logger.warning(
                    f"⚠️ Couldn't click sub-position button: {click_err.args[0] if click_err.args else str(click_err)}"
                )
        # 4️⃣ Wait for *all* <li> items under the first UL in scroll-to-experience-sectio
        outer_ul = WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(
                (
                    By.CSS_SELECTOR,
                    "section#scroll-to-experience-section > div > "
                    "ul.EkLSvbutcEBrUAXAOwWRTfzDjbKmuGZJuLpQaJo",  # exact class name
                )
            )
        )
        # 2️⃣  Now collect only its direct <li> children
        li_items = outer_ul.find_elements(By.CSS_SELECTOR, ":scope > li")
        return li_items

    def extract_experience_data(self) -> Dict[str, List[Dict[str, str]]]:
        experience_list = []

        try:
            # 1️⃣ Wait for the outer <div id="experience-section">

            # Re-find the list items after expansions
            li_items = self.get_outer_li()
            logger.info(f"Found {len(li_items)} experience list item(s) for parsing.")

            # 5️⃣ Extract text for each job / position
            for li in li_items:
                try:
                    # 1. Does this <li> have a child <ul>?
                    # nested_uls = li.find_elements(By.XPATH, "./ul")
                    nested_uls = li.find_elements(
                        By.XPATH, "./ul[@class='dTuJyNtqCoFlVTuuOgrMWRdWVPjZUxcD']"
                    )

                    if nested_uls:
                        # --- MULTI‑ROLE ENTRY ------------------------------------
                        company = self.safe_find_text(
                            By.XPATH, ".//h2[@data-anonymize='company-name']", li
                        )  # gets company + maybe top date range
                        nested_roles = nested_uls[0].find_elements(
                            By.CSS_SELECTOR, ":scope > li"
                        )
                        logger.debug(
                            f"Found {len(nested_roles)} nested roles for {company}"
                        )

                        for nested in nested_roles:
                            title = self.safe_find_text(
                                By.XPATH, ".//*[@data-anonymize='job-title']", nested
                            )
                            date_range = self.safe_find_text(
                                By.XPATH,
                                ".//p[contains(@class, '_sizeXSmall_1e5nen')]",
                                nested,
                            )

                            tenure = self.safe_find_text(
                                By.XPATH,
                                ".//p[contains(@class, '_sizeXSmall_1e5nen')]",
                                nested,
                            )

                            location = self.safe_find_text(
                                By.XPATH,
                                ".//p[contains(@class, 'lowEmphasis')][not(span)]",
                                nested,
                            )

                            description = self.safe_find_text(
                                By.XPATH, ".//*[@data-anonymize='person-blurb']", nested
                            )

                            experience_list.append(
                                {
                                    "title": title,
                                    "company": company,
                                    "date_range": date_range,
                                    "tenure": tenure,
                                    "location": location,
                                    "description": description,
                                }
                            )
                    else:
                        # --- SINGLE‑ROLE ENTRY -----------------------------------
                        role_info = self.parse_experience_li(li)
                        experience_list.append(role_info)

                except Exception as parse_err:
                    # Log the specific error message from the exception
                    logger.warning(
                        f"⚠️ Could not parse an experience item: {parse_err.args[0] if parse_err.args else str(parse_err)}"
                    )

            return {"experience": experience_list}

        except Exception as e:
            logger.error(
                f"⚠️ Error extracting experience data: {e.args[0] if e.args else str(e)}",
                exc_info=False,
            )
        return {"experience": []}

    def extract_interests_data(self):
        try:
            self.driver.execute_script(
                "window.scrollTo(0, document.body.scrollHeight);"
            )
            time.sleep(3)
            interests_section = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located(
                    (By.XPATH, "//section[@id='interests-section']")
                )
            )
            interests_entries = interests_section.find_elements(
                By.XPATH,
                ".//span[@class='_bodyText_1e5nen _default_1i6ulk _sizeMedium_1e5nen _weightBold_1e5nen']",
            )
            interests_list = [entry.text for entry in interests_entries if entry.text]
            return {"interests": interests_list}
        except Exception as e:
            logger.error(f"⚠️ Error extracting interests data: {e}")
            return {"interests": []}

    def extract_skills_data(self):
        try:
            skills_section = WebDriverWait(self.driver, 5).until(
                EC.presence_of_element_located(
                    (By.XPATH, "//section[@data-sn-view-name='feature-lead-skills']")
                )
            )
            skills_entries = skills_section.find_elements(By.XPATH, ".//p")
            skills_list = [
                entry.get_attribute("title")
                for entry in skills_entries
                if entry.get_attribute("title")
            ]
            return {"skills": skills_list}
        except Exception as e:
            logger.error(f"⚠️ Error extracting skills data: {e}")
            return {"skills": []}

    def __call__(self, profile_url: str, cookies: List[Dict[str, Any]]):
        try:
            self.setup_driver()
            self.driver.get("https://www.linkedin.com/sales/login")
            time.sleep(3)
            self.load_cookies(cookies)

            self.driver.get(profile_url)
            time.sleep(5)

            name = (
                WebDriverWait(self.driver, 5)
                .until(
                    EC.presence_of_element_located(
                        (By.XPATH, "//section[contains(@class, '_header_')]//h1")
                    )
                )
                .text
            )

            location = "Location Not Found"
            try:
                location = (
                    WebDriverWait(self.driver, 5)
                    .until(
                        EC.presence_of_element_located(
                            (
                                By.XPATH,
                                "//*[@id='profile-card-section']/section[1]/div[1]/div[4]/div[1]",
                            )
                        )
                    )
                    .text
                )
            except Exception:
                logger.debug("Location of the  Profile Not Found.")

            about = "About section not available"
            try:
                # 1) Try to click the 'Show more' button using its data-test attribute
                try:
                    expand_btn = WebDriverWait(self.driver, 5).until(
                        EC.presence_of_element_located(
                            (
                                By.XPATH,
                                "//section[@id='about-section']//button[contains(@id, 'ellipsis-button-') and contains(@id, '-clamped-content')]",
                            )
                        )
                    )
                    try:
                        expand_btn.click()
                    except Exception:
                        # fallback to JS click
                        self.driver.execute_script(CLICK_BUTTON_ARGUMENT, expand_btn)
                except Exception:
                    # no button found or clickable in 5s → assume already expanded
                    pass

                # 2) Now grab the full <p> text
                about = (
                    WebDriverWait(self.driver, 5)
                    .until(
                        EC.presence_of_element_located(
                            (By.XPATH, '//*[@id="about-section"]/p')
                        )
                    )
                    .text
                )

            except Exception as e:
                logger.warning(f"Failed to extract About section: {e}")

            about = self.clean(about)
            experience_data = self.extract_experience_data()

            education_data = self.extract_education_data()
            interests_data = self.extract_interests_data()
            skills_data = self.extract_skills_data()

            activity_data = self.extract_activity_data()
            logger.debug(f"experience_data>> {experience_data}")
            profile_data = {
                "name": name,
                "location": location,
                "about": about,
                "experience": experience_data["experience"],
                "education": education_data["education"],
                "interests": interests_data["interests"],
                "skills": skills_data["skills"],
                "posts": activity_data["posts"],
            }
            return profile_data
        except Exception as e:
            logger.error(f"⚠️ Error scraping profile: {e}")
            return {"error": f"Error scraping profile: {e}"}
        finally:
            self.driver.quit()


def format_section(data):
    if not data:
        return "Not Available"
    if isinstance(data, list):
        if all(isinstance(item, dict) for item in data):
            return "\n".join(
                [", ".join(f"{k}: {v}" for k, v in item.items()) for item in data]
            )
        return "\n".join(str(item) for item in data)
    return str(data)


def gen_mail(client_data):
    client_data = f"""
            Name: {client_data.get('name', 'Not Available')}
            Location: {client_data.get('location', 'Not Available')}
            About: {client_data.get('about', 'Not Available')}
            Experience: {format_section(client_data.get('experience', []))}
            Education: {format_section(client_data.get('education', []))}
            Interests: {', '.join(client_data.get('interests', []))}
            Skills: {', '.join(client_data.get('skills', []))}
            Recent Posts: {', '.join(client_data.get('posts', []))}
        """
    # logger.debug(f"Data Received:>>> {client_data}")
    try:
        prompt = f"""
            You are a world-class salesman with deep IT knowledge specializing in AI, Cloud services, and legacy system modernization. Your task is to generate a business development email to a potential client. Keep the email concise (under 200 words), professional, and compelling.
            **Client Profile:**
            {client_data}

            **Our Business Summary:**
            {BUSINESS_SUMMARY}

            Based on the client's profile and our business summary, write the email. While analyzing the client's profile, check if his recent posts hint at a requirement or hiring for any tech-related roles or topics, if not present, then ignore the recent posts and continue email generation based on the rest of the data. Specifically:
            * Highlight how our company can help the client address their needs and pain points.
            * Suggest how our services can provide a valuable solution, focusing on AI, Cloud services, and legacy system modernization.
            * Make a clear and compelling pitch.
            * Note you must not include an AI response kind of message like 'Ok here's your answer'. Just direct response.
        """
        response = model.generate_content(prompt)
        _ = response.text.strip()
        return response.candidates[0].content.parts[0].text.strip()

    except Exception as e:
        logger.error(f"Exception: {e}")


def gen_connection_request(client_data):
    try:
        prompt = f"""
            You are a world-class professional with expertise in AI, Cloud services, and legacy system modernization. Your task is to craft a concise and professional LinkedIn connection request to a potential client. Keep it friendly, brief, and engaging, while aiming to build a relationship.

            **Client Profile:**
            {client_data}

            **Our Business Summary:**
            {BUSINESS_SUMMARY}

            Based on the client's profile and our business summary, write the connection request. Specifically:
            * Greet the client with a personalized message.
            * Express interest in connecting based on mutual interests, and offer value in a non-intrusive manner.
            * Briefly mention how your expertise in AI, Cloud services, or legacy system modernization could align with their needs.
            * Keep the message brief and professional (under 150 words).
            *Note you must not include an AI response kind of message like 'Ok here's your answer'. Just direct response.
        """
        response = model.generate_content(prompt)
        return response.candidates[0].content.parts[0].text.strip()

    except Exception as e:
        logger.error(f"Exception: {e}")
