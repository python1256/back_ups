import json
from typing import Dict

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_google_genai import ChatGoogleGenerativeAI

from ....core.config import llm
from ...utils.log import logger


class AIGenerator:
    def __init__(self):
        self.llm: ChatGoogleGenerativeAI = llm

    def _get_urls(self, page_content: str, company_url: str):
        """
            return urls in given format
        ```json{
                "company_details": "",
                "Business_model":"",
                "clients":""
            }
        """
        url_template = """
            You are an expert at finding the most relevant URL endpoints from the given HTML-transformed text.

            **Task:**
            - Identify full (absolute) URLs for the following categories:
            1. Company details (basic info, target areas, working sectors, about the company)
            2. Business model of the company (how the company generates value, products/services, monetization model)
            3. Tech stack (technologies, frameworks, tools, or platforms used by the company)
            4. Clients of the company (customers, partners, case studies, or testimonials)

            **Inputs:**
            - Text: {text}
            - Base URL: {company_url}

            **Note:**
            - Only provide a single, most relevant URL for each field.
            - The URL must be a **full absolute URL** (no relative paths).
            - If a category cannot be found, return `null` for that field.
            - Do not give null if not found. 
            
            **Output (JSON only):**
            ```json
            {{
                "company_details": "<full URL with company details/about/working sectors>",
                "business_model": "<full URL with business model information>",
                "tech_stack": "<full URL with technologies/tech stack used>",
                "clients": "<url contains client details>"
            }}
        """

        url_prompt = ChatPromptTemplate.from_messages(
            [("system", url_template), ("user", "[{text},{company_url}]")]
        )
        chain = url_prompt | self.llm | StrOutputParser()

        urls = chain.invoke({"text": page_content, "company_url": company_url})
        logger.debug(f"Interesing urls >> {urls}")
        return urls.replace("`", "").replace("json", "")

    def _get_insights(self, page_content: str, details: str) -> Dict:
        try:
            self.business_model_response = {
                "name": "<Business model name>",
                "description": "<Brief explanation of the business model>",
                "plans": [
                    {
                        "title": "<Business plan title>",
                        "summary": "<Short description of the plan>",
                    }
                ],
            }
            self.company_details_response = {
                "name": "<Company name>",
                "founded_year": "<Year the company was founded>",
                "vision": "<Company vision or mission statement>",
                "services": ["<Service 1>", "<Service 2>"],
                "company_size": "<Number of employees or size category>",
                "leadership_team": [
                    {"name": "<Leader's full name>", "title": "<Leader's title/role>"}
                ],
            }
            self.client_details_response = {
                "clients": [
                    {
                        "name": "<Client name (company or individual)>",
                        "industry": "<Industry/sector of the client>",
                        "description": "<Brief client details or relationship>",
                    }
                ]
            }
            self.tech_stack_response = {
                "tech_stack": ["<List of technology and services>"]
            }

            insights_template = """
                You are an expert data extractor.

                **Task:**  
                - From the raw web text, extract the specified details.  
                - Do not add or guess information.  
                - Return output strictly in JSON format. 

                **Details to extract:** {details_to_find}  
                **Raw text:** {raw_web_text}  

                **Output:**  
                ```json
                {custom_response}
                ```
            """

            insights_prompt = ChatPromptTemplate.from_messages(
                [
                    ("system", insights_template),
                    ("user", "{raw_web_text}"),
                ]
            )

            insights_chain = insights_prompt | self.llm | StrOutputParser()

            logger.debug("insights chain invoked.")

            if details == "company_details":
                custom_response = self.company_details_response
            elif details == "business_model":
                custom_response = self.business_model_response
            elif details == "tech_stack":
                custom_response = self.tech_stack_response
            elif details == "clients":
                custom_response = self.client_details_response
            else:
                custom_response = {}

            insights = insights_chain.invoke(
                {
                    "raw_web_text": page_content,
                    "custom_response": json.dumps(custom_response),
                    "details_to_find": details,
                }
            )

            insights_dict = insights.replace("`", "").replace("json", "")
            return json.loads(insights_dict)
        except Exception as e:
            logger.error(f"Error while get insights from text >> {e}")
            return {}
