import json
from typing import Dict, List, Optional, Union

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

from ....core.config import llm
from ....database.mongo_database import MongoDBConnection
from ....database.profile_data_schema import Company, ProfileScraping
from ...utils.load_env import environment
from ...utils.log import logger


class AIScoreGenerator:
    def __init__(self):
        self.score_template = """
            You are a professional evaluator specializing in analyzing how strong a person is **within their role or profession**, regardless of company fit.  
            Your goal is to assess the **depth, maturity, and impact** of a person’s career profile using clear evidence (experience, achievements, leadership, technical or domain mastery).

            ---

            ### EVALUATION PRINCIPLES

            1. **Evidence-Driven Evaluation:**  
            - Only score what is explicitly mentioned — no assumptions.  
            - Reward quantifiable outcomes, leadership, complexity, and real-world impact.  
            - Deduct points for vague, generic, or missing evidence.

            2. **Weighted Scoring Factors (Total = 100%)**
            - Role Experience & Growth → 30%  
            - Achievements & Impact → 25%  
            - Skills & Expertise Depth → 25%  
            - Leadership / Initiative / Ownership → 10%  
            - Consistency & Stability (career progression, clarity) → 10%

            3. **Scoring Guidelines:**
            - **Role Experience (30%)**
                - 10+ years with steady growth & senior-level roles → 90–100  
                - 5–9 years with moderate progression → 70–89  
                - 2–4 years or narrow scope → 50–69  
                - <2 years or unclear experience → below 50  

            - **Achievements & Impact (25%)**
                - Strong metrics, ownership of key outcomes → 85–100  
                - Moderate achievements (some outcomes but vague metrics) → 65–84  
                - Descriptive but no measurable impact → 45–64  
                - Missing or generic claims → below 45  

            - **Skills & Expertise (25%)**
                - Deep technical or domain mastery, certifications, mentoring others → 85–100  
                - Good hands-on skill set but limited breadth → 65–84  
                - Generic skill mentions only → 45–64  
                - Weak or unclear technical capability → below 45  

            - **Leadership / Initiative (10%)**
                - Led teams, mentored others, took ownership of outcomes → 85–100  
                - Some leadership exposure or side initiatives → 65–84  
                - Minimal leadership or passive contributor → below 65  

            - **Consistency & Stability (10%)**
                - Clear role progression and stable growth → 85–100  
                - Some job-hopping but overall coherent path → 65–84  
                - Frequent switches or unclear direction → below 65  

            4. **Scoring Ranges (Overall Strength):**
            - Excellent: 85–100  
            - Strong: 70–84  
            - Moderate: 55–69  
            - Developing: below 55

            ---

            ### INPUT:
            Candidate Profile:
            {candidate_profile}

            ---

            ### OUTPUT FORMAT (STRICTLY JSON ONLY):
            {{
                "role": "<Candidate's current or most recent role/title>",
                "analysis": "<Excellent | Strong | Moderate | Developing>",
                "overall_strength_score": <integer between 0 and 100>,
                "overview": "<2–3 sentence factual summary describing candidate’s overall role maturity and impact>",
                "profile_summary": "<Concise factual summary of experience, skills, and achievements>",
                "factor_scores": {{
                    "role_experience_growth": <0–100>,
                    "achievements_impact": <0–100>,
                    "skills_expertise_depth": <0–100>,
                    "leadership_initiative": <0–100>,
                    "consistency_stability": <0–100>
                }},
                "insights": "<Brief insight on standout strengths or improvement areas>",
                "description": "<Persona-style description (e.g., 'Mid-level software engineer with strong technical ownership and growing leadership potential.')>",
                "factors": [
                    {{
                        "name": "Role Experience & Growth",
                        "score": <integer>,
                        "explanation": "<Justify based on years, promotions, and career trajectory>"
                    }},
                    {{
                        "name": "Achievements & Impact",
                        "score": <integer>,
                        "explanation": "<Describe evidence of impact or quantifiable outcomes>"
                    }},
                    {{
                        "name": "Skills & Expertise Depth",
                        "score": <integer>,
                        "explanation": "<Explain skill strength and specialization level>"
                    }},
                    {{
                        "name": "Leadership / Initiative",
                        "score": <integer>,
                        "explanation": "<Note any leadership, mentoring, or project ownership>"
                    }},
                    {{
                        "name": "Consistency & Stability",
                        "score": <integer>,
                        "explanation": "<Comment on job stability and progression pattern>"
                    }}
                ],
                "tips_to_improve": [
                    {{
                        "area": "<Specific development area>",
                        "suggestion": "<Concrete step to grow expertise or career impact>",
                        "expected_score_gain": <integer between 0 and 15>
                    }}
                ]
            }}

            ---

            ### IMPORTANT:
            - Make sure each factor score reflects evidence strength.
            - Ensure the overall score = weighted sum of factors.
            - Scores must differ clearly between junior, mid-level, and senior profiles.
            - Never inflate scores for vague or missing data.
            """

        self.db_conn = MongoDBConnection(host=environment.MONGO_HOST)
        self.score_prompt = ChatPromptTemplate.from_messages(
            [("system", self.score_template), ("user", "{candidate_profile}")]
        )

        self.score_chain = self.score_prompt | llm | StrOutputParser()

    def _generate_business_decision(
        self,
        person_company: Dict,
        person_profile: Dict,
        client_requirements: Dict,
        client_company: Dict,
    ) -> Dict:
        try:
            template = """
                You are a business intelligence and partnership evaluation expert.  
                Your task is to determine if an individual (prospect) is likely to give business or collaborate with the client company.

                ### Entities
                - Prospect Individual Profile: {person_profile}
                - Prospect Company Details: {person_company}
                - Client Company (seeking business): {client_company}
                - Client Collaboration / Business Requirements: {client_requirements}

                ### Important Context
                - The **client is looking for business.**
                - The individual you analyze is the **potential business giver / buyer / partner.**
                - Do NOT match personal traits or persona.
                - Evaluate purely on **business relevance, authority, company fit, and likelihood to generate business.**

                ---

                ### Evaluation Logic

                You must analyze:

                #### 1. Prospect Individual
                - Authority, title, and decision-making power
                - Purchasing influence and business responsibility
                - Relevant experience in:
                - Buying similar services
                - Working with vendors/partners

                #### 2. Prospect Company → Client Business Fit
                - Industry & business model match
                - Company size & maturity match (startup / scale-up / enterprise)
                - Pain points solved by the client’s offering
                - Budget & spending capability
                - Tech/stack/business compatibility

                #### 3. Business Opportunity
                - Can the prospect company realistically benefit from the client's offering?
                - Do they operate in a domain that needs the client's solution?
                - Do they have the infrastructure, scale, or urgency?

                #### 4. Interest & Collaboration Signal
                - Public interest in similar tech/services
                - Partnership or outsourcing openness (if info exists)
                - If data missing, score conservatively

                ---

                ### Weighted Scoring (0-100)

                | Factor | Weight |
                |---|---|
                | Authority to approve/decide business | 30% |
                | Industry & business relevance | 20% |
                | Need for client’s product/service | 20% |
                | Company scale/fit & budget ability | 15% |
                | Tech/operational compatibility | 10% |
                | Collaboration openness / signals | 5% |

                Penalize when:
                - Company type does NOT need the client’s product/service
                - Prospect lacks decision authority
                - Budget/stage mismatch
                - Competitive conflict
                - No evidence of tech/solution dependency

                ---

                ### Output Format (Strict JSON)

                ```json
                {{
                    "decision": "[Highly Likely | Likely | Neutral | Unlikely | Very Unlikely]",
                    "business_opportunity_score": 0-100,
                    "rationale": "Provide a detailed rationale covering opportunity relevance, decision-maker power, company needs and maturity, risks, conversion likelihood, and how this person can support our business growth.",
                    "factors": {{
                        "authority": "",
                        "industry_fit": "",
                        "need_alignment": "",
                        "company_level_budget_fit": "",
                        "tech_fit": "",
                        "collaboration_openness": "",
                        "risks": "",
                        "strategic_opportunities": ""
                    }},
                    "score_breakdown": {{
                        "authority": "out of 10/10",
                        "industry_fit": "out of 10/10",
                        "need_alignment": "out of 10/10",
                        "company_level_budget_fit": "out of 10/10",
                        "tech_fit": "out of 10/10",
                        "collaboration_openness": "out of 10/10"
                    }},
                    "final_reasoning": "",
                    "recommended_outreach_strategy": ""
                }}
            """

            business_decision_prompt = ChatPromptTemplate.from_messages(
                [("system", template), ("user", "{person_profile}")]
            )
            business_decision_chain = business_decision_prompt | llm | StrOutputParser()

            logger.debug("Generating business decision description...")
            business_decision_response = business_decision_chain.invoke(
                {
                    "person_company": person_company,
                    "person_profile": person_profile,
                    "client_requirements": client_requirements,
                    "client_company": client_company,
                }
            )
            return json.loads(
                business_decision_response.replace("`", "json").replace("json", "")
            )
        except Exception as e:
            logger.error(f"Error while generate business decision >> {e}")

    def __call__(
        self,
        profile_name: str,
        candidate_profile: Union[List, Dict, str],
        company_details: Union[List, Dict, str],
    ) -> Optional[Union[List, Dict]]:
        try:
            logger.debug("Generating profile score ...")
            score_response = self.score_chain.invoke(
                {
                    "candidate_profile": json.dumps(candidate_profile),
                    "company_details": json.dumps(company_details),
                }
            )

            score_json_response = json.loads(
                score_response.replace("`", "").replace("json", "")
            )

            self.db_conn.update_db(
                identifier_field="profile_name",
                identifier_value=profile_name,
                collection_object=ProfileScraping,
                fields_data=dict(
                    {
                        ProfileScraping.scoringData.name: score_json_response,
                    }
                ),
            )
            return score_json_response
        except Exception as e:
            logger.error(f"Error while generate profile score >> {e}")
