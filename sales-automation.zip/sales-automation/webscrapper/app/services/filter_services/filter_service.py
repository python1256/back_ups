from typing import Any, Dict, List
from urllib.parse import quote_plus, urlencode

from ...api.v1.controllers.scrapper.filter.filter_schemas.filter_request_schema import (
    CompanySearchParams,
    FilterRequest,
)
from ..utils.log import logger


class FilterSelection:
    def __init__(self):
        self.session = None

    def build_query(self, params: FilterRequest) -> str:
        query_list = []
        try:
            for key, value in params.model_dump(exclude_none=True).items():
                if isinstance(value, list):
                    for v in value:
                        query_list.append((f"{key}[]", v))
                elif "_min" in key or "_max" in key:
                    base, bound = key.rsplit("_", 1)
                    query_list.append((f"{base}[{bound}]", value))
                else:
                    query_list.append((key, value))

            return urlencode(
                query_list,
                doseq=True,
                quote_via=lambda s, safe, encoding=None, errors=None: quote_plus(
                    s, safe="[]"
                ),
            )
        except Exception as e:
            logger.error(f"Error while generate filter query >> {e}")
            return ""

    def _build_query_dict(self, param_dict: Dict[str, Any]) -> Dict[str, Any]:
        query_dict = {}
        for field, value in param_dict.items():
            if isinstance(value, dict):
                self._handle_dict_field(query_dict, field, value)
            elif isinstance(value, list):
                self._handle_list_field(query_dict, field, value)
            else:
                query_dict[field] = value
        return query_dict

    def _handle_dict_field(
        self, query_dict: Dict[str, Any], field: str, value_dict: Dict[str, Any]
    ) -> None:
        for k, v in value_dict.items():
            if v is not None:
                query_dict[f"{field}[{k}]"] = v

    def _handle_list_field(
        self, query_dict: Dict[str, Any], field: str, value_list: List[Any]
    ) -> None:
        for v in value_list:
            query_dict.setdefault(f"{field}[]", []).append(v)

    def to_query(self, params: CompanySearchParams) -> str:
        try:
            query_dict = self._build_query_dict(params.model_dump(exclude_none=True))
            return urlencode(query_dict, doseq=True)
        except Exception as e:
            logger.error(f"Error while generate company filter query >> {e}")
            return ""
