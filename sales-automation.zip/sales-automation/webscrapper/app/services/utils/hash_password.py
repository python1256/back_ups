import bcrypt


def generate_password_hash(password: str) -> str:
    """
    Hash a plaintext password using bcrypt.
    Returns the hashed password as a string.
    """
    if isinstance(password, str):
        password = password.encode("utf-8")  # Convert to bytes
    hashed = bcrypt.hashpw(password, bcrypt.gensalt())
    return hashed.decode("utf-8")


def check_password_hash(hashed_password: str, password: str) -> bool:
    """
    Verify a plaintext password against a hashed password.
    Returns True if the password matches, False otherwise.
    """
    if isinstance(password, str):
        password = password.encode("utf-8")
    if isinstance(hashed_password, str):
        hashed_password = hashed_password.encode("utf-8")
    return bcrypt.checkpw(password, hashed_password)
