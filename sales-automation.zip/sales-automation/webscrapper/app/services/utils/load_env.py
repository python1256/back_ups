from dotenv import load_dotenv
from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    GENAI_API_KEY: str = Field(..., env="GENAI_API_KEY")
    SECRET_KEY: str = Field(..., env="SECRET_KEY")
    APOLLO_API_URL: str = Field(..., env="APOLLO_API_URL")
    APOLLO_API_KEY: str = Field(..., env="APOLLO_API_KEY")
    MONGO_HOST: str = Field(..., env="MONGO_URI")
    CELERY_BROKER_URL: str = Field(..., env="CELERY_BROKER_URL")
    CELERY_RESULT_BACKEND: str = Field(..., env="CELERY_RESULT_BACKEND")
    MODEL_NAME: str = Field(..., env="MODEL_NAME")
    INTERVAL_MINUTE: str = Field(..., env="INTERVAL_MINUTE")
    ALGORITHM: str = Field(..., env="ALGORITHM")
    SMTP_USER: str = Field(..., env="SMTP_USER")
    SMTP_PASSWORD: str = Field(..., env="SMTP_PASSWORD")
    ALLOWED_ORIGINS: str = Field(..., env="ALLOWED_ORIGINS")
    TOKEN_NAME: str = Field(..., env="TOKEN_NAME")

    class Config:
        load_dotenv()
        env_file_encoding = "utf-8"
        extra = "allow"


environment = Settings()
