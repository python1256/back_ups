from datetime import datetime, timezone

from mongoengine import (
    BooleanField,
    DateTimeField,
    Document,
    EmbeddedDocument,
    EmbeddedDocumentField,
    IntField,
    ListField,
    ReferenceField,
    StringField,
)

from ..profile_data_schema import Account


class SalesAssests(Document):
    name = StringField(required=True, unique=True)
    content = StringField(required=False)

    createdAt = DateTimeField(default=datetime.now(timezone.utc))
    updatedAt = DateTimeField(default=datetime.now(timezone.utc))
    is_delete = BooleanField(default=False)

    meta = {
        "collection": "sales_assests",
        "indexes": ["name"],
        "ordering": ["-createdAt"],
    }

    def save(self, *args, **kwargs):
        """Auto-update timestamps on save."""
        self.updatedAt = datetime.now(timezone.utc)
        return super(SalesAssests, self).save(*args, **kwargs)


class ValuePropositionFilter(EmbeddedDocument):
    job_title = ListField(StringField(), default=list)

    def clean(self):
        """Normalize single string fields to lists"""
        if isinstance(self.job_title, str):
            self.job_title = [self.job_title]
        if isinstance(self.department, str):
            self.department = [self.department]
        if isinstance(self.seniority_level, str):
            self.seniority_level = [self.seniority_level]
        if isinstance(self.industry, str):
            self.industry = [self.industry]

    department = ListField(StringField(), default=list)
    seniority_level = ListField(StringField(), default=list)
    industry = ListField(StringField(), default=list)


class ValueProposition(Document):
    persona = ListField(StringField(), default=list)
    buyer = StringField(required=True)
    filters = EmbeddedDocumentField(ValuePropositionFilter, required=False)
    account_id = ReferenceField(
        Account, required=False, help_text="Reference to associated account"
    )
    description = StringField(required=False)
    is_delete = BooleanField(default=False)

    createdAt = DateTimeField(default=datetime.now(timezone.utc))
    updatedAt = DateTimeField(default=datetime.now(timezone.utc))

    meta = {
        "collection": "value_propositions",
        "ordering": ["-createdAt"],
    }

    def save(self, *args, **kwargs):
        """Auto-update timestamps."""
        self.updatedAt = datetime.now(timezone.utc)
        if self.filters:
            self.filters.clean()
        return super(ValueProposition, self).save(*args, **kwargs)


class PersonaLibrary(Document):
    type = StringField(
        required=True,
        choices=["job-title", "seniority_level", "department", "industries"],
        help_text="Specify if the entry is a persona or a seniority level",
    )
    title = StringField(required=True)
    description = StringField(required=False)
    createdAt = DateTimeField(default=datetime.now(timezone.utc))
    updatedAt = DateTimeField(default=datetime.now(timezone.utc))
    is_delete = BooleanField(default=False)
    meta = {
        "collection": "persona_library",
        "ordering": ["-createdAt"],
    }

    def save(self, *args, **kwargs):
        """Auto-update timestamps on save."""
        self.updatedAt = datetime.now(timezone.utc)
        return super(PersonaLibrary, self).save(*args, **kwargs)

    @classmethod
    def get_all_by_type(cls, entry_type: str):
        """Fetch all entries filtered by type (persona or seniority_level)."""
        return list(cls.objects(type=entry_type).order_by("-createdAt"))


class WritingStyle(Document):
    style = StringField(required=False)
    sample_content = StringField(required=False)
    audience = StringField(required=False)
    max_words = IntField(required=False)
    is_delete = BooleanField(default=False)

    createdAt = DateTimeField(default=datetime.now(timezone.utc))
    updatedAt = DateTimeField(default=datetime.now(timezone.utc))

    meta = {
        "collection": "writing_style",
        "ordering": ["-createdAt"],
    }

    def save(self, *args, **kwargs):
        """Auto-update timestamps on save."""
        self.updatedAt = datetime.now(timezone.utc)
        return super(WritingStyle, self).save(*args, **kwargs)


class PersonaLibrary(Document):
    """
    Collection for persona and seniority level entries.
    Each document has a title and description.
    """

    type = StringField(
        required=True,
        choices=["persona", "seniority_level", "department", "industries"],
        help_text="Specify if the entry is a persona or a seniority level",
    )
    title = StringField(required=True)
    description = StringField(required=False)

    createdAt = DateTimeField(default=datetime.utcnow)
    updatedAt = DateTimeField(default=datetime.utcnow)

    meta = {
        "collection": "persona_library",
        "ordering": ["-createdAt"],
        "indexes": ["type", "title"],
    }

    def save(self, *args, **kwargs):
        """Auto-update timestamps on save."""
        self.updatedAt = datetime.now(timezone.utc)
        return super(PersonaLibrary, self).save(*args, **kwargs)

    @classmethod
    def get_all_by_type(cls, entry_type: str):
        """Fetch all entries filtered by type (persona or seniority_level)."""
        return list(cls.objects(type=entry_type).order_by("-createdAt"))
