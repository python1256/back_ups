from contextlib import asynccontextmanager

from app.api.v1.router import router
from app.api.v1.schedular.email_schedular import EmailScheduler
from app.api.v1.schedular.scheduler import LinkedInScheduler
from app.services.utils.load_env import environment
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        scheduler = LinkedInScheduler(
            interval_minutes=float(environment.INTERVAL_MINUTE)
        )
        email_scheduler = EmailScheduler(
            interval_minutes=float(environment.INTERVAL_MINUTE)
        )
        email_scheduler.start()
        scheduler.start()
        yield
    finally:
        scheduler.stop()
        email_scheduler.stop()


# lifespan=lifespan,
app = FastAPI(lifespan=lifespan, redoc_url=None)
templates = Jinja2Templates(directory="templates")

app.mount("/static", StaticFiles(directory="static", html=True), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=environment.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router=router)


@app.middleware("http")
async def add_csp_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Frame-Options"] = "ALLOWALL"
    response.headers[
        "Content-Security-Policy"
    ] = "frame-ancestors https: http: chrome-extension://*;"
    return response


@app.exception_handler(404)
async def http_exception_handler(request: Request, exc: HTTPException):
    return templates.TemplateResponse(
        "error.html",
        {"request": request},
        status_code=exc.status_code,
    )


@app.exception_handler(405)
async def http_exception_handler(request: Request, exc: HTTPException):
    return templates.TemplateResponse(
        "error.html",
        {"request": request},
        status_code=exc.status_code,
    )
