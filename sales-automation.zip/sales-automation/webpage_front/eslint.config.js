import js from '@eslint/js';
import globals from 'globals';
import react from 'eslint-plugin-react';
import reactHooks from 'eslint-plugin-react-hooks';
import reactRefresh from 'eslint-plugin-react-refresh';
import { defineConfig, globalIgnores } from 'eslint/config';
import prettier from 'eslint-plugin-prettier';

export default defineConfig([
	globalIgnores(['dist']),
	{
		files: ['**/*.{js,jsx}'],
		extends: [js.configs.recommended, reactHooks.configs['recommended-latest'], reactRefresh.configs.vite],
		plugins: {
			prettier,
			react,
		},
		languageOptions: {
			ecmaVersion: 'latest',
			globals: globals.browser,
			parserOptions: {
				ecmaFeatures: { jsx: true },
				sourceType: 'module',
			},
		},
		rules: {
			'no-unused-vars': [
				'error',
				{
					vars: 'all',
					args: 'after-used',
					ignoreRestSiblings: false,
					varsIgnorePattern: '^_',
				},
			],
			'react/jsx-uses-react': 'off',
			'react/jsx-uses-vars': 'error',
			'no-console': ['warn', { allow: ['warn', 'error'] }],
		},
	},
]);
