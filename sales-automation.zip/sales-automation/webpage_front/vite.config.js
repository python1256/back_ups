import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react-swc';
import tailwindcss from '@tailwindcss/vite';

// https://vite.dev/config/
export default defineConfig({
	plugins: [react(), tailwindcss()],
	server: {
		cors: true,
		headers: {
			'X-Frame-Options': 'ALLOWALL',
			'Content-Security-Policy': 'frame-ancestors https: http: chrome-extension://*;',
			// 'Content-Security-Policy': 'frame-ancestors *',
			// 'Content-Security-Policy': 'frame-ancestors self https://*.aspiresoftware.in chrome-extension://*'
		},
		allowedHosts: [
			/\.ngrok-free\.app$/,
			".aspiresoftware.in"
		  ]
	},
});
