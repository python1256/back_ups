export const timeAgo = (dateInput) => {
	if (!dateInput) return '';
	const date = new Date(dateInput);
	if (isNaN(date.getTime())) return '';

	const now = new Date();
	const diffSeconds = Math.floor((now - date) / 1000);

	const units = [
		{ label: 'year', seconds: 365 * 24 * 60 * 60 },
		{ label: 'month', seconds: 30 * 24 * 60 * 60 },
		{ label: 'day', seconds: 24 * 60 * 60 },
		{ label: 'hour', seconds: 60 * 60 },
		{ label: 'minute', seconds: 60 },
		{ label: 'second', seconds: 1 },
	];

	for (const { label, seconds } of units) {
		const value = Math.floor(diffSeconds / seconds);
		if (value >= 1) {
			if (label === 'day' && value === 1) return 'Yesterday';
			return `${value} ${label}${value > 1 ? 's' : ''} ago`;
		}
	}

	return 'Just now';
};
