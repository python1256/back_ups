import api from './api';

export const getValuePropositions = async ({ page = 1, q = '' } = {}) => {
	try {
		const response = await api.get('/value-propositions/', {
			params: { page, q },
		});
		return response.data;
	} catch (error) {
		console.error('Error fetching value propositions:', error);
		throw error.response?.data || { message: 'Failed to fetch value propositions' };
	}
};

export const createValueProposition = async (payload) => {
	try {
		const response = await api.post('/value-propositions/', payload);
		return response.data;
	} catch (error) {
		console.error('Error creating value proposition:', error);
		throw error.response?.data || { message: 'Failed to create value proposition' };
	}
};

export const editValueProposition = async (id, payload) => {
	try {
		const response = await api.patch(`/value-propositions/${id}`, payload);
		return response.data;
	} catch (error) {
		console.error('Error editing value proposition:', error);
		throw error.response?.data || { message: 'Failed to update value proposition' };
	}
};

export const deleteValuePropositions = async (ids) => {
	try {
		const response = await api.delete('/value-propositions/', {
			data: { ids: Array.isArray(ids) ? ids : [ids] },
		});
		return response.data;
	} catch (error) {
		console.error('Error deleting value propositions:', error);
		throw error.response?.data || { message: 'Failed to delete value propositions' };
	}
};

export const getValuePropositionById = async (id) => {
	try {
		const response = await api.get(`/value-propositions/${id}`);
		return response.data;
	} catch (error) {
		console.error('Error fetching value proposition:', error);
		throw error.response?.data || { message: 'Failed to fetch value proposition' };
	}
};

export const getPersonaLibrary = async (search = '') => {
	try {
		const res = await api.get('/persona-library', {
			params: { q: search },
		});
		return res.data;
	} catch (error) {
		console.error('Error fetching persona library:', error);
		throw error.response?.data || { message: 'Failed to fetch persona library' };
	}
};

export const getSalesAssets = async ({ page = 1, q = '' } = {}) => {
	try {
		const response = await api.get('/sales-assets/', {
			params: { page, q },
		});
		return response.data;
	} catch (error) {
		console.error('Error fetching sales assets:', error);
		throw error.response?.data || { message: 'Failed to fetch sales assets' };
	}
};

export const createSalesAsset = async (payload) => {
	try {
		const response = await api.post('/sales-assets/', payload);
		return response.data;
	} catch (error) {
		console.error('Error creating sales asset:', error);
		throw error.response?.data || { message: 'Failed to create sales asset' };
	}
};

export const editSalesAsset = async (id, payload) => {
	try {
		const response = await api.patch(`/sales-assets/${id}`, payload);
		return response.data;
	} catch (error) {
		console.error('Error editing sales asset:', error);
		throw error.response?.data || { message: 'Failed to update sales asset' };
	}
};

export const deleteSalesAssets = async (ids) => {
	try {
		const response = await api.delete('/sales-assets/', {
			data: { ids: Array.isArray(ids) ? ids : [ids] },
		});
		return response.data;
	} catch (error) {
		console.error('Error deleting sales assets:', error);
		throw error.response?.data || { message: 'Failed to delete sales assets' };
	}
};

export const getSalesAssetById = async (id) => {
	try {
		const response = await api.get(`/sales-assets/${id}`);
		return response.data;
	} catch (error) {
		console.error('Error fetching sales asset:', error);
		throw error.response?.data || { message: 'Failed to fetch sales asset' };
	}
};

export const getWritingStyles = async ({ page = 1, q = '' } = {}) => {
	try {
		const response = await api.get('/writing-styles/', {
			params: { page, q },
		});
		return response.data;
	} catch (error) {
		console.error('Error fetching writing styles:', error);
		throw error.response?.data || { message: 'Failed to fetch writing styles' };
	}
};

export const createWritingStyle = async (payload) => {
	try {
		const response = await api.post('/writing-styles/', payload);
		return response.data;
	} catch (error) {
		console.error('Error creating writing style:', error);
		throw error.response?.data || { message: 'Failed to create writing style' };
	}
};

export const editWritingStyle = async (id, payload) => {
	try {
		const response = await api.patch(`/writing-styles/${id}`, payload);
		return response.data;
	} catch (error) {
		console.error('Error editing writing style:', error);
		throw error.response?.data || { message: 'Failed to update writing style' };
	}
};

export const deleteWritingStyles = async (ids) => {
	try {
		const response = await api.delete('/writing-styles/', {
			data: { ids: Array.isArray(ids) ? ids : [ids] },
		});
		return response.data;
	} catch (error) {
		console.error('Error deleting writing styles:', error);
		throw error.response?.data || { message: 'Failed to delete writing styles' };
	}
};

export const getWritingStyleById = async (id) => {
	try {
		const response = await api.get(`/writing-styles/${id}`);
		return response.data;
	} catch (error) {
		console.error('Error fetching writing style:', error);
		throw error.response?.data || { message: 'Failed to fetch writing style' };
	}
};
