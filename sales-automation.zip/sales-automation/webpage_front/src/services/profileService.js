import api from './api';

export const getProfilesByFilterId = async ({ filterId, page = 1, q = '' }) => {
	try {
		const response = await api.get('/profiles', {
			params: {
				filter_id: filterId,
				page,
				q,
			},
		});
		return response.data;
	} catch (error) {
		console.error('Error fetching profiles:', error);
		throw error.response?.data || { message: 'Failed to fetch profiles' };
	}
};

export const getProfileById = async (id) => {
	try {
		const response = await api.get(`/profiles/${id}`);
		return response.data;
	} catch (error) {
		console.error('Error fetching profile:', error);
		throw error.response?.data || { message: 'Failed to fetch profile' };
	}
};
