import api from './api';

export const getFilters = async ({ page = 1, q = '' } = {}) => {
	try {
		const response = await api.get('/filters', {
			params: { page, q },
		});
		return response.data;
	} catch (error) {
		console.error('Error fetching filters:', error);
		throw error.response?.data || { message: 'Failed to fetch filters' };
	}
};

export const getFilterById = async (id) => {
	try {
		const response = await api.get(`/filter/${id}`);
		return response.data;
	} catch (error) {
		console.error('Error fetching filter:', error);
		throw error.response?.data || { message: 'Failed to fetch filter' };
	}
};

export const createFilter = async ({ name, params }) => {
	try {
		const response = await api.post(`/filters?${params}`, { filter_name: name });
		return response.data;
	} catch (error) {
		console.error('Error creating filter:', error);
		throw error.response?.data || { message: 'Failed to create filter' };
	}
};

export const editFilter = async ({ id, name, params }) => {
	try {
		const response = await api.put(`/filters?${params}`, {
			filter_id: id,
			filter_name: name,
		});
		return response.data;
	} catch (error) {
		console.error('Error editing filter:', error);
		throw error.response?.data || { message: 'Failed to update filter' };
	}
};

export const deleteFilters = async (ids) => {
	try {
		const response = await api.delete('/filters', {
			data: {
				filters_ids: Array.isArray(ids) ? ids : [ids],
			},
		});
		return response.data;
	} catch (error) {
		console.error('Error deleting filters:', error);
		throw error.response?.data || { message: 'Failed to delete filters' };
	}
};
