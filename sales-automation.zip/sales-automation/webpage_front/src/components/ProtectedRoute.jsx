import { Navigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import PropTypes from 'prop-types';
import AddLinkedinDetails from '../pages/AddLinkedinDetails';

export default function ProtectedRoute({ children }) {
	const { isAuthenticated, authChecked, isAccountFrozen } = useAuth();

	if (isAccountFrozen) {
		return <AddLinkedinDetails />;
	}

	if (!authChecked) {
		return (
			<div className="w-screen h-screen flex flex-col items-center justify-center bg-gray-50">
				<div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4"></div>
				<p className="text-gray-600 text-lg font-medium tracking-wide">Just a moment, verifying your session...</p>
			</div>
		);
	}
	if (!isAuthenticated) return <Navigate to="/login" replace />;
	return children;
}

ProtectedRoute.propTypes = {
	children: PropTypes.node.isRequired,
};
