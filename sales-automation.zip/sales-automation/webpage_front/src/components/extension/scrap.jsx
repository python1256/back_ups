import React, { useEffect, useState } from 'react';
import SalesNavigatorPortfolio from './portfolio';
import ContentView from './shared/content';
import CustomizeContent from './shared/customize';
import LinkedInPortfolio from './linkedin';
import UrlDisplay from './urldisplay';
import TabBar from './ui/tab';
import api from '../../services/api';

const GetCurrentUrl = () => {
	const [currentUrl, setCurrentUrl] = useState('');
	const [profileData, setProfileData] = useState(null);
	const [isLoading, setIsLoading] = useState(false);
	const [sourceTabId, setSourceTabId] = useState(null);
	const [activeTab, setActiveTab] = useState('profile');
	const [type, setType] = useState('');
	const [generatedContent, setGeneratedContent] = useState(null);

	const tabs = [
		{ key: 'profile', label: 'Profile' },
		{ key: 'customize', label: 'Customize Your Content' },
		{ key: 'content', label: 'Content' },
	];

	const getLinkedInUrlType = (url) => {
		if (!url) return null;
		if (url.startsWith('https://www.linkedin.com/sales/') || url.startsWith('https://sales.linkedin.com/')) {
			return 'sales_navigator';
		}
		if (url.startsWith('https://www.linkedin.com/') || url.startsWith('https://linkedin.com/')) {
			return 'linkedin';
		}
		return null;
	};

	useEffect(() => {
		setType(getLinkedInUrlType(currentUrl));
	}, [currentUrl]);

	useEffect(() => {
		chrome.storage.local.get(['sourceTabInfo'], (result) => {
			if (result.sourceTabInfo) {
				setSourceTabId(result.sourceTabInfo.id);
				setCurrentUrl(result.sourceTabInfo.url);
			}
		});

		const messageListener = (message) => {
			if (message.action === 'updateTabInfo' && message.tabInfo) {
				setSourceTabId(message.tabInfo.id);
				setCurrentUrl(message.tabInfo.url);
			}
		};

		chrome.runtime.onMessage.addListener(messageListener);
		return () => chrome.runtime.onMessage.removeListener(messageListener);
	}, []);

	const getUrlFromChrome = async () => {
		return new Promise((resolve) => {
			if (sourceTabId) {
				chrome.tabs.get(sourceTabId, (tab) => {
					if (chrome.runtime.lastError) resolve('Tab not available');
					else resolve(tab.url);
				});
			} else {
				chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
					resolve(tabs[0]?.url || 'No URL available');
				});
			}
		});
	};

	const getCookiesFromChrome = async () => {
		if (!sourceTabId) return [];

		// Wrap chrome.tabs.get in a promise
		const tab = await new Promise((resolve) => {
			chrome.tabs.get(sourceTabId, (t) => resolve(t));
		});

		if (!tab?.url?.startsWith('http')) return [];

		// Wrap chrome.cookies.getAll in a promise
		const cookies = await new Promise((resolve) => {
			chrome.cookies.getAll({ url: tab.url }, (c) => resolve(c));
		});

		// Save to storage (optional, non-blocking)
		chrome.storage.local.set({ tabCookies: cookies });

		return cookies;
	};

	const fetchProfileData = async (url, cookieHeader, urlType) => {
		try {
			setIsLoading(true);
			const refreshToken = await new Promise((resolve) => {
				chrome.storage.local.get(['refresh_token'], (result) => resolve(result.refresh_token));
			});

			const endpoint =
				urlType === 'linkedin'
					? 'https://sales-automation.aspiresoftware.in/profile-scrapper'
					: 'https://sales-automation.aspiresoftware.in/scrape-and-generate';

			const response = await api.post(
				endpoint,
				{ profile_url: url, cookies: cookieHeader },
				{
					headers: {
						Authorization: `Bearer ${refreshToken}`,
						'Content-Type': 'application/json',
					},
				}
			);

			setProfileData(response.data);
			chrome.storage.local.set({ profileData: response.data });
		} catch (error) {
			console.error(error);
			alert('Failed to fetch profile data.');
		} finally {
			setIsLoading(false);
		}
	};

	const handleFetch = async () => {
		const url = await getUrlFromChrome();
		if (!url) {
			alert('Please open a LinkedIn or Sales Navigator profile page.');
			return;
		}
		const urlType = getLinkedInUrlType(url);
		setCurrentUrl(url);

		try {
			setIsLoading(true);
			const cookies = await getCookiesFromChrome();
			await fetchProfileData(url, cookies, urlType);
		} catch (error) {
			console.error('Error:', error);
		} finally {
			setIsLoading(false);
		}
	};

	const handleGenerateContent = async ({ tone, writingStyle, salesAsset, valueProposition, type }) => {
		if (!profileData) return;

		setIsLoading(true);
		try {
			const response = await api.post('/write-content', {
				company_details: profileData.company_data || {},
				person_details: profileData.profile_data || {},
				content_type: type,
				tone,
				writingStyle: writingStyle,
				value_proposition: valueProposition || [], // just pass the array directly
				sales_assets: salesAsset ? [salesAsset] : [], // salesAsset is single object, keep as array
			});
			setGeneratedContent(response.data?.data || null);
			setActiveTab('content');
		} catch (error) {
			console.error('Error generating content:', error);
			alert('Failed to generate content.');
		} finally {
			setIsLoading(false);
		}
	};

	useEffect(() => {
		chrome.storage.local.get(['profileData'], (result) => {
			if (result.profileData) setProfileData(result.profileData);
		});
	}, []);

	return (
		<div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
			<TabBar tabs={tabs} activeTab={activeTab} onTabChange={setActiveTab} />
			<div style={{ flex: 1, padding: '10px', overflowY: 'auto' }}>
				{activeTab === 'profile' && (
					<>
						<UrlDisplay url={currentUrl} isLoading={isLoading} onClick={handleFetch} />
						{profileData && (
							<>
								{type === 'linkedin' && <LinkedInPortfolio data={profileData} />}
								{type === 'sales_navigator' && <SalesNavigatorPortfolio data={profileData} />}
							</>
						)}
					</>
				)}

				{activeTab === 'customize' && <CustomizeContent onGenerateContent={handleGenerateContent} />}

				{activeTab === 'content' && <ContentView generatedContent={generatedContent} isLoading={isLoading} />}
			</div>
		</div>
	);
};

export default GetCurrentUrl;
