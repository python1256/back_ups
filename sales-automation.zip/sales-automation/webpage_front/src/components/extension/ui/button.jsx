import React from 'react';
import PropTypes from 'prop-types';
import { motion } from 'framer-motion';
import { Loader2 } from 'lucide-react';

const Button = ({ onClick, isLoading, disabled, children }) => {
	return (
		<motion.button
			whileHover={!isLoading && !disabled ? { scale: 1.03 } : {}}
			whileTap={!isLoading && !disabled ? { scale: 0.98 } : {}}
			onClick={onClick}
			disabled={isLoading || disabled}
			className={`relative w-full py-3 px-5 rounded-xl font-semibold 
        transition-all duration-300 ease-in-out 
        flex items-center justify-center gap-2 
        backdrop-blur-sm border 
        ${
					isLoading || disabled
						? 'bg-gradient-to-r from-gray-300 to-gray-400 text-gray-700 cursor-not-allowed'
						: 'bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 text-black shadow-md hover:shadow-lg hover:from-blue-600 hover:to-purple-600'
				}`}
		>
			{isLoading ? (
				<>
					<Loader2 className="animate-spin w-5 h-5 text-white" />
					<span>Loading...</span>
				</>
			) : (
				children
			)}
		</motion.button>
	);
};

// ------------------ PropTypes ------------------
Button.propTypes = {
	onClick: PropTypes.func,
	isLoading: PropTypes.bool,
	disabled: PropTypes.bool,
	children: PropTypes.node.isRequired,
};

// ------------------ Default Props ------------------
Button.defaultProps = {
	onClick: () => {},
	isLoading: false,
	disabled: false,
};

export default Button;
