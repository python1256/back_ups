import React, { useRef, useEffect, useState } from 'react';
import PropTypes from 'prop-types';

const TabBar = ({ tabs, activeTab, onTabChange }) => {
	const containerRef = useRef(null);
	const [sliderStyle, setSliderStyle] = useState({ left: 0, width: 0 });

	const updateSlider = () => {
		const container = containerRef.current;
		if (!container) return;

		const activeButton = container.querySelector(`[data-key="${activeTab}"]`);
		if (activeButton) {
			const { offsetLeft, offsetWidth } = activeButton;
			setSliderStyle({ left: offsetLeft, width: offsetWidth });
		}
	};

	useEffect(() => {
		requestAnimationFrame(updateSlider);
	}, [activeTab, tabs]);

	useEffect(() => {
		window.addEventListener('resize', updateSlider);
		return () => window.removeEventListener('resize', updateSlider);
	}, [activeTab, tabs]);

	return (
		<div
			ref={containerRef}
			style={{
				position: 'relative',
				display: 'flex',
				background: '#fff',
				borderBottom: '1px solid #e5e7eb',
				boxShadow: '0 1px 3px rgba(0, 0, 0, 0.05)',
			}}
		>
			{tabs.map((tab) => (
				<button
					key={tab.key}
					data-key={tab.key}
					onClick={() => onTabChange(tab.key)}
					role="tab"
					aria-selected={activeTab === tab.key}
					tabIndex={activeTab === tab.key ? 0 : -1}
					style={{
						flex: 1,
						padding: '10px 16px',
						background: 'none',
						border: 'none',
						fontSize: '14px',
						color: activeTab === tab.key ? '#1d4ed8' : '#6b7280',
						fontWeight: activeTab === tab.key ? 600 : 500,
						cursor: 'pointer',
						transition: 'color 0.25s ease',
					}}
				>
					{tab.label}
				</button>
			))}

			<div
				style={{
					position: 'absolute',
					bottom: 0,
					height: '3px',
					background: '#2563eb',
					borderRadius: '3px',
					transition: 'all 0.25s ease',
					left: `${sliderStyle.left}px`,
					width: `${sliderStyle.width}px`,
				}}
			/>
		</div>
	);
};

// ----- PropTypes -----
TabBar.propTypes = {
	tabs: PropTypes.arrayOf(
		PropTypes.shape({
			key: PropTypes.string.isRequired,
			label: PropTypes.string.isRequired,
		})
	).isRequired,
	activeTab: PropTypes.string.isRequired,
	onTabChange: PropTypes.func.isRequired,
};

export default TabBar;
