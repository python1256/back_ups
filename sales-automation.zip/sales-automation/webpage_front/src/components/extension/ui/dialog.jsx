import React from 'react';
import PropTypes from 'prop-types';
import * as DialogPrimitive from '@radix-ui/react-dialog';
import { X } from 'lucide-react';

export const Dialog = DialogPrimitive.Root;
export const DialogTrigger = DialogPrimitive.Trigger;
export const DialogClose = DialogPrimitive.Close;

export const DialogContent = ({ children, className }) => (
	<DialogPrimitive.Portal>
		{/* Overlay */}
		<DialogPrimitive.Overlay className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm data-[state=open]:animate-fadeIn data-[state=closed]:animate-fadeOut" />

		{/* Content */}
		<DialogPrimitive.Content
			className={`fixed z-50 left-1/2 top-1/2 w-[90vw] max-w-2xl max-h-[80vh] overflow-y-auto -translate-x-1/2 -translate-y-1/2 rounded-2xl bg-white p-6 shadow-xl focus:outline-none data-[state=open]:animate-scaleIn ${className}`}
		>
			{children}

			{/* Close Button */}
			<DialogClose asChild>
				<button className="absolute right-4 top-4 text-gray-500 hover:text-gray-700 transition" aria-label="Close">
					<X className="h-5 w-5" />
				</button>
			</DialogClose>
		</DialogPrimitive.Content>
	</DialogPrimitive.Portal>
);

DialogContent.propTypes = {
	children: PropTypes.node.isRequired,
	className: PropTypes.string,
};

DialogContent.defaultProps = {
	className: '',
};

export const DialogHeader = ({ children }) => <div className="mb-4 border-b pb-2">{children}</div>;

DialogHeader.propTypes = {
	children: PropTypes.node.isRequired,
};

export const DialogTitle = ({ children }) => <h2 className="text-xl font-semibold text-gray-900">{children}</h2>;

DialogTitle.propTypes = {
	children: PropTypes.node.isRequired,
};
