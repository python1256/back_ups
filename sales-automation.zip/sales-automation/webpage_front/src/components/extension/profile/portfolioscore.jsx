import React, { useState } from 'react';
import PropTypes from 'prop-types';
import Card from '../ui/card';
import ReactMarkdown from 'react-markdown';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { ArrowRight, MapPin } from 'lucide-react';

// ------------------ Utility ------------------
const getScoreColor = (score) => {
	const s = parseFloat(score);
	if (isNaN(s)) return 'text-gray-700';
	if (s >= 80) return 'text-green-600';
	if (s >= 60) return 'text-yellow-600';
	return 'text-red-600';
};

// ------------------ Score Component ------------------
export const PortfolioScore = ({ score }) => {
	const [open, setOpen] = useState(false);
	if (!score) return null;

	const { analysis, description, factors, overall_match_score, overview, profile_summary, insights, tips_to_improve } =
		score;

	return (
		<div className="inline-flex items-center gap-2">
			{overall_match_score != null && (
				<button className="flex items-center gap-1 cursor-pointer" onClick={() => setOpen(true)}>
					<span className={`text-lg md:text-xl font-extrabold ${getScoreColor(overall_match_score)}`}>
						{overall_match_score}%
					</span>
					<span className="font-bold text-xs text-blue-600 leading-none">Score</span>
					<ArrowRight size={14} className="text-blue-500 transition group-hover:text-blue-600" />
				</button>
			)}

			<Dialog open={open} onOpenChange={setOpen}>
				<DialogContent>
					<DialogHeader>
						<DialogTitle>Detailed Score Information</DialogTitle>
					</DialogHeader>

					{(overview || profile_summary) && (
						<section className="mb-4">
							<h3 className="font-semibold mb-2">Score Summary</h3>
							{overview && (
								<p className="text-gray-700 mb-2">
									<strong>Overview:</strong> {overview}
								</p>
							)}
							{profile_summary && (
								<p className="text-gray-700">
									<strong>Profile Summary:</strong> {profile_summary}
								</p>
							)}
						</section>
					)}

					{(analysis || description) && (
						<section className="mb-4">
							<h3 className="font-semibold mb-2">Detailed Analysis</h3>
							{analysis && (
								<p className="text-gray-700 mb-1">
									<strong>Analysis:</strong> {analysis}
								</p>
							)}
							{description && (
								<p className="text-gray-700">
									<strong>Description:</strong> {description}
								</p>
							)}
						</section>
					)}

					{factors?.length > 0 && (
						<section className="mb-4">
							<h3 className="font-semibold mb-2">Key Factors</h3>
							<ul className="space-y-2">
								{factors.map((f) => (
									<li key={f.name} className="flex items-center gap-2">
										<span className={`font-bold ${getScoreColor(f.score || 0)}`}>
											{parseFloat(f.score) >= 70 ? '🟢' : '🟡'}
										</span>
										<div>
											<strong>{f.name}:</strong> <span>{f.explanation || f.score || 'N/A'}</span>
										</div>
									</li>
								))}
							</ul>
						</section>
					)}

					{insights && (
						<section className="mb-4">
							<h3 className="font-semibold mb-2">Insights</h3>
							<p className="text-gray-700">{insights}</p>
						</section>
					)}
					{tips_to_improve.map((tip) => (
						<li
							key={tip.area} // assuming 'area' is unique
							className="border-l-4 border-blue-400 pl-3"
						>
							<p className="font-semibold text-gray-800 mb-1">{tip.area}</p>
							<p className="mb-1">{tip.suggestion}</p>
							<span className="inline-block bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded-full">
								Expected Score Gain: {tip.expected_score_gain}
							</span>
						</li>
					))}
				</DialogContent>
			</Dialog>
		</div>
	);
};

// ------------------ Header ------------------
export const PortfolioHeader = ({ name, headline, location, linkedinProfile, score }) => {
	let formattedLink = null;

	if (linkedinProfile) {
		formattedLink = linkedinProfile.startsWith('http') ? linkedinProfile : `https://${linkedinProfile}`;
	}

	return (
		<Card className="mb-4">
			<div className="flex flex-col gap-3">
				<div className="flex items-center justify-between gap-3">
					<h6 className="font-extrabold text-gray-900 m-0">{name || 'N/A'}</h6>
				</div>

				{headline && <p className="text-gray-600 text-lg">{headline}</p>}

				<div className="flex items-center justify-between flex-wrap gap-2">
					{location && (
						<p className="text-gray-500 text-sm flex items-center gap-1">
							<MapPin className="w-4 h-4" /> {location}
						</p>
					)}

					{formattedLink && (
						<a
							href={formattedLink}
							target="_blank"
							rel="noopener noreferrer"
							aria-label={`View ${name}'s LinkedIn Profile`}
							className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-full shadow-sm text-white bg-blue-600 hover:bg-blue-700 transition duration-150"
						>
							LinkedIn
						</a>
					)}

					{score && <PortfolioScore score={score} />}
				</div>
			</div>
		</Card>
	);
};

// ------------------ About ------------------
export const PortfolioAbout = ({ overview }) => {
	const [showMore, setShowMore] = useState(false);
	if (!overview) return null;

	const previewLength = 350;
	const preview = overview.length > previewLength ? overview.slice(0, previewLength) + '...' : overview;

	return (
		<Card className="mb-4">
			<h3 className="font-semibold text-xl mb-3 border-b pb-2">About</h3>
			<div className="text-gray-700 text-base leading-relaxed">
				<ReactMarkdown>{showMore ? overview : preview}</ReactMarkdown>
			</div>

			{overview.length > previewLength && (
				<button onClick={() => setShowMore(!showMore)} className="text-blue-700 hover:underline font-medium mt-2">
					{showMore ? 'Show Less' : 'Show More...'}
				</button>
			)}
		</Card>
	);
};

const DetailRow = ({ label, value }) => {
	if (!value) return null;

	const displayValue = Array.isArray(value) ? value.join(', ') : value;

	return (
		<div className="flex justify-between py-1.5 border-b border-gray-100 last:border-b-0">
			<strong className="text-sm font-medium text-gray-600">{label}:</strong>
			<span className="text-sm text-gray-800 text-right max-w-[70%]">{displayValue}</span>
		</div>
	);
};

DetailRow.propTypes = {
	label: PropTypes.string.isRequired,
	value: PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
};
// ------------------ Company Info ------------------
export const PortfolioCompanyInfo = ({ company }) => {
	if (!company) return null;
	const { company_details, business_model, clients, services, tech_stack, vision } = company;
	return (
		<Card className="mb-4">
			<h3 className="font-semibold text-xl mb-3 border-b pb-2">Company Info</h3>
			<div className="space-y-1">
				<DetailRow label="Name" value={company_details?.name} />
				<DetailRow label="Size" value={company_details?.company_size} />
				<DetailRow label="Founded" value={company_details?.founded_year} />
				<DetailRow label="Leadership" value={company_details?.leadership_team} />
				<DetailRow label="Business Model" value={business_model?.business_model} />
				<DetailRow label="Clients" value={clients?.clients} />
				<DetailRow label="Services" value={services} />
				<DetailRow label="Tech Stack" value={tech_stack?.tech_stack} />
				<DetailRow label="Vision" value={vision} />
			</div>
		</Card>
	);
};

// ------------------ Experience ------------------
export const PortfolioExperience = ({ experience = [] }) => {
	const [showAll, setShowAll] = useState(false);
	if (experience.length === 0) return null;

	const displayedExp = showAll ? experience : experience.slice(0, 3);

	return (
		<Card>
			<h3 className="font-semibold text-xl mb-4 border-b pb-2">Experience</h3>
			{displayedExp.map((exp) => {
				// Construct a stable key using unique properties
				const key = `${exp.position}-${exp.company_name}-${exp.duration}`;

				return (
					<div
						key={key}
						className="relative pl-6 pb-6 last:pb-0 transition-transform duration-300 hover:translate-x-1 hover:shadow-lg rounded-lg"
					>
						<div
							className="absolute left-0 top-1 w-4 h-4 rounded-full border-2 border-white shadow-md"
							style={{ background: 'linear-gradient(45deg, #3b82f6, #9333ea)' }}
						/>
						{displayedExp.indexOf(exp) < displayedExp.length - 1 && (
							<div
								className="absolute left-[7px] top-5 bottom-0 w-1 rounded"
								style={{
									background: 'linear-gradient(to bottom, #3b82f6, #9333ea)',
								}}
							/>
						)}
						<div className="space-y-1">
							<p className="font-semibold text-gray-900 text-base">{exp.position || exp.company_name}</p>
							{exp.company_name && <p className="text-gray-600 text-sm italic">{exp.company_name}</p>}
							{exp.duration && <p className="text-blue-500 text-xs font-medium">{exp.duration}</p>}
							{exp.description && <p className="text-gray-700 text-sm mt-1 leading-relaxed">{exp.description}</p>}
						</div>
					</div>
				);
			})}

			{experience.length > 3 && (
				<button
					onClick={() => setShowAll((p) => !p)}
					className="mt-2 text-blue-600 hover:text-blue-800 font-medium transition-colors"
				>
					{showAll ? 'Show Less' : `+${experience.length - 3} more`}
				</button>
			)}
		</Card>
	);
};

// ------------------ Tags ------------------
export const PortfolioTags = ({ title, tags, bgColor = '#e0e0e0', textColor = '#333' }) => {
	const [showAll, setShowAll] = useState(false);
	if (!tags || tags.length === 0) return null;

	const displayedTags = showAll ? tags : tags.slice(0, 5);

	return (
		<Card>
			<h3 className="font-semibold text-base mb-3">{title}</h3>
			<div className="flex flex-wrap gap-2 mb-3">
				{displayedTags.map((tag) => (
					<span
						key={tag} // use the tag string as a stable key
						style={{
							background: bgColor,
							color: textColor,
							padding: '5px 12px',
							borderRadius: '20px',
							fontSize: '13px',
							fontWeight: 500,
						}}
					>
						{tag}
					</span>
				))}
			</div>
			{tags.length > 5 && (
				<button onClick={() => setShowAll(!showAll)} className="text-blue-700 hover:underline font-medium text-sm">
					{showAll ? 'Show Less' : `+${tags.length - 5} more`}
				</button>
			)}
		</Card>
	);
};

PortfolioTags.propTypes = {
	title: PropTypes.string.isRequired,
	tags: PropTypes.arrayOf(PropTypes.string).isRequired,
	bgColor: PropTypes.string,
	textColor: PropTypes.string,
};
PortfolioScore.propTypes = {
	score: PropTypes.shape({
		analysis: PropTypes.string,
		description: PropTypes.string,
		factors: PropTypes.arrayOf(
			PropTypes.shape({
				name: PropTypes.string,
				score: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
				explanation: PropTypes.string,
			})
		),
		overall_match_score: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
		overview: PropTypes.string,
		profile_summary: PropTypes.string,
		insights: PropTypes.string,
		tips_to_improve: PropTypes.arrayOf(
			PropTypes.shape({
				area: PropTypes.string,
				suggestion: PropTypes.string,
				expected_score_gain: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
			})
		),
	}),
};
PortfolioHeader.propTypes = {
	name: PropTypes.string,
	headline: PropTypes.string,
	location: PropTypes.string,
	linkedinProfile: PropTypes.string,
	score: PropTypes.object,
};
PortfolioAbout.propTypes = {
	overview: PropTypes.string,
};
PortfolioCompanyInfo.propTypes = {
	company: PropTypes.shape({
		company_details: PropTypes.shape({
			name: PropTypes.string,
			company_size: PropTypes.string,
			founded_year: PropTypes.string,
			leadership_team: PropTypes.array,
		}),
		business_model: PropTypes.shape({
			business_model: PropTypes.string,
		}),
		clients: PropTypes.shape({
			clients: PropTypes.array,
		}),
		services: PropTypes.array,
		tech_stack: PropTypes.shape({
			tech_stack: PropTypes.array,
		}),
		vision: PropTypes.string,
	}),
};
PortfolioExperience.propTypes = {
	experience: PropTypes.arrayOf(
		PropTypes.shape({
			position: PropTypes.string,
			company_name: PropTypes.string,
			duration: PropTypes.string,
			description: PropTypes.string,
		})
	),
};
