import React from 'react';
import { Wrench } from 'lucide-react';
import PropTypes from 'prop-types';

const Skills = ({ skill = [] }) => {
	// Filter out empty or invalid skill values
	const filteredSkills = skill.filter((item) => typeof item === 'string' && item.trim() !== '');

	if (filteredSkills.length === 0) return null;

	return (
		<div className="display-container">
			<h3 className="component-header flex items-center">
				<Wrench color="#3e56ee" size={25} />
				<span className="ml-2">Skills</span>
			</h3>

			<ul className="content-text list space-y-2 mt-2">
				{filteredSkills.map((item) => {
					// Generate a safe unique key (avoids ESLint warning)
					const key = item.trim().toLowerCase().replace(/\s+/g, '-');
					return (
						<li key={key} className="list-item">
							{item}
						</li>
					);
				})}
			</ul>
		</div>
	);
};

Skills.propTypes = {
	skill: PropTypes.arrayOf(PropTypes.string),
};

export default Skills;
