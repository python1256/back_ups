import React, { useRef, useState, useEffect } from 'react';
import { LucideBriefcaseBusiness, Copy } from 'lucide-react';
import PropTypes from 'prop-types';

const MAX_HEIGHT = 400;

const Experience = ({ experience = [] }) => {
	const contentRef = useRef(null);
	const [isExpanded, setIsExpanded] = useState(false);
	const [canCollapse, setCanCollapse] = useState(false);
	const [copiedIdx, setCopiedIdx] = useState(null);

	// Filter valid experience entries
	const filtered = experience.filter((item) => Object.values(item).some((v) => (typeof v === 'string' ? v.trim() : v)));

	useEffect(() => {
		const el = contentRef.current;
		if (el) setCanCollapse(el.scrollHeight > MAX_HEIGHT);
	}, [filtered, isExpanded]);

	const handleCopy = (item, idx) => {
		const text = [
			item.title && `Role: ${item.title}`,
			item.company && `Company: ${item.company}`,
			item.location && `Location: ${item.location}`,
			item.date_range && `Tenure: ${item.date_range}`,
			item.description && `Description: ${item.description}`,
		]
			.filter(Boolean)
			.join('\n');

		navigator.clipboard.writeText(text);
		setCopiedIdx(idx);
		setTimeout(() => setCopiedIdx(null), 1000);
	};

	return (
		<div className="display-container">
			<h3 className="component-header flex items-center">
				<LucideBriefcaseBusiness size={25} color="#3e56ee" />
				<span className="ml-2">Experience</span>
			</h3>

			<div
				ref={contentRef}
				className="experience-content"
				style={{
					maxHeight: isExpanded ? 'none' : `${MAX_HEIGHT}px`,
					overflowY: isExpanded ? 'visible' : 'auto',
					overflowX: 'hidden',
					transition: 'max-height 0.3s ease',
				}}
			>
				{filtered.map((item, idx) => (
					<div key={`${item.title}-${idx}`} className="relative my-2 p-4 border rounded-lg shadow-sm bg-white group">
						{/* Copy button */}
						<div className="absolute top-2 right-2">
							{copiedIdx === idx ? (
								<span className="text-green-600 text-xs font-medium">Copied!</span>
							) : (
								<Copy size={16} className="cursor-pointer hover:text-blue-600" onClick={() => handleCopy(item, idx)} />
							)}
						</div>

						{/* Fields */}
						{item.title && (
							<div className="mb-1">
								<strong>Role:</strong> {item.title}
							</div>
						)}
						{item.company && (
							<div className="mb-1">
								<strong>Company:</strong> {item.company}
							</div>
						)}
						{item.location && (
							<div className="mb-1">
								<strong>Location:</strong> {item.location}
							</div>
						)}
						{item.date_range && (
							<div className="text-sm text-gray-600">
								<strong>Tenure:</strong> {item.date_range}
							</div>
						)}
						{item.description && <div className="mt-2 text-gray-700">{item.description}</div>}
					</div>
				))}
			</div>

			{canCollapse && (
				<div className="content-text flex justify-start mt-2">
					<button onClick={() => setIsExpanded(!isExpanded)} className="show-more-btn text-blue-600 hover:underline">
						{isExpanded ? 'Collapse' : 'Expand'}
					</button>
				</div>
			)}
		</div>
	);
};

// ✅ Correct casing
Experience.propTypes = {
	experience: PropTypes.arrayOf(
		PropTypes.shape({
			title: PropTypes.string,
			company: PropTypes.string,
			location: PropTypes.string,
			date_range: PropTypes.string,
			description: PropTypes.string,
		})
	),
};

export default Experience;
