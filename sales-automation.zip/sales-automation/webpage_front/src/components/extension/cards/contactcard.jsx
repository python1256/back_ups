import React from 'react';
import { Contact } from 'lucide-react';
import PropTypes from 'prop-types';

const ContactCard = ({ name }) => {
	return (
		<div className="display-container">
			<div className="component-header flex items-center">
				<Contact size={22} color="#3e56ee" />
				<span className="ml-2">Contact</span>
			</div>
			<span className="content-text">{name}</span>
		</div>
	);
};

// ✅ Add PropTypes validation
ContactCard.propTypes = {
	name: PropTypes.string.isRequired, // mark as required if always expected
};

export default ContactCard;
