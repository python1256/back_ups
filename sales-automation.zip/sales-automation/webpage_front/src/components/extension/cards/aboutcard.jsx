import React, { useRef, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Info } from 'lucide-react';

const MAX_HEIGHT = 200; // Height limit when collapsed

const About = ({ about = '' }) => {
	const contentRef = useRef(null);
	const [isExpanded, setIsExpanded] = useState(false);
	const [isOverflowing, setIsOverflowing] = useState(false);

	useEffect(() => {
		const el = contentRef.current;
		if (el) {
			setIsOverflowing(el.scrollHeight > MAX_HEIGHT);
		}
	}, [about]);

	if (!about.trim()) return null;

	return (
		<div className="p-4 bg-white rounded-2xl shadow-sm border border-gray-100 mb-6">
			{/* Header */}
			<h3 className="text-xl font-semibold text-gray-800 flex items-center mb-3">
				<Info size={22} color="#3e56ee" />
				<span className="ml-2">About</span>
			</h3>

			{/* Content */}
			<div className="relative text-gray-700 leading-relaxed">
				<div
					ref={contentRef}
					className={`transition-[max-height] duration-300 ease-in-out ${
						isExpanded ? 'max-h-none' : 'overflow-hidden'
					}`}
					style={{ maxHeight: isExpanded ? 'none' : `${MAX_HEIGHT}px` }}
				>
					<p className="whitespace-pre-line">{about}</p>
				</div>

				{/* Gradient Fade when collapsed */}
				{!isExpanded && isOverflowing && (
					<div className="absolute bottom-0 left-0 w-full h-12 bg-gradient-to-t from-white to-transparent pointer-events-none"></div>
				)}

				{/* Toggle Button */}
				{isOverflowing && (
					<button
						onClick={() => setIsExpanded(!isExpanded)}
						aria-expanded={isExpanded}
						className="mt-3 text-blue-600 hover:underline focus:outline-none focus:ring-2 focus:ring-blue-400 rounded text-sm font-medium"
					>
						{isExpanded ? 'Show Less' : 'Show More'}
					</button>
				)}
			</div>
		</div>
	);
};

About.propTypes = {
	about: PropTypes.string,
};

export default About;
