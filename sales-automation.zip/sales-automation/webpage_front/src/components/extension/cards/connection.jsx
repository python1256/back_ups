import React, { useState } from 'react';
import { UserPlus, Copy } from 'lucide-react';
import PropTypes from 'prop-types';

const ConnectionCard = ({ connectionContent }) => {
	const [copied, setCopied] = useState(false);

	const copyText = async () => {
		try {
			await navigator.clipboard.writeText(connectionContent);
			setCopied(true);
			setTimeout(() => setCopied(false), 2000);
		} catch {
			alert('Copy failed.');
		}
	};

	return (
		<div className="display-container">
			<h3 className="component-header">
				<UserPlus color="#3e56ee" size={25} />
				<span>Connection Request</span>
				<div className="copy-container">
					{copied ? (
						<span className="copied-text">Copied!</span>
					) : (
						<Copy onClick={copyText} className="copy-icon" size={20} color="#3e56ee" />
					)}
				</div>
			</h3>
			<div className="content-text">
				<div className="email-content">{connectionContent}</div>
			</div>
		</div>
	);
};

// ✅ lowercase `propTypes`
ConnectionCard.propTypes = {
	connectionContent: PropTypes.string,
};

export default ConnectionCard;
