// Portfolio.js
import React from 'react';
import PropTypes from 'prop-types';

import ContactCard from './cards/contactcard';
import Education from './cards/education';
import About from './cards/aboutcard';
import Interest from './cards/interests';
import EmailCard from './cards/email';
import ConnectionCard from './cards/connection';
import SkillsCard from './cards/skills';
import Experience from './cards/experience';
import LocationCard from './cards/location';
import PostsCard from './cards/posts';

const SalesNavigatorPortfolio = ({ data = {} }) => {
	const { profile_data = {}, connection_request_content = '', email_content = '' } = data;

	const {
		name = '',
		location = '',
		about = '',
		education = [],
		experience = [],
		interests = [],
		skills = [],
		posts = [],
	} = profile_data || {};

	return (
		<>
			<ContactCard name={name} />
			<LocationCard location={location} />
			<Education education={education} />
			<About about={about} />
			<Interest interest={interests} />
			<SkillsCard skill={skills} />
			<Experience experience={experience} />
			<PostsCard postcontent={posts} />
			<EmailCard emailContent={email_content} />
			<ConnectionCard connectionContent={connection_request_content} />
		</>
	);
};

SalesNavigatorPortfolio.propTypes = {
	data: PropTypes.shape({
		profile_data: PropTypes.shape({
			name: PropTypes.string,
			location: PropTypes.string,
			about: PropTypes.string,
			education: PropTypes.array,
			experience: PropTypes.array,
			interests: PropTypes.arrayOf(PropTypes.string),
			skills: PropTypes.arrayOf(PropTypes.string),
			posts: PropTypes.arrayOf(PropTypes.string),
		}),
		connection_request_content: PropTypes.string,
		email_content: PropTypes.string,
	}),
};

export default SalesNavigatorPortfolio;
