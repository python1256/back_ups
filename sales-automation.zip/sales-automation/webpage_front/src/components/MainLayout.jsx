import PropTypes from 'prop-types';
import Navbar from './Navbar';

const MainLayout = ({ children }) => {
	return (
		<>
			<Navbar />
			<div className="overflow-auto h-[calc(100vh-72px)] bg-[rgb(280,280,280)]">{children}</div>
		</>
	);
};

MainLayout.propTypes = {
	children: PropTypes.node.isRequired,
};
export default MainLayout;
