import { useEffect, useRef, useState } from 'react';
import { createFilter } from '../services/filterService';
import { X } from 'lucide-react';
import PropTypes from 'prop-types';

function ChipsInput({ value = [], placeholder = '', onChange }) {
	const [inputValue, setInputValue] = useState('');
	const inputRef = useRef(null);

	const addChipsFromString = (str) => {
		if (!str) return;
		const parts = str
			.split(',')
			.map((p) => p.trim())
			.filter((p) => p.length);
		if (parts.length === 0) return;
		const next = Array.from(new Set([...value, ...parts]));
		onChange(next);
		setInputValue('');
	};

	const handleKeyDown = (e) => {
		if (e.key === 'Enter' || e.key === ',') {
			e.preventDefault();
			addChipsFromString(inputValue);
		}
		if (e.key === 'Backspace' && inputValue === '' && value.length) {
			onChange(value.slice(0, -1));
		}
	};

	const removeChip = (idx) => {
		const next = value.slice();
		next.splice(idx, 1);
		onChange(next);
	};

	return (
		<div className="border rounded p-2 min-h-[44px] flex flex-wrap gap-2 items-center">
			{value.map((v, i) => (
				<div key={`chip-${i + 1}`} className="flex items-center gap-2 bg-gray-100 rounded px-2 py-1 text-sm">
					<span>{v}</span>
					<button type="button" onClick={() => removeChip(i)} className="text-xs">
						✕
					</button>
				</div>
			))}
			<input
				ref={inputRef}
				value={inputValue}
				placeholder={placeholder || 'Type and press Enter or comma to add'}
				onChange={(e) => setInputValue(e.target.value)}
				onKeyDown={handleKeyDown}
				onBlur={() => addChipsFromString(inputValue)}
				className="flex-1 min-w-[120px] outline-none"
			/>
		</div>
	);
}

ChipsInput.propTypes = {
	value: PropTypes.array.isRequired,
	placeholder: PropTypes.string,
	onChange: PropTypes.func.isRequired,
};

export default function AddFilterModal({ open, onClose, onAdded }) {
	const initialJSON = {
		person_titles: ['CEO', 'CTO', 'CIO', 'Founder', 'Co-Founder', 'Co founder'],
		include_similar_titles: true,
		q_keywords: 'Fintech',
		person_locations: ['India'],
		person_seniorities: ['VP', 'Director', 'Manager', 'Owner', 'Partner', 'Head'],
		q_organization_domains_list: ['aspireapp.com', 'razorpay.com'],
		contact_email_status: ['VERIFIED', 'UNVERIFIED'],
		organization_ids: null,
		organization_num_employees_ranges: ['11-50', '51-200', '201-500'],
		revenue_range_min: 1000000,
		revenue_range_max: 100000000,
		currently_using_all_of_technology_uids: ['salesforce', 'google_analytics'],
		currently_using_any_of_technology_uids: ['salesforce', 'google_analytics'],
		currently_not_using_any_of_technology_uids: ['wordpress_org'],
		q_organization_job_titles: ['CTO', 'CIO', 'Head of Technology'],
		organization_job_locations: ['India'],
		organization_num_jobs_range_min: 1,
		organization_num_jobs_range_max: 10,
		organization_job_posted_at_range_min: '2023-01-01',
		organization_job_posted_at_range_max: '2025-10-08',
		page: 1,
		per_page: 20,
	};

	const schema = {
		person_titles: { type: 'list' },
		include_similar_titles: { type: 'boolean' },
		q_keywords: { type: 'text' },
		person_locations: { type: 'list' },
		person_seniorities: { type: 'list' },
		q_organization_domains_list: { type: 'list' },
		contact_email_status: { type: 'list' },
		organization_ids: { type: 'list' },
		organization_num_employees_ranges: { type: 'list' },
		revenue_range_min: { type: 'number' },
		revenue_range_max: { type: 'number' },
		currently_using_all_of_technology_uids: { type: 'list' },
		currently_using_any_of_technology_uids: { type: 'list' },
		currently_not_using_any_of_technology_uids: { type: 'list' },
		q_organization_job_titles: { type: 'list' },
		organization_job_locations: { type: 'list' },
		organization_num_jobs_range_min: { type: 'number' },
		organization_num_jobs_range_max: { type: 'number' },
		organization_job_posted_at_range_min: { type: 'date' },
		organization_job_posted_at_range_max: { type: 'date' },
		page: { type: 'number' },
		per_page: { type: 'number' },
	};

	const buildInitialFilterObject = () => {
		const obj = {};
		Object.keys(schema).forEach((k) => {
			const t = schema[k].type;
			const raw = Object.hasOwn(initialJSON, k) ? initialJSON[k] : null;

			let value;
			if (raw !== null && raw !== undefined) {
				value = raw;
			} else if (t === 'list') {
				value = [];
			} else if (t === 'boolean') {
				value = false;
			} else {
				value = '';
			}

			if (t === 'list' && !Array.isArray(value)) {
				value = value == null ? [] : [String(value)];
			}

			obj[k] = { type: t, value };
		});

		return obj;
	};

	const [name, setName] = useState('');
	const [filterObject, setFilterObject] = useState(buildInitialFilterObject());
	const [selectedFields, setSelectedFields] = useState([]);
	const [showAddRow, setShowAddRow] = useState(false);
	const [addFieldKey, setAddFieldKey] = useState('');
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState('');

	const availableFields = Object.keys(schema).filter((k) => !selectedFields.includes(k));

	useEffect(() => {
		if (!open) {
			setShowAddRow(false);
			setAddFieldKey('');
			setSelectedFields([]);
			setFilterObject(buildInitialFilterObject());
			setName('');
			setLoading(false);
			setError('');
		}
	}, [open]);

	const labelize = (s) => s.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());

	const updateFilterKey = (key, patch) => {
		setFilterObject((prev) => ({
			...prev,
			[key]: {
				...prev[key],
				...patch,
			},
		}));
	};

	const handleConfirmAddField = () => {
		if (!addFieldKey) return;
		setSelectedFields((s) => [...s, addFieldKey]);

		if (!filterObject[addFieldKey]) {
			const type = schema[addFieldKey].type;
			let value;

			if (type === 'list') {
				value = [];
			} else if (type === 'boolean') {
				value = false;
			} else {
				value = '';
			}
			updateFilterKey(addFieldKey, { type, value });
		}
		setAddFieldKey('');
		setShowAddRow(false);
	};

	const handleRemoveField = (key) => {
		setSelectedFields((s) => s.filter((x) => x !== key));
	};

	const submit = async () => {
		setError('');
		if (selectedFields.length === 0) {
			setError('Please add at least one field before creating a filter.');
			return;
		}
		if (!name.trim()) {
			setError('Filter name is required.');
			return;
		}

		setLoading(true);
		try {
			const params = new URLSearchParams();
			selectedFields.forEach((k) => {
				const entry = filterObject[k];
				if (entry) {
					const v = entry.value;
					if (Array.isArray(v)) {
						v.forEach((item) => {
							params.append(k, item);
						});
					} else if (v !== '' && v !== null && v !== undefined) {
						params.append(k, v);
					}
				}
			});

			const payload = {
				name,
				params: params.toString(),
			};

			await createFilter(payload);
			onAdded?.();
			onClose?.();
		} catch (err) {
			console.error('createFilter err', err);
			setError(err?.message || 'Failed to add filter');
		} finally {
			setLoading(false);
		}
	};

	if (!open) return null;

	return (
		<div className="fixed inset-0 bg-black/30 flex items-center justify-center z-40">
			<div className="bg-white rounded-2xl p-6 w-full max-w-3xl">
				<div className="flex items-center justify-between mb-2">
					<h3 className="font-semibold text-lg">Add Filter</h3>

					<div className="flex items-center gap-2">
						<button
							type="button"
							onClick={() => setShowAddRow((s) => !s)}
							className="px-3 py-1 border rounded flex items-center gap-2 cursor-pointer"
							title="Add field"
						>
							<span className="font-bold">+</span>
							<span className="text-sm">Add field</span>
						</button>
						<button
							type="button"
							onClick={onClose}
							className="p-2 border rounded hover:bg-gray-100 flex items-center justify-center cursor-pointer"
							title="Close"
						>
							<X size={16} />
						</button>
					</div>
				</div>
				<div>
					<label htmlFor="filterName" className="block text-sm mb-1">
						Filter Name
					</label>
					<input
						id="filterName"
						value={name}
						onChange={(e) => setName(e.target.value)}
						className="w-full border px-3 py-2 rounded"
					/>
				</div>

				{showAddRow && (
					<div className="mt-4 flex gap-2 items-center">
						<select
							value={addFieldKey}
							onChange={(e) => setAddFieldKey(e.target.value)}
							className="border px-3 py-2 rounded flex-1"
						>
							<option value="">— pick a field —</option>
							{availableFields.map((k) => (
								<option key={k} value={k}>
									{labelize(k)}
								</option>
							))}
						</select>
						<button
							type="button"
							onClick={handleConfirmAddField}
							disabled={!addFieldKey}
							className="px-4 py-2 bg-indigo-600 text-white rounded disabled:opacity-50"
						>
							Add
						</button>
						<button
							type="button"
							onClick={() => {
								setShowAddRow(false);
								setAddFieldKey('');
							}}
							className="px-3 py-2 border rounded"
						>
							Cancel
						</button>
					</div>
				)}
				<div className="space-y-4 mt-4 h-[240px] overflow-auto">
					{selectedFields.length === 0 && (
						<div className="text-sm text-gray-600">
							No fields added yet — click <span className="font-medium">Add field</span> to start.
						</div>
					)}

					{selectedFields.map((key) => {
						const entry = filterObject[key] || { type: schema[key].type, value: '' };
						return (
							<div key={key} className="border rounded p-3 flex flex-col gap-2">
								<div className="flex items-center justify-between">
									<div>
										<div className="font-medium">{labelize(key)}</div>
										<div className="text-xs text-gray-500">{key}</div>
									</div>
									<div className="flex items-center gap-2">
										{/* <select
											value={entry.type}
											disabled
											className="border px-2 py-1 rounded text-sm bg-gray-100 cursor-not-allowed"
										>
											<option value="list">List (chips)</option>
											<option value="text">Text</option>
											<option value="number">Number</option>
											<option value="boolean">Boolean</option>
											<option value="date">Date</option>
										</select> */}

										<button
											type="button"
											onClick={() => handleRemoveField(key)}
											className="px-2 py-1 border rounded text-sm"
										>
											Remove
										</button>
									</div>
								</div>

								{entry.type === 'list' && (
									<ChipsInput
										value={Array.isArray(entry.value) ? entry.value : []}
										onChange={(next) => updateFilterKey(key, { value: next })}
										placeholder={`Add values for ${labelize(key)}`}
									/>
								)}
								{entry.type === 'text' && (
									<input
										value={entry.value || ''}
										onChange={(e) => updateFilterKey(key, { value: e.target.value })}
										className="w-full border px-3 py-2 rounded"
									/>
								)}
								{entry.type === 'number' && (
									<input
										type="number"
										value={entry.value || ''}
										onChange={(e) => updateFilterKey(key, { value: e.target.value })}
										className="w-full border px-3 py-2 rounded"
									/>
								)}
								{entry.type === 'boolean' && (
									<label className="flex items-center gap-2">
										<input
											type="checkbox"
											checked={Boolean(entry.value)}
											onChange={(e) => updateFilterKey(key, { value: e.target.checked })}
										/>
										<span className="text-sm">Enabled</span>
									</label>
								)}
								{entry.type === 'date' && (
									<input
										type="date"
										value={entry.value || ''}
										onChange={(e) => updateFilterKey(key, { value: e.target.value })}
										className="border px-3 py-2 rounded"
									/>
								)}
							</div>
						);
					})}
				</div>

				{error && <div className="text-red-600 text-sm mt-3">{error}</div>}

				<div className="mt-6 flex justify-end gap-2">
					<button onClick={onClose} className="px-4 py-2 border rounded cursor-pointer">
						Cancel
					</button>
					<button
						onClick={submit}
						disabled={loading}
						className="px-4 py-2 bg-indigo-600 text-white rounded disabled:opacity-50 cursor-pointer"
					>
						{loading ? 'Adding...' : 'Add Filter'}
					</button>
				</div>
			</div>
		</div>
	);
}

AddFilterModal.propTypes = {
	open: PropTypes.bool.isRequired,
	onClose: PropTypes.func.isRequired,
	onAdded: PropTypes.func.isRequired,
};
