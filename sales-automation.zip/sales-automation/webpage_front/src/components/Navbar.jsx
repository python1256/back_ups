import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { User, FileStack, FileText } from 'lucide-react';
import CompanyLogo from '../assets/aspire-logo.svg';

export default function Navbar() {
	const navigate = useNavigate();
	const { logout, user } = useAuth();

	const handleLogout = async () => {
		await logout();
		navigate('/login');
	};

	return (
		<header className="bg-white shadow sticky top-0 h-[72px]">
			<div className="max-w-6xl mx-auto px-4 flex items-center justify-between h-full">
				<div className="flex items-center gap-8">
					<img src={CompanyLogo} alt="Logo" className="h-8 w-auto cursor-pointer" />
					<nav className="flex items-center gap-6">
						<button
							onClick={() => navigate('/')}
							className="flex items-center gap-2 text-gray-700 hover:text-indigo-600 font-medium transition-colors"
						>
							<FileStack className="w-4 h-4" />
							Filters
						</button>
						<button
							onClick={() => navigate('/content-section')}
							className="flex items-center gap-2 text-gray-700 hover:text-indigo-600 font-medium transition-colors"
						>
							<FileText className="w-4 h-4" />
							Contents
						</button>
					</nav>
				</div>

				<div className="flex items-center gap-3">
					<div className="w-10 h-10 rounded-full overflow-hidden bg-indigo-600 flex items-center justify-center text-white">
						{user?.data?.picture ? (
							<img
								src={user.data.picture}
								alt="User Profile"
								className="w-full h-full object-cover"
								referrerPolicy="no-referrer"
							/>
						) : (
							<User className="w-5 h-5" />
						)}
					</div>
					<button
						onClick={handleLogout}
						className="px-3 py-1.5 border rounded-md text-gray-700 hover:bg-gray-100 transition-colors font-medium"
					>
						Logout
					</button>
				</div>
			</div>
		</header>
	);
}
