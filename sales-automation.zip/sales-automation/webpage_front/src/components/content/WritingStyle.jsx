import { useEffect, useState } from 'react';
import { Loader2, PlusCircle, Trash2, Edit2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { getWritingStyles, deleteWritingStyles } from '../../services/contentService';

export default function WritingStyle() {
	const [data, setData] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [page, setPage] = useState(1);
	const [totalPages, setTotalPages] = useState(1);
	const [deletingId, setDeletingId] = useState(null);
	const [deleteError, setDeleteError] = useState(null);

	const navigate = useNavigate();

	useEffect(() => {
		const fetchData = async () => {
			try {
				setLoading(true);
				const res = await getWritingStyles({ page });
				setData(res?.data || []);
				setTotalPages(res?.totalPages || 1);
			} catch (err) {
				setError(err?.message || 'Failed to load data');
			} finally {
				setLoading(false);
			}
		};

		fetchData();
	}, [page]);

	const truncateText = (text, maxLength = 150) => {
		if (!text) return '-';
		return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
	};

	const handleDelete = async (id) => {
		const ok = window.confirm('Are you sure you want to delete this writing style? This action cannot be undone.');
		if (!ok) return;

		try {
			setDeleteError(null);
			setDeletingId(id);
			await deleteWritingStyles(id);

			setData((prev) => prev.filter((item) => item.id !== id));
		} catch (err) {
			const message = err?.message || JSON.stringify(err) || 'Failed to delete writing style';
			console.error('Delete error:', message);
			setDeleteError(message);
		} finally {
			setDeletingId(null);
		}
	};

	return (
		<div className="p-4">
			<div className="flex items-center justify-between mb-6">
				<h2 className="text-xl font-semibold">Writing Style</h2>
				<button
					onClick={() => navigate('/content-section/writing-style/create')}
					className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"
				>
					<PlusCircle size={18} />
					<span>Create New</span>
				</button>
			</div>

			{loading && (
				<div className="flex justify-center py-10">
					<Loader2 className="animate-spin text-indigo-600" size={32} />
				</div>
			)}

			{error && <div className="text-red-600">{error}</div>}

			{!loading && !error && data.length === 0 && (
				<div className="text-gray-500 text-center py-8">No writing styles found.</div>
			)}

			{data.length > 0 && (
				<div className="border rounded-lg overflow-x-auto shadow-sm">
					<table className="min-w-full text-left text-sm">
						<thead className="bg-gray-50 border-b text-gray-600 text-xs uppercase tracking-wider">
							<tr>
								<th className="px-4 py-2 font-medium">Name</th>
								<th className="px-4 py-2 font-medium">Sample Content</th>
								<th className="px-4 py-2 font-medium">Audience</th>
								<th className="px-4 py-2 font-medium text-right">Actions</th>
							</tr>
						</thead>
						<tbody>
							{data.map((item) => (
								<tr key={item.id} className="border-b hover:bg-gray-50">
									<td className="px-4 py-2 align-top">{item.style || item.name || '-'}</td>

									<td className="px-4 py-2 max-w-[500px] truncate align-top" title={item.sample_content}>
										{truncateText(item.sample_content)}
									</td>

									<td className="px-4 py-2 align-top">{item.audience || '-'}</td>

									<td className="px-4 py-2 text-right align-top">
										<div className="inline-flex items-center gap-2">
											<button
												className="flex items-center gap-2 px-3 py-1.5 border rounded hover:bg-gray-50"
												title="Edit"
											>
												<Edit2 className="w-4 h-4" />
												<span className="text-xs">Edit</span>
											</button>

											<button
												onClick={() => handleDelete(item.id)}
												disabled={deletingId === item.id}
												className="flex items-center gap-2 px-3 py-1.5 border rounded hover:bg-gray-50 disabled:opacity-60"
												title="Delete"
											>
												{deletingId === item.id ? (
													<span className="flex items-center gap-2">
														<Loader2 className="animate-spin" />
														<span className="text-xs">Deleting</span>
													</span>
												) : (
													<>
														<Trash2 className="w-4 h-4" />
														<span className="text-xs">Delete</span>
													</>
												)}
											</button>
										</div>
									</td>
								</tr>
							))}
						</tbody>
					</table>
				</div>
			)}

			{data.length > 0 && (
				<div className="flex justify-end mt-6 gap-2">
					<button
						onClick={() => setPage((p) => Math.max(1, p - 1))}
						disabled={page === 1}
						className="px-4 py-1 border rounded disabled:opacity-50 hover:bg-gray-100 transition"
					>
						Prev
					</button>

					<span className="px-4 py-1 border rounded bg-gray-50">
						{page} / {totalPages}
					</span>

					<button
						onClick={() => setPage((p) => (p < totalPages ? p + 1 : p))}
						disabled={page >= totalPages}
						className="px-4 py-1 border rounded disabled:opacity-50 hover:bg-gray-100 transition"
					>
						Next
					</button>
				</div>
			)}

			{deleteError && (
				<div className="fixed right-6 bottom-6 bg-red-50 p-3 rounded shadow">
					<span className="text-sm text-red-700">{deleteError}</span>
				</div>
			)}
		</div>
	);
}
