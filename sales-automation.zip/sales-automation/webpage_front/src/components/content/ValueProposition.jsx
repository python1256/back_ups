import { useEffect, useState } from 'react';
import { Loader2, PlusCircle } from 'lucide-react';
import { getValuePropositions } from '../../services/contentService';
import { useNavigate } from 'react-router-dom';

export default function ValueProposition() {
	const [data, setData] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [page, setPage] = useState(1);
	const [totalPages, setTotalPages] = useState(1);

	const navigate = useNavigate();
	useEffect(() => {
		const fetchData = async () => {
			try {
				setLoading(true);
				const res = await getValuePropositions({ page });

				setData(res?.data || []);
				setTotalPages(res?.totalPages || 1);
			} catch (err) {
				setError(err?.message || 'Failed to load data');
			} finally {
				setLoading(false);
			}
		};

		fetchData();
	}, [page]);

	const formatArray = (arr) => (Array.isArray(arr) && arr.length ? arr.join(', ') : '-');

	const formatDate = (dateString) => {
		const date = new Date(dateString);
		return date.toLocaleString();
	};

	return (
		<div className="p-4">
			<div className="flex items-center justify-between mb-6">
				<h2 className="text-xl font-semibold">Value Proposition</h2>
				<button
					onClick={() => navigate('/content-section/value-proposition/create')}
					className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"
				>
					<PlusCircle size={18} />
					<span>Create New</span>
				</button>
			</div>

			{loading && (
				<div className="flex justify-center py-10">
					<Loader2 className="animate-spin text-indigo-600" size={32} />
				</div>
			)}

			{error && <div className="text-red-600">{error}</div>}

			{!loading && !error && data.length === 0 && (
				<div className="text-gray-500 text-center py-8">No value propositions found.</div>
			)}

			{data.length > 0 && (
				<div className="border rounded-lg overflow-x-auto shadow-sm">
					<table className="min-w-full text-left text-sm">
						<thead className="bg-gray-50 border-b text-gray-600 text-xs uppercase tracking-wider">
							<tr>
								<th className="px-4 py-2 font-medium">Buyer</th>
								<th className="px-4 py-2 font-medium">Description</th>
								<th className="px-4 py-2 font-medium">Persona</th>
								<th className="px-4 py-2 font-medium">Job Title</th>
								<th className="px-4 py-2 font-medium">Department</th>
								<th className="px-4 py-2 font-medium">Seniority</th>
								<th className="px-4 py-2 font-medium">Industry</th>
								<th className="px-4 py-2 font-medium">Created</th>
							</tr>
						</thead>
						<tbody>
							{data.map((item) => (
								<tr key={item.id} className="border-b hover:bg-gray-50">
									<td className="px-4 py-2">{item.buyer}</td>
									<td className="px-4 py-2 max-w-[250px] truncate">{item.description}</td>
									<td className="px-4 py-2">{formatArray(item.persona)}</td>
									<td className="px-4 py-2">{formatArray(item.filters?.job_title)}</td>
									<td className="px-4 py-2">{formatArray(item.filters?.department)}</td>
									<td className="px-4 py-2">{formatArray(item.filters?.seniority_level)}</td>
									<td className="px-4 py-2">{formatArray(item.filters?.industry)}</td>
									<td className="px-4 py-2 text-xs text-gray-500">{formatDate(item.createdAt)}</td>
								</tr>
							))}
						</tbody>
					</table>
				</div>
			)}

			{data.length > 0 && (
				<div className="flex justify-end mt-6 gap-2">
					<button
						onClick={() => setPage((p) => Math.max(1, p - 1))}
						disabled={page === 1}
						className="px-4 py-1 border rounded disabled:opacity-50 hover:bg-gray-100 transition"
					>
						Prev
					</button>

					<span className="px-4 py-1 border rounded bg-gray-50">
						{page} / {totalPages}
					</span>

					<button
						onClick={() => setPage((p) => (p < totalPages ? p + 1 : p))}
						disabled={page >= totalPages}
						className="px-4 py-1 border rounded disabled:opacity-50 hover:bg-gray-100 transition"
					>
						Next
					</button>
				</div>
			)}
		</div>
	);
}
