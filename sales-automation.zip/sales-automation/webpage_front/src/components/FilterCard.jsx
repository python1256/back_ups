import { useNavigate } from 'react-router-dom';
import { Edit, Trash2, MapPin, BadgeCheck, XCircle } from 'lucide-react';
import { deleteFilters } from '../services/filterService';
import PropTypes from 'prop-types';

export default function FilterCard({ filter, onDelete }) {
	const navigate = useNavigate();
	const { filterData = {}, createdAt, updatedAt, createdBy } = filter;
	const titles = filterData.person_titles || [];
	const locations = filterData.person_locations || [];
	const includeSimilar = filterData.include_similar_titles;
	const isCompleted = filter?.status?.toLowerCase() === 'completed';

	const handleDelete = async () => {
		const confirmed = window.confirm(`Are you sure you want to delete "${filter.filterName}"?`);
		if (!confirmed) return;

		try {
			await deleteFilters(filter.id);
			if (onDelete) onDelete(filter.id);
		} catch (error) {
			console.error('Delete failed:', error);
		}
	};

	return (
		<div className="bg-white p-4 rounded-2xl shadow hover:shadow-md transition flex flex-col justify-between border border-gray-100">
			<div>
				<div className="flex items-center justify-between mb-2">
					<div className="flex items-center justify-between gap-2">
						<h3 className="font-semibold text-lg truncate">{filter.filterName || 'Untitled'}</h3>
						<span
							className={`text-xs px-2 py-0.5 rounded-full font-medium ${
								isCompleted ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
							}`}
						>
							{isCompleted ? 'Completed' : 'Processing'}
						</span>
					</div>
					<button
						onClick={() => navigate(`/filter/${filter.id}`)}
						className="px-2 bg-white border rounded-lg shadow hover:bg-gray-50 transition cursor-pointer"
						title="View Filter"
					>
						View
					</button>
				</div>

				{titles.length > 0 && (
					<div className="mt-2">
						<div className="text-xs text-gray-500 mb-1">Titles</div>
						<div className="flex flex-wrap gap-2">
							{titles.map((t, idx) => (
								<span key={`${idx + 1}`} className="bg-indigo-50 text-indigo-700 text-xs px-2 py-1 rounded-full">
									{t}
								</span>
							))}
						</div>
					</div>
				)}

				{locations.length > 0 && (
					<div className="mt-3">
						<div className="text-xs text-gray-500 mb-1 flex items-center gap-1">
							<MapPin size={14} />
							Locations
						</div>
						<div className="flex flex-wrap gap-2">
							{locations.map((l, idx) => (
								<span key={`${idx + 1}`} className="bg-emerald-50 text-emerald-700 text-xs px-2 py-1 rounded-full">
									{l}
								</span>
							))}
						</div>
					</div>
				)}

				<div className="mt-3 flex items-center gap-2 text-xs text-gray-600">
					{includeSimilar ? (
						<BadgeCheck size={16} className="text-green-600" />
					) : (
						<XCircle size={16} className="text-red-500" />
					)}
					{includeSimilar ? 'Including similar titles' : 'Not including similar titles'}
				</div>
			</div>

			<div className="mt-4 flex items-center justify-between text-xs text-gray-400">
				<div className="flex flex-col">
					<span>Created by: {createdBy}</span>
					<span>Created: {new Date(createdAt).toLocaleDateString()}</span>
					<span>Updated: {new Date(updatedAt).toLocaleDateString()}</span>
				</div>

				<div className="flex items-center gap-2">
					{/* <button title="Search" className="p-2 border rounded-full hover:bg-gray-100 transition cursor-pointer">
						<Search size={16} />
					</button> */}
					<button
						title="Edit"
						onClick={() => navigate(`/filter/edit/${filter.id}`)}
						className="p-2 border rounded-full hover:bg-gray-100 transition cursor-pointer"
					>
						<Edit size={16} />
					</button>
					<button
						title="Delete"
						onClick={handleDelete}
						className="p-2 border rounded-full hover:bg-red-50 text-red-600 transition cursor-pointer"
					>
						<Trash2 size={16} />
					</button>
				</div>
			</div>
		</div>
	);
}

FilterCard.propTypes = {
	filter: PropTypes.object.isRequired,
	onDelete: PropTypes.func,
};
