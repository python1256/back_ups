import { createContext, useCallback, useEffect, useMemo, useState } from 'react';
import { verifyAuth } from '../services/authService';
import api from '../services/api';
import PropTypes from 'prop-types';

const AuthContext = createContext();

const AuthProvider = ({ children }) => {
	const [isAuthenticated, setIsAuthenticated] = useState(false);
	const [authChecked, setAuthChecked] = useState(false);
	const [isAccountFrozen, setIsAccountFrozen] = useState(false);
	const [user, setUser] = useState(null);

	const handleLogout = useCallback(async () => {
		try {
			await api.post('/logout', {});
		} catch (err) {
			console.error('Logout failed:', err);
		}
		setIsAuthenticated(false);
		setUser(null);
		setIsAccountFrozen(false);
	}, []);

	const verify = useCallback(async () => {
		try {
			const response = await verifyAuth();
			if (response?.status === 200) {
				setIsAccountFrozen(!!response.data?.is_frozen);
				setIsAuthenticated(true);
				setUser(response.data);
			} else {
				handleLogout();
			}
		} catch (err) {
			console.error('Auth check failed', err);
			handleLogout();
		} finally {
			setAuthChecked(true);
		}
	}, [handleLogout]);

	useEffect(() => {
		verify();
	}, [verify]);

	const contextValue = useMemo(
		() => ({
			isAuthenticated,
			authChecked,
			isAccountFrozen,
			user,
			logout: handleLogout,
			accountVerify: verify,
		}),
		[isAuthenticated, authChecked, user, isAccountFrozen, handleLogout, verify]
	);

	return <AuthContext.Provider value={contextValue}>{children}</AuthContext.Provider>;
};

export { AuthContext, AuthProvider };

AuthProvider.propTypes = {
	children: PropTypes.node.isRequired,
};
