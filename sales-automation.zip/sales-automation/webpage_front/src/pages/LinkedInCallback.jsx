import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { Loader2 } from 'lucide-react';

export default function LinkedInCallback() {
	const navigate = useNavigate();
	const { isAuthenticated, authChecked } = useAuth();

	useEffect(() => {
		if (authChecked) {
			if (isAuthenticated) navigate('/');
			else navigate('/login');
		}
	}, [authChecked, isAuthenticated, navigate]);

	return (
		<div className="h-screen flex items-center justify-center">
			<Loader2 className="animate-spin mr-2" />
			<span>Finishing sign in...</span>
		</div>
	);
}
