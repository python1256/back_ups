import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getFilterById, deleteFilters } from '../services/filterService';
import { ArrowLeft, MapPin, BadgeCheck, XCircle, Calendar, Edit, Trash2, Loader2, Users } from 'lucide-react';

export default function FilterDetail() {
	const { id } = useParams();
	const navigate = useNavigate();
	const [filter, setFilter] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [deleting, setDeleting] = useState(false);

	useEffect(() => {
		const fetchFilter = async () => {
			try {
				setLoading(true);
				setError(null);
				const res = await getFilterById(id);
				if (res) {
					setFilter(res);
				} else {
					setError('Filter not found');
				}
			} catch (err) {
				console.error('Failed to fetch filter:', err);
				setError('Invalid or missing filter');
			} finally {
				setLoading(false);
			}
		};

		fetchFilter();
	}, [id]);

	const handleDelete = async () => {
		const confirmed = window.confirm('Are you sure you want to delete this filter?');
		if (!confirmed) return;

		try {
			setDeleting(true);
			await deleteFilters(id);
			navigate('/');
		} catch (err) {
			console.error('Delete failed:', err);
		} finally {
			setDeleting(false);
		}
	};

	if (loading) {
		return (
			<div className="max-w-4xl mx-auto p-8">
				<div className="animate-pulse space-y-4">
					<div className="h-6 bg-gray-200 rounded w-1/4"></div>
					<div className="h-4 bg-gray-200 rounded w-1/2"></div>
					<div className="h-4 bg-gray-200 rounded w-2/3"></div>
				</div>
			</div>
		);
	}

	if (error) {
		return (
			<div className="max-w-2xl mx-auto p-8 text-center">
				<XCircle size={48} className="mx-auto text-red-500 mb-4" />
				<h2 className="text-xl font-semibold mb-2">Filter Not Found</h2>
				<p className="text-gray-600 mb-4">{error}</p>
				<button
					onClick={() => navigate('/')}
					className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition"
				>
					Back to Filters
				</button>
			</div>
		);
	}

	const { filterName, filterData = {}, createdAt, updatedAt, createdBy } = filter;
	const titles = filterData.person_titles || [];
	const locations = filterData.person_locations || [];
	const includeSimilar = filterData.include_similar_titles;

	return (
		<div className="max-w-4xl mx-auto pt-8 px-4">
			<div className="flex items-center justify-between mb-6">
				<button
					onClick={() => navigate(-1)}
					className="flex items-center gap-2 px-3 py-1 border rounded-lg hover:bg-gray-100 text-gray-600 hover:text-indigo-600 transition"
				>
					<ArrowLeft size={20} />
					<span>Back</span>
				</button>

				<div className="flex items-center gap-2">
					<button
						onClick={() => navigate(`/filter/${id}/profiles`)}
						className="flex items-center gap-1 px-3 py-1 border rounded-lg hover:bg-gray-100 transition cursor-pointer"
					>
						<Users size={20} />
						View Profiles
					</button>

					<button
						onClick={() => navigate(`/filter/edit/${id}`)}
						className="flex items-center gap-1 px-3 py-1 border rounded-lg hover:bg-gray-100 transition cursor-pointer"
					>
						<Edit size={16} /> Edit
					</button>
					<button
						onClick={handleDelete}
						disabled={deleting}
						className="flex items-center gap-1 px-3 py-1 border text-red-600 rounded-lg hover:bg-red-50 transition disabled:opacity-50 cursor-pointer"
					>
						{deleting ? <Loader2 className="animate-spin" size={16} /> : <Trash2 size={16} />}
						Delete
					</button>
				</div>
			</div>

			<h4 className="text-2xl font-semibold mb-2">{filterName || 'Untitled Filter'}</h4>
			{/* <p className="text-sm text-gray-500 mb-6">ID: {id}</p> */}

			<div className="space-y-6">
				{titles.length > 0 && (
					<div>
						<div className="text-sm text-gray-500 mb-2">Titles</div>
						<div className="flex flex-wrap gap-2">
							{titles.map((t, idx) => (
								<span key={`${idx + 1}`} className="bg-indigo-50 text-indigo-700 text-sm px-3 py-1 rounded-full">
									{t}
								</span>
							))}
						</div>
					</div>
				)}

				{locations.length > 0 && (
					<div>
						<div className="text-sm text-gray-500 mb-2 flex items-center gap-1">
							<MapPin size={16} /> Locations
						</div>
						<div className="flex flex-wrap gap-2">
							{locations.map((l, idx) => (
								<span key={`${idx + 1}`} className="bg-emerald-50 text-emerald-700 text-sm px-3 py-1 rounded-full">
									{l}
								</span>
							))}
						</div>
					</div>
				)}

				<div className="flex items-center gap-2 text-gray-700">
					{includeSimilar ? (
						<BadgeCheck size={20} className="text-green-600" />
					) : (
						<XCircle size={20} className="text-red-500" />
					)}
					<span className="text-sm">
						{includeSimilar ? 'Including similar titles' : 'Not including similar titles'}
					</span>
				</div>

				<div className="flex flex-col sm:flex-row sm:items-center gap-4 text-sm text-gray-600 mt-6 border-t pt-4">
					<div className="flex items-center gap-2">
						<Calendar size={16} />
						<span>Created by: {createdBy || 'Unknown'}</span>
					</div>
					<div className="flex items-center gap-2">
						<Calendar size={16} />
						<span>Created: {new Date(createdAt).toLocaleString()}</span>
					</div>
					<div className="flex items-center gap-2">
						<Calendar size={16} />
						<span>Updated: {new Date(updatedAt).toLocaleString()}</span>
					</div>
				</div>
			</div>
		</div>
	);
}
