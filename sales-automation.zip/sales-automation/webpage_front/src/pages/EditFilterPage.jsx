import { useEffect, useRef, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { editFilter, getFilterById } from '../services/filterService';
import { Loader2 } from 'lucide-react';
import PropTypes from 'prop-types';

function ChipsInput({ value = [], placeholder = '', onChange }) {
	const [inputValue, setInputValue] = useState('');
	const inputRef = useRef(null);

	const addChipsFromString = (str) => {
		if (!str) return;
		const parts = str
			.split(',')
			.map((p) => p.trim())
			.filter((p) => p.length);
		if (parts.length === 0) return;
		const next = Array.from(new Set([...value, ...parts]));
		onChange(next);
		setInputValue('');
	};

	const handleKeyDown = (e) => {
		if (e.key === 'Enter' || e.key === ',') {
			e.preventDefault();
			addChipsFromString(inputValue);
		}
		if (e.key === 'Backspace' && inputValue === '' && value.length) {
			onChange(value.slice(0, -1));
		}
	};

	const removeChip = (idx) => {
		const next = value.slice();
		next.splice(idx, 1);
		onChange(next);
	};

	return (
		<div className="border rounded p-2 min-h-[44px] flex flex-wrap gap-2 items-center">
			{value.map((v, i) => (
				<div key={`${i + 1}`} className="flex items-center gap-2 bg-gray-100 rounded px-2 py-1 text-sm">
					<span>{v}</span>
					<button type="button" onClick={() => removeChip(i)} className="text-xs">
						✕
					</button>
				</div>
			))}
			<input
				ref={inputRef}
				value={inputValue}
				placeholder={placeholder || 'Type and press Enter or comma to add'}
				onChange={(e) => setInputValue(e.target.value)}
				onKeyDown={handleKeyDown}
				onBlur={() => addChipsFromString(inputValue)}
				className="flex-1 min-w-[120px] outline-none"
			/>
		</div>
	);
}

ChipsInput.propTypes = {
	value: PropTypes.array.isRequired,
	placeholder: PropTypes.string,
	onChange: PropTypes.func.isRequired,
};

export default function EditFilterPage() {
	const { id } = useParams();
	const navigate = useNavigate();

	const [name, setName] = useState('');
	const [selectedFields, setSelectedFields] = useState([]);
	const [filterObject, setFilterObject] = useState({});
	const [addFieldKey, setAddFieldKey] = useState('');
	const [showAddRow, setShowAddRow] = useState(false);
	const [loading, setLoading] = useState(false);
	const [isFetching, setIsFetching] = useState(false);
	const [error, setError] = useState('');

	const schema = {
		person_titles: { type: 'list' },
		include_similar_titles: { type: 'boolean' },
		q_keywords: { type: 'text' },
		person_locations: { type: 'list' },
		person_seniorities: { type: 'list' },
		q_organization_domains_list: { type: 'list' },
		contact_email_status: { type: 'list' },
		organization_ids: { type: 'list' },
		organization_num_employees_ranges: { type: 'list' },
		revenue_range_min: { type: 'number' },
		revenue_range_max: { type: 'number' },
		currently_using_all_of_technology_uids: { type: 'list' },
		currently_using_any_of_technology_uids: { type: 'list' },
		currently_not_using_any_of_technology_uids: { type: 'list' },
		q_organization_job_titles: { type: 'list' },
		organization_job_locations: { type: 'list' },
		organization_num_jobs_range_min: { type: 'number' },
		organization_num_jobs_range_max: { type: 'number' },
		organization_job_posted_at_range_min: { type: 'date' },
		organization_job_posted_at_range_max: { type: 'date' },
		page: { type: 'number' },
		per_page: { type: 'number' },
	};

	const labelize = (s) => s.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
	const availableFields = Object.keys(schema).filter((k) => !selectedFields.includes(k));

	useEffect(() => {
		const loadFilter = async () => {
			setIsFetching(true);
			try {
				const data = await getFilterById(id);
				setName(data.filterName || '');
				const paramsData = data.filterData || {};
				const initialSelected = Object.keys(paramsData);
				setSelectedFields(initialSelected);

				const fo = {};
				initialSelected.forEach((key) => {
					const type = schema[key]?.type || 'text';
					const rawVal = paramsData[key];

					let val;
					if (type === 'boolean') {
						// Accept 'true'/'false' strings, numbers as truthy, or booleans
						if (rawVal === 'true' || rawVal === true) val = true;
						else if (rawVal === 'false' || rawVal === false) val = false;
						else val = Boolean(rawVal);
					} else if (type === 'list') {
						// normalize to array
						if (Array.isArray(rawVal)) val = rawVal;
						else if (rawVal == null) val = [];
						else
							val = String(rawVal)
								.split(',')
								.map((s) => s.trim())
								.filter(Boolean);
					} else if (type === 'number') {
						if (rawVal === null || rawVal === undefined || rawVal === '') val = '';
						else {
							const n = Number(rawVal);
							val = Number.isNaN(n) ? String(rawVal) : n;
						}
					} else {
						// text / date
						if (rawVal == null) val = '';
						else val = String(rawVal);
					}

					fo[key] = { type, value: val };
				});

				setFilterObject(fo);
			} catch (err) {
				console.error('Error loading filter', err);
				setError('Failed to load filter. Please try again.');
			} finally {
				setIsFetching(false);
			}
		};

		loadFilter();
	}, [id]);

	const updateFilterKey = (key, patch) => {
		setFilterObject((prev) => ({
			...prev,
			[key]: {
				...prev[key],
				...patch,
			},
		}));
	};

	const handleConfirmAddField = () => {
		if (!addFieldKey) return;
		setSelectedFields((s) => [...s, addFieldKey]);
		setAddFieldKey('');
		setShowAddRow(false);
		updateFilterKey(addFieldKey, { type: schema[addFieldKey].type, value: [] });
	};

	const handleRemoveField = (key) => {
		setSelectedFields((s) => s.filter((x) => x !== key));
		setFilterObject((prev) => {
			const next = { ...prev };
			delete next[key];
			return next;
		});
	};

	const submit = async () => {
		setError('');
		if (!name.trim()) {
			setError('Filter name is required.');
			return;
		}
		if (selectedFields.length === 0) {
			setError('Please add at least one field before saving.');
			return;
		}

		const payload = {};
		selectedFields.forEach((k) => {
			const entry = filterObject[k];
			if (entry) {
				if (entry.type === 'boolean') {
					payload[k] = entry.value;
				} else if (Array.isArray(entry.value) && entry.value.length > 0) {
					payload[k] = entry.value;
				}
			}
		});

		if (Object.keys(payload).length === 0) {
			setError('Please fill at least one field value.');
			return;
		}

		setLoading(true);
		try {
			const query = new URLSearchParams(payload);
			await editFilter({
				id,
				name: name.trim(),
				params: query.toString(),
			});
			navigate('/');
		} catch (err) {
			console.error('updateFilter err', err);
			setError(err?.message || 'Failed to update filter');
		} finally {
			setLoading(false);
		}
	};

	if (isFetching) {
		return (
			<div className="max-w-4xl mx-auto py-24 flex items-center justify-center">
				<div className="flex items-center gap-3 text-sm text-gray-700">
					<Loader2 className="animate-spin" />
					<span>Loading filter...</span>
				</div>
			</div>
		);
	}

	return (
		<div className="max-w-4xl mx-auto p-4 bg-white h-full">
			<div className="flex items-center justify-between mb-2 shrink-0">
				<h3 className="font-semibold text-lg">Edit Filter</h3>
				<button
					type="button"
					onClick={() => navigate(-1)}
					className="px-3 py-1 border rounded-lg hover:bg-gray-100 cursor-pointer flex items-center justify-center"
				>
					Back
				</button>
			</div>

			<div className="flex-1 pr-1 h-[75%]">
				<div className="flex items-end gap-4 mb-4">
					<div className="flex-1">
						<label htmlFor="filter-name" className="block text-sm mb-1">
							Filter Name
						</label>
						<input
							id="filter-name"
							value={name}
							onChange={(e) => setName(e.target.value)}
							disabled={isFetching}
							className="w-full border px-3 py-2 rounded disabled:opacity-50"
						/>
					</div>

					<button
						type="button"
						onClick={() => setShowAddRow((s) => !s)}
						disabled={isFetching}
						className="px-3 py-2 border rounded flex items-center gap-2 cursor-pointer h-fit"
					>
						<span className="font-bold">+</span> Add field
					</button>
				</div>

				{showAddRow && (
					<div className="mb-4 flex gap-2 items-center">
						<select
							value={addFieldKey}
							onChange={(e) => setAddFieldKey(e.target.value)}
							className="border px-3 py-2 rounded flex-1"
						>
							<option value="">— pick a field —</option>
							{availableFields.map((k) => (
								<option key={k} value={k}>
									{labelize(k)}
								</option>
							))}
						</select>
						<button
							type="button"
							onClick={handleConfirmAddField}
							disabled={!addFieldKey}
							className="px-4 py-2 bg-indigo-600 text-white rounded disabled:opacity-50 cursor-pointer"
						>
							Add
						</button>
						<button
							type="button"
							onClick={() => {
								setShowAddRow(false);
								setAddFieldKey('');
							}}
							className="px-3 py-2 border rounded cursor-pointer"
						>
							Cancel
						</button>
					</div>
				)}

				<div className={`space-y-4 ${showAddRow ? 'h-[60%]' : 'h-[75%]'} overflow-auto`}>
					{selectedFields.length === 0 && (
						<div className="text-sm text-gray-600">
							No fields selected — click <span className="font-medium">Add field</span> to begin.
						</div>
					)}

					{selectedFields.map((key) => {
						const entry = filterObject[key] || { type: schema[key].type, value: '' };
						return (
							<div key={key} className="border rounded p-3 flex flex-col gap-2">
								<div className="flex items-center justify-between">
									<div>
										<div className="font-medium">{labelize(key)}</div>
										<div className="text-xs text-gray-500">{key}</div>
									</div>
									<div className="flex items-center gap-2">
										<button
											type="button"
											onClick={() => handleRemoveField(key)}
											disabled={isFetching}
											className="px-2 py-1 border rounded text-sm cursor-pointer"
										>
											Remove
										</button>
									</div>
								</div>

								{entry.type === 'list' && (
									<ChipsInput
										value={Array.isArray(entry.value) ? entry.value : []}
										onChange={(next) => updateFilterKey(key, { value: next })}
									/>
								)}
								{entry.type === 'text' && (
									<input
										value={entry.value || ''}
										onChange={(e) => updateFilterKey(key, { value: e.target.value })}
										className="w-full border px-3 py-2 rounded"
									/>
								)}
								{entry.type === 'number' && (
									<input
										type="number"
										value={entry.value || ''}
										onChange={(e) => updateFilterKey(key, { value: e.target.value })}
										className="w-full border px-3 py-2 rounded"
									/>
								)}
								{entry.type === 'boolean' && (
									<label className="flex items-center gap-2">
										<input
											type="checkbox"
											checked={Boolean(entry.value)}
											onChange={(e) => updateFilterKey(key, { value: e.target.checked })}
										/>
										<span className="text-sm">Enabled</span>
									</label>
								)}
								{entry.type === 'date' && (
									<input
										type="date"
										value={entry.value || ''}
										onChange={(e) => updateFilterKey(key, { value: e.target.value })}
										className="border px-3 py-2 rounded"
									/>
								)}
							</div>
						);
					})}
				</div>

				{error && <div className="text-red-600 text-sm mt-3">{error}</div>}
			</div>

			<div className="mt-4 flex justify-end gap-2 shrink-0">
				<button onClick={() => navigate(-1)} className="px-4 py-2 border rounded cursor-pointer">
					Cancel
				</button>
				<button
					onClick={submit}
					disabled={isFetching || loading}
					className="px-4 py-2 bg-indigo-600 text-white rounded disabled:opacity-50 cursor-pointer"
				>
					{loading ? 'Saving...' : 'Save Changes'}
				</button>
			</div>
		</div>
	);
}
