import GetCurrentUrl from '../../components/extension/scrap';

function ExtensionHome() {
	return <GetCurrentUrl />;
}

export default ExtensionHome;
