import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader2, MapPin, Building2, Link, User, CalendarCheck2 } from 'lucide-react';
import { getProfileById } from '../services/profileService';
import { timeAgo } from '../utils/utilFunctions';

export default function ProfileDetailPage() {
	const { id } = useParams();
	const navigate = useNavigate();
	const [data, setData] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);

	useEffect(() => {
		const fetchData = async () => {
			try {
				setLoading(true);
				const res = await getProfileById(id);
				setData(res);
			} catch (err) {
				console.error('Failed to fetch profile detail:', err);
				setError(err?.message || 'Failed to load profile details');
			} finally {
				setLoading(false);
			}
		};
		fetchData();
	}, [id]);

	if (loading) {
		return (
			<div className="flex justify-center py-10">
				<Loader2 className="animate-spin text-indigo-600" size={32} />
			</div>
		);
	}

	if (error) {
		return <div className="text-red-600 text-center py-10">{error}</div>;
	}

	if (!data) return null;

	const { profileData, companyData, scoringData, decisionData } = data;

	return (
		<div className="max-w-4xl mx-auto p-6">
			<div className="flex items-center justify-between mb-6 sticky top-0 bg-white z-10 pb-2 border-b">
				<button
					onClick={() => navigate(-1)}
					className="flex items-center gap-2 px-3 py-1 border rounded-lg hover:bg-gray-100 text-gray-600 hover:text-indigo-600 transition cursor-pointer"
				>
					<ArrowLeft size={20} />
					<span>Back</span>
				</button>
				<h2 className="text-xl font-semibold">{profileData?.name || 'Profile Detail'}</h2>
			</div>

			<div className="space-y-6 overflow-y-auto max-h-[calc(100vh-190px)] pr-2">
				<section className="border rounded-lg p-5 shadow-sm">
					<div className="flex items-center justify-between mb-3">
						<h3 className="font-semibold text-lg">Profile Information</h3>
						{data?.updatedAt && (
							<div className="flex items-center gap-1 text-xs text-gray-500">
								<CalendarCheck2 size={14} />
								<span className="whitespace-nowrap">{timeAgo(data.updatedAt)}</span>
							</div>
						)}
					</div>
					<div className="flex items-center gap-3">
						{profileData?.profile_image_url ? (
							<img
								src={profileData.profile_image_url}
								alt={profileData?.name || 'Profile Avatar'}
								className="w-12 h-12 rounded-full object-cover border"
							/>
						) : (
							<div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center border">
								<User size={22} className="text-gray-500" />
							</div>
						)}
						<div>
							<p className="text-xl font-bold">{profileData?.name}</p>
							<p className="text-gray-600">{profileData?.headline}</p>
						</div>
					</div>
					<p className="flex items-center gap-1 text-sm text-gray-500 mt-1">
						<MapPin size={14} /> {profileData?.location}
					</p>
					{profileData?.contact_info?.linkedin_profile && (
						<a
							href={`https://${profileData.contact_info.linkedin_profile}`}
							target="_blank"
							rel="noopener noreferrer"
							className="inline-flex items-center gap-1 mt-2 text-indigo-600 hover:underline text-sm"
						>
							<Link size={14} /> LinkedIn Profile
						</a>
					)}

					{profileData?.about && (
						<div className="mt-4">
							<p className="text-gray-700 whitespace-pre-line text-sm">{profileData.about.overview}</p>
							<div className="mt-2 text-xs text-gray-500 space-y-1">
								<p>
									<strong>Industry:</strong> {profileData.about.industry}
								</p>
								<p>
									<strong>Company Size:</strong> {profileData.about['company size']}
								</p>
								<p>
									<strong>Founded:</strong> {profileData.about.founded}
								</p>
								<p>
									<strong>Website:</strong>{' '}
									<a href={profileData.about.website} className="text-indigo-600 hover:underline">
										{profileData.about.website}
									</a>
								</p>
							</div>
						</div>
					)}
				</section>

				{profileData?.experience?.length > 0 && (
					<section className="border rounded-lg p-5 shadow-sm">
						<h3 className="font-semibold text-lg mb-3">Experience</h3>
						<div className="space-y-3">
							{profileData.experience.map((exp, i) => (
								<div key={`${i + 1}`} className="border rounded p-3">
									<h4 className="font-semibold">{exp.position}</h4>
									<p className="text-sm text-gray-700">{exp.company_name}</p>
									<p className="text-xs text-gray-500">
										{exp.duration} — {exp.location}
									</p>
								</div>
							))}
						</div>
					</section>
				)}

				{companyData && (
					<section className="border rounded-lg p-5 shadow-sm">
						<h3 className="font-semibold text-lg mb-3 flex items-center gap-1">
							<Building2 size={18} /> Company Details
						</h3>
						<p className="font-semibold text-gray-800">{companyData.company_details?.name}</p>
						<p className="text-sm text-gray-600 mb-2">{companyData.business_model?.business_model}</p>

						<div className="text-xs text-gray-500 space-y-1">
							<p>
								<strong>Vision:</strong> {companyData.company_details?.vision}
							</p>
							{companyData.company_details?.services?.length > 0 && (
								<p>
									<strong>Services:</strong> {companyData.company_details.services.join(', ')}
								</p>
							)}
							{companyData.tech_stack?.tech_stack?.length > 0 && (
								<p>
									<strong>Tech Stack:</strong> {companyData.tech_stack.tech_stack.join(', ')}
								</p>
							)}
						</div>
					</section>
				)}

				{scoringData && (
					<section className="border rounded-lg p-5 shadow-sm">
						<h3 className="font-semibold text-lg mb-3">Profile Scoring</h3>
						<p className="text-lg font-bold text-indigo-600">Score: {scoringData.overall_match_score}%</p>
						<p className="text-sm mt-2 text-gray-700">{scoringData.overview}</p>
						<ul className="mt-3 space-y-1 text-sm text-gray-600">
							{Object.entries(scoringData.factor_scores || {}).map(([k, v]) => (
								<li key={k}>
									<strong className="capitalize">{k}:</strong> {v}
								</li>
							))}
						</ul>
					</section>
				)}

				{decisionData && (
					<section className="border rounded-lg p-5 shadow-sm">
						<h3 className="font-semibold text-lg mb-3">Decision Summary</h3>
						<p>
							<strong>Decision:</strong> {decisionData.decision}
						</p>
						<p>
							<strong>Score:</strong> {decisionData.score}
						</p>
						<p className="text-sm mt-2 text-gray-700">{decisionData.rationale}</p>
					</section>
				)}

				{companyData?.clients?.clients?.length > 0 && (
					<section className="border rounded-lg p-5 shadow-sm">
						<h3 className="font-semibold text-lg mb-3">Clients</h3>
						<div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-72 overflow-y-auto pr-2">
							{companyData.clients.clients.map((client, i) => (
								<div key={`${i + 1}`} className="border rounded p-3 hover:shadow transition">
									<p className="font-semibold">{client.name}</p>
									<p className="text-xs text-gray-500 mb-1">{client.industry}</p>
									<p className="text-sm text-gray-600">{client.description}</p>
								</div>
							))}
						</div>
					</section>
				)}
			</div>
		</div>
	);
}
