import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { createSalesAsset } from '../../../services/contentService';

export default function CreateSalesAssetPage() {
	const [name, setName] = useState('');
	const [content, setContent] = useState('');
	const [type, setType] = useState('');

	const [loadingSubmit, setLoadingSubmit] = useState(false);
	const [error, setError] = useState(null);

	const navigate = useNavigate();

	const handleBack = () => {
		const hasUnsaved = name.trim() || content.trim() || type.trim();
		if (hasUnsaved) {
			const ok = window.confirm('You have unsaved changes. Leave and lose changes?');
			if (!ok) return;
		}
		navigate(-1);
	};

	const handleCreate = async () => {
		if (!name.trim()) {
			alert('Please enter Name.');
			return;
		}
		if (!content.trim()) {
			alert('Please enter Summary / Content.');
			return;
		}

		const payload = {
			name: name.trim(),
			content: content.trim(),
			type: type.trim() || '',
		};

		try {
			setLoadingSubmit(true);
			setError(null);
			await createSalesAsset(payload);
			setLoadingSubmit(false);
			navigate(-1);
		} catch (err) {
			setLoadingSubmit(false);
			const message = err?.message || JSON.stringify(err) || 'Failed to create sales asset';
			console.error('Error creating sales asset:', message);
			setError(message);
		}
	};

	return (
		<div className="max-w-4xl mx-auto p-6 space-y-6">
			<div>
				<h4 className="text-2xl font-semibold">Create Sales Asset</h4>
				<p className="text-gray-600 mt-1">Add a new sales asset. Name and Summary are required.</p>
			</div>

			<div className="grid grid-cols-1 gap-4">
				<div className="flex flex-col gap-2">
					<label htmlFor="name" className="text-sm font-medium text-gray-700">
						Name *
					</label>
					<input
						id="name"
						value={name}
						onChange={(e) => setName(e.target.value)}
						className="border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
						placeholder="Enter asset name..."
					/>
				</div>

				<div className="flex flex-col gap-2">
					<label htmlFor="content" className="text-sm font-medium text-gray-700">
						Content *
					</label>
					<textarea
						id="content"
						value={content}
						onChange={(e) => setContent(e.target.value)}
						rows={6}
						className="border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none resize-vertical"
						placeholder="Short summary or content of the sales asset..."
					/>
				</div>

				<div className="flex flex-col gap-2">
					<label htmlFor="type-sales-asset" className="text-sm font-medium text-gray-700">
						Type (optional)
					</label>
					<input
						id="type-sales-asset"
						value={type}
						onChange={(e) => setType(e.target.value)}
						className="border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
						placeholder="e.g. One-pager, Case Study, Presentation..."
					/>
				</div>
			</div>

			<div className="flex justify-end gap-3">
				<button onClick={handleBack} className="px-4 py-2 border rounded-lg">
					Back
				</button>

				<button
					onClick={handleCreate}
					disabled={loadingSubmit || !name.trim() || !content.trim()}
					className="px-5 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50"
				>
					{loadingSubmit ? (
						<span className="flex items-center gap-2">
							<Loader2 className="animate-spin" />
							Creating...
						</span>
					) : (
						'Create'
					)}
				</button>
			</div>

			{error && (
				<div className="fixed right-6 bottom-6 bg-red-50 p-3 rounded shadow">
					<span className="text-sm text-red-700">{error}</span>
				</div>
			)}
		</div>
	);
}
