import React from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import ValueProposition from '../../components/content/ValueProposition';
import SalesAssets from '../../components/content/SalesAssets';
import WritingStyle from '../../components/content/WritingStyle';

const tabs = [
	{ name: 'Value Proposition', path: '/content-section/value-proposition' },
	{ name: 'Sales Assets', path: '/content-section/sales-assets' },
	{ name: 'Writing Style', path: '/content-section/writing-style' },
];

export default function ContentSectionPage() {
	const location = useLocation();
	const navigate = useNavigate();

	React.useEffect(() => {
		if (location.pathname === '/content-section') {
			navigate(tabs[0].path, { replace: true });
		}
	}, [location.pathname, navigate]);

	const renderContent = () => {
		switch (location.pathname) {
			case '/content-section/value-proposition':
				return <ValueProposition />;
			case '/content-section/sales-assets':
				return <SalesAssets />;
			case '/content-section/writing-style':
				return <WritingStyle />;
			default:
				return null;
		}
	};

	return (
		<div className="max-w-6xl h-full mx-auto p-6 flex gap-2">
			<div className="h-full w-48 border-r pr-4 flex flex-col gap-2">
				{tabs.map((tab) => (
					<NavLink
						key={tab.path}
						to={tab.path}
						className={({ isActive }) =>
							`px-4 py-2 rounded text-left transition ${
								isActive ? 'bg-indigo-600 text-white' : 'hover:bg-gray-100 text-gray-700'
							}`
						}
					>
						{tab.name}
					</NavLink>
				))}
			</div>

			<div className="flex-1 overflow-auto">{renderContent()}</div>
		</div>
	);
}
