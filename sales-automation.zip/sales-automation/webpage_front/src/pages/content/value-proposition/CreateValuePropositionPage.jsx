import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronDown, Loader2, X, Trash2 } from 'lucide-react';
import { createValueProposition, getPersonaLibrary } from '../../../services/contentService';

export default function CreateValuePropositionPage() {
	const [personaList, setPersonaList] = useState([]);
	const [selectedPersona, setSelectedPersona] = useState(null);

	const [buyerPersonaName, setBuyerPersonaName] = useState('');
	const [description, setDescription] = useState(
		'This helps marketing leaders streamline lead generation using AI-driven insights.'
	);

	const [deptOptions, setDeptOptions] = useState([]);
	const [industryOptions, setIndustryOptions] = useState([]);
	const [seniorityOptions, setSeniorityOptions] = useState([]);

	const [jobTitleKeyword, setJobTitleKeyword] = useState('');
	const [selectedDepartments, setSelectedDepartments] = useState([]);
	const [selectedIndustries, setSelectedIndustries] = useState([]);
	const [selectedSeniorities, setSelectedSeniorities] = useState([]);

	const [openAccordion, setOpenAccordion] = useState(null);
	const [loadingOptions, setLoadingOptions] = useState(true);
	const [loadingSubmit, setLoadingSubmit] = useState(false);
	const [error, setError] = useState(null);

	const navigate = useNavigate();

	useEffect(() => {
		let cancelled = false;
		async function fetchData() {
			try {
				setLoadingOptions(true);
				const res = await getPersonaLibrary();
				if (cancelled) return;
				setPersonaList(res?.persona || []);
				setDeptOptions(res?.department || []);
				setIndustryOptions(res?.industries || []);
				setSeniorityOptions(res?.seniority_level || []);
			} catch (err) {
				if (!cancelled) setError(err?.message || 'Failed to fetch options');
			} finally {
				if (!cancelled) setLoadingOptions(false);
			}
		}
		fetchData();
		return () => {
			cancelled = true;
		};
	}, []);

	const toggleAccordion = (key) => {
		setOpenAccordion((prev) => (prev === key ? null : key));
	};

	const toggleSelection = (value, selected, setSelected) => {
		setSelected((prev) => (prev.includes(value) ? prev.filter((v) => v !== value) : [...prev, value]));
	};

	const removeChip = (type, value) => {
		if (type === 'dept') setSelectedDepartments((s) => s.filter((v) => v !== value));
		if (type === 'industry') setSelectedIndustries((s) => s.filter((v) => v !== value));
		if (type === 'seniority') setSelectedSeniorities((s) => s.filter((v) => v !== value));
		if (type === 'keyword') setJobTitleKeyword('');
	};

	const clearFilters = () => {
		setJobTitleKeyword('');
		setSelectedDepartments([]);
		setSelectedIndustries([]);
		setSelectedSeniorities([]);
		setOpenAccordion(null);
	};

	const filtersAppliedCount =
		(jobTitleKeyword ? 1 : 0) + selectedDepartments.length + selectedIndustries.length + selectedSeniorities.length;

	const handleBack = () => {
		const hasUnsaved =
			buyerPersonaName ||
			description ||
			jobTitleKeyword ||
			selectedDepartments.length ||
			selectedIndustries.length ||
			selectedSeniorities.length;

		if (hasUnsaved) {
			const ok = window.confirm('You have unsaved changes. Leave and lose changes?');
			if (!ok) return;
		}
		navigate(-1);
	};

	const handleContinue = async () => {
		if (!buyerPersonaName.trim()) {
			alert('Please enter Buyer (persona) name.');
			return;
		}

		if (!description.trim()) {
			alert('Description is required. Please add a description.');
			return;
		}

		if (filtersAppliedCount === 0) {
			alert('Please apply at least one filter before continuing.');
			return;
		}

		const payload = {
			buyer: buyerPersonaName,
			description: description,
			filters: {
				job_title: jobTitleKeyword || 'text',
				department: selectedDepartments,
				industry: selectedIndustries,
				seniority_level: selectedSeniorities,
			},
			persona: selectedPersona ? [selectedPersona.title] : [],
		};

		try {
			setLoadingSubmit(true);
			await createValueProposition(payload);
			setLoadingSubmit(false);
			navigate(-1);
		} catch (err) {
			setLoadingSubmit(false);
			const message = err?.message || JSON.stringify(err) || 'Failed to create value proposition';
			console.error('Error creating value proposition:', message);
			setError(message);
		}
	};

	return (
		<div className="max-w-6xl mx-auto p-6 space-y-6">
			<div>
				<h4 className="text-2xl font-semibold">Define your persona by adding filters</h4>
				<p className="text-gray-600 mt-1">Create different personas using filters — at least one filter is required.</p>
			</div>

			<div className="grid grid-cols-1 md:grid-cols-3 gap-4">
				<div className="flex flex-col gap-2">
					<label htmlFor="persona" className="text-sm font-medium text-gray-700">
						Select Persona from Library
					</label>
					<select
						id="persona"
						value={selectedPersona?.id || ''}
						onChange={(e) => {
							const sel = personaList.find((p) => p.id === e.target.value);
							setSelectedPersona(sel || null);
						}}
						className="border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
					>
						<option value="">Select Persona</option>
						{personaList.map((p) => (
							<option key={p.id} value={p.id}>
								{p.title}
							</option>
						))}
					</select>
				</div>

				<div className="flex flex-col gap-2 md:col-span-2">
					<label htmlFor="buyer" className="text-sm font-medium text-gray-700">
						Buyer Persona Name *
					</label>
					<input
						id="buyer"
						value={buyerPersonaName}
						onChange={(e) => setBuyerPersonaName(e.target.value)}
						className="border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
						placeholder="Enter buyer persona name..."
					/>
				</div>
			</div>

			<div className="flex flex-col gap-2">
				<label htmlFor="description" className="text-sm font-medium text-gray-700">
					Description *
				</label>
				<div className="flex gap-3 items-center">
					<input
						id="description"
						value={description}
						onChange={(e) => setDescription(e.target.value)}
						className="flex-1 border rounded-lg p-3 focus:ring-2 focus:ring-indigo-500 outline-none"
						placeholder="Short description..."
					/>
				</div>
			</div>

			<div className="border rounded-lg p-4 bg-gray-50">
				<div className="flex items-start justify-between gap-4">
					<div>
						<p className="font-medium text-gray-700">
							{filtersAppliedCount} Filter{filtersAppliedCount !== 1 ? 's' : ''} Applied
							<span className="text-gray-500"> (At least one required)</span>
						</p>
						<p className="text-xs text-gray-400 mt-1">
							Use checkboxes to select multiple values. Selected values show as chips.
						</p>
					</div>

					<div className="flex items-center gap-2">
						<button
							onClick={clearFilters}
							className="flex items-center gap-2 px-3 py-1.5 bg-white border rounded text-sm hover:bg-gray-50"
						>
							<Trash2 className="w-4 h-4" />
							Clear filters
						</button>
					</div>
				</div>

				<div className="mt-4 space-y-3">
					<div className="border rounded-lg overflow-hidden">
						<button
							onClick={() => toggleAccordion('job')}
							className={`w-full flex justify-between items-center p-3 bg-white ${openAccordion === 'job' ? 'ring-1 ring-indigo-100' : ''}`}
						>
							<div className="text-left">
								<div className="text-sm font-medium text-gray-800">Job Title Keyword</div>
								<div className="text-xs text-gray-500">
									{jobTitleKeyword ? `Applied: "${jobTitleKeyword}"` : 'Filter by job title text'}
								</div>
							</div>
							<ChevronDown
								className={`transform transition-transform ${openAccordion === 'job' ? 'rotate-180' : ''}`}
							/>
						</button>
						{openAccordion === 'job' && (
							<div className="p-3 bg-white border-t">
								<input
									value={jobTitleKeyword}
									onChange={(e) => setJobTitleKeyword(e.target.value)}
									className="w-full border rounded p-2 focus:ring-2 focus:ring-indigo-500 outline-none"
									placeholder="Enter job title keyword"
								/>
								<div className="mt-3 flex items-center gap-2">
									<button
										onClick={() => setOpenAccordion(null)}
										className="px-3 py-1 rounded bg-indigo-600 text-white text-sm"
									>
										Apply
									</button>
									<button onClick={() => setJobTitleKeyword('')} className="px-3 py-1 text-sm rounded border">
										Reset
									</button>
								</div>
							</div>
						)}
					</div>

					<div className="border rounded-lg overflow-hidden">
						<button
							onClick={() => toggleAccordion('dept')}
							className={`w-full flex justify-between items-center p-3 bg-white ${openAccordion === 'dept' ? 'ring-1 ring-indigo-100' : ''}`}
						>
							<div className="text-left">
								<div className="text-sm font-medium text-gray-800">Department</div>
								<div className="text-xs text-gray-500">{selectedDepartments.length} selected</div>
							</div>
							<ChevronDown
								className={`transform transition-transform ${openAccordion === 'dept' ? 'rotate-180' : ''}`}
							/>
						</button>
						{openAccordion === 'dept' && (
							<div className="p-3 bg-white border-t">
								<div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
									{deptOptions.length === 0 && <div className="text-sm text-gray-500">No options</div>}
									{deptOptions.map((o, idx) => {
										const title = o.title || o;
										const checked = selectedDepartments.includes(title);
										return (
											<label
												htmlFor={`title-dept-${idx}`}
												key={title}
												className="flex items-start gap-3 p-2 bg-white border rounded-lg hover:bg-gray-50 cursor-pointer"
											>
												<input
													id={`title-dept-${idx}`}
													type="checkbox"
													checked={checked}
													onChange={() => toggleSelection(title, selectedDepartments, setSelectedDepartments)}
													className="mt-1"
												/>
												<span className="text-sm">{title}</span>
											</label>
										);
									})}
								</div>
								<div className="mt-3 flex items-center gap-2">
									<button
										onClick={() => setOpenAccordion(null)}
										className="px-3 py-1 rounded bg-indigo-600 text-white text-sm"
									>
										Done
									</button>
									<button onClick={() => setSelectedDepartments([])} className="px-3 py-1 text-sm rounded border">
										Clear
									</button>
								</div>
							</div>
						)}
					</div>

					<div className="border rounded-lg overflow-hidden">
						<button
							onClick={() => toggleAccordion('seniority')}
							className={`w-full flex justify-between items-center p-3 bg-white ${openAccordion === 'seniority' ? 'ring-1 ring-indigo-100' : ''}`}
						>
							<div className="text-left">
								<div className="text-sm font-medium text-gray-800">Seniority Level</div>
								<div className="text-xs text-gray-500">{selectedSeniorities.length} selected</div>
							</div>
							<ChevronDown
								className={`transform transition-transform ${openAccordion === 'seniority' ? 'rotate-180' : ''}`}
							/>
						</button>
						{openAccordion === 'seniority' && (
							<div className="p-3 bg-white border-t">
								<div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
									{seniorityOptions.length === 0 && <div className="text-sm text-gray-500">No options</div>}
									{seniorityOptions.map((o, idx) => {
										const title = o.title || o;
										const checked = selectedSeniorities.includes(title);
										return (
											<label
												htmlFor={`title-seniority-${idx}`}
												key={title}
												className="flex items-start gap-3 p-2 bg-white border rounded-lg hover:bg-gray-50 cursor-pointer"
											>
												<input
													id={`title-seniority-${idx}`}
													type="checkbox"
													checked={checked}
													onChange={() => toggleSelection(title, selectedSeniorities, setSelectedSeniorities)}
													className="mt-1"
												/>
												<span className="text-sm">{title}</span>
											</label>
										);
									})}
								</div>
								<div className="mt-3 flex items-center gap-2">
									<button
										onClick={() => setOpenAccordion(null)}
										className="px-3 py-1 rounded bg-indigo-600 text-white text-sm"
									>
										Done
									</button>
									<button onClick={() => setSelectedSeniorities([])} className="px-3 py-1 text-sm rounded border">
										Clear
									</button>
								</div>
							</div>
						)}
					</div>

					<div className="border rounded-lg overflow-hidden">
						<button
							onClick={() => toggleAccordion('industry')}
							className={`w-full flex justify-between items-center p-3 bg-white ${openAccordion === 'industry' ? 'ring-1 ring-indigo-100' : ''}`}
						>
							<div className="text-left">
								<div className="text-sm font-medium text-gray-800">Industry</div>
								<div className="text-xs text-gray-500">{selectedIndustries.length} selected</div>
							</div>
							<ChevronDown
								className={`transform transition-transform ${openAccordion === 'industry' ? 'rotate-180' : ''}`}
							/>
						</button>
						{openAccordion === 'industry' && (
							<div className="p-3 bg-white border-t">
								<div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
									{industryOptions.length === 0 && <div className="text-sm text-gray-500">No options</div>}
									{industryOptions.map((o, idx) => {
										const title = o.title || o;
										const checked = selectedIndustries.includes(title);
										return (
											<label
												htmlFor={`title-industry-${idx}`}
												key={title}
												className="flex items-start gap-3 p-2 bg-white border rounded-lg hover:bg-gray-50 cursor-pointer"
											>
												<input
													id={`title-industry-${idx}`}
													type="checkbox"
													checked={checked}
													onChange={() => toggleSelection(title, selectedIndustries, setSelectedIndustries)}
													className="mt-1"
												/>
												<span className="text-sm">{title}</span>
											</label>
										);
									})}
								</div>
								<div className="mt-3 flex items-center gap-2">
									<button
										onClick={() => setOpenAccordion(null)}
										className="px-3 py-1 rounded bg-indigo-600 text-white text-sm"
									>
										Done
									</button>
									<button onClick={() => setSelectedIndustries([])} className="px-3 py-1 text-sm rounded border">
										Clear
									</button>
								</div>
							</div>
						)}
					</div>
				</div>

				<div className="mt-4">
					<div className="flex flex-wrap gap-2 items-center">
						{jobTitleKeyword && (
							<div className="flex items-center gap-2 bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full text-sm">
								<span className="truncate max-w-xs">Title: "{jobTitleKeyword}"</span>
								<button
									onClick={() => removeChip('keyword')}
									className="p-0.5 rounded hover:bg-indigo-100 flex items-center"
								>
									<X className="w-4 h-4" />
								</button>
							</div>
						)}

						{selectedDepartments.map((d) => (
							<div key={d} className="flex items-center gap-2 bg-white border px-3 py-1 rounded-full text-sm">
								<span>{d}</span>
								<button onClick={() => removeChip('dept', d)} className="p-1 rounded hover:bg-gray-100">
									<X className="w-4 h-4" />
								</button>
							</div>
						))}

						{selectedIndustries.map((i) => (
							<div key={i} className="flex items-center gap-2 bg-white border px-3 py-1 rounded-full text-sm">
								<span>{i}</span>
								<button onClick={() => removeChip('industry', i)} className="p-1 rounded hover:bg-gray-100">
									<X className="w-4 h-4" />
								</button>
							</div>
						))}

						{selectedSeniorities.map((s) => (
							<div key={s} className="flex items-center gap-2 bg-white border px-3 py-1 rounded-full text-sm">
								<span>{s}</span>
								<button onClick={() => removeChip('seniority', s)} className="p-1 rounded hover:bg-gray-100">
									<X className="w-4 h-4" />
								</button>
							</div>
						))}

						{filtersAppliedCount === 0 && <div className="text-sm text-gray-400">No filters selected</div>}
					</div>
				</div>
			</div>

			<div className="flex justify-end gap-3">
				<button onClick={handleBack} className="px-4 py-2 border rounded-lg">
					Back
				</button>

				<button
					onClick={handleContinue}
					disabled={loadingSubmit || !buyerPersonaName.trim() || !description.trim() || filtersAppliedCount === 0}
					className="px-5 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50"
				>
					{loadingSubmit ? (
						<span className="flex items-center gap-2">
							<Loader2 className="animate-spin" />
							Creating...
						</span>
					) : (
						'Create'
					)}
				</button>
			</div>

			{loadingOptions && (
				<div className="fixed right-6 bottom-6 bg-white p-3 rounded shadow flex items-center gap-2">
					<Loader2 className="animate-spin" />
					<span className="text-sm">Loading options...</span>
				</div>
			)}

			{error && (
				<div className="fixed right-6 bottom-6 bg-red-50 p-3 rounded shadow">
					<span className="text-sm text-red-700">{error}</span>
				</div>
			)}
		</div>
	);
}
