import { useState } from 'react';
import { Link } from 'lucide-react';
import { createLinkedinUserDetails } from '../services/authService';
import { useAuth } from '../hooks/useAuth';

export default function AddLinkedinDetails() {
	const [formData, setFormData] = useState({
		linkedin_url: '',
	});
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState(null);
	const [validationErrors, setValidationErrors] = useState({});
	const { accountVerify } = useAuth();

	const validateForm = () => {
		const errors = {};
		const linkedinRegex = /^https?:\/\/(www\.)?linkedin\.com\/.*$/i;

		if (!formData.linkedin_url.trim()) errors.linkedin_url = 'LinkedIn URL is required';
		else if (!linkedinRegex.test(formData.linkedin_url)) errors.linkedin_url = 'Enter a valid LinkedIn profile URL';

		setValidationErrors(errors);
		return Object.keys(errors).length === 0;
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!validateForm()) return;

		setLoading(true);
		setError(null);

		try {
			const res = await createLinkedinUserDetails(formData);
			if (res?.status === 200) {
				await accountVerify();
			} else {
				setError(res?.data?.message || 'Linkedin details creation failed');
			}
		} catch (err) {
			setError(err?.response?.data?.message || 'Linkedin details creation failed');
		} finally {
			setLoading(false);
		}
	};

	const handleChange = (e) => {
		setFormData({ ...formData, [e.target.name]: e.target.value });
	};

	return (
		<div className="w-screen h-screen flex items-center justify-center bg-gradient-to-br from-sky-50 to-indigo-100">
			<div className="w-[420px] bg-white p-8 rounded-2xl shadow-xl border border-gray-100">
				<h2 className="text-2xl font-semibold mb-2 text-center text-gray-800">Add LinkedIn URL</h2>
				<p className="text-sm text-gray-500 text-center mb-6">Add url to get started</p>

				{error && <div className="mb-4 text-sm text-red-600 bg-red-50 border border-red-200 p-2 rounded">{error}</div>}

				<form onSubmit={handleSubmit} className="space-y-5">
					<div>
						<label htmlFor="linkedin-url" className="block text-sm font-medium mb-1 text-gray-700">
							LinkedIn URL
						</label>
						<div className="relative">
							<Link className="absolute left-3 top-2.5 text-gray-400" size={18} />
							<input
								id="linkedin-url"
								type="url"
								name="linkedin_url"
								value={formData.linkedin_url}
								onChange={handleChange}
								className={`w-full pl-9 pr-3 py-2 border rounded-lg focus:ring-2 focus:ring-sky-500 outline-none ${
									validationErrors.linkedin_url ? 'border-red-400' : 'border-gray-300'
								}`}
								placeholder="https://linkedin.com/in/username"
							/>
						</div>
						{validationErrors.linkedin_url && (
							<p className="text-xs text-red-500 mt-1">{validationErrors.linkedin_url}</p>
						)}
					</div>

					<button
						type="submit"
						disabled={loading}
						className={`w-full py-2.5 text-white font-medium rounded-lg transition-all ${
							loading ? 'bg-sky-300 cursor-not-allowed' : 'bg-sky-600 hover:bg-sky-700 active:scale-[.98]'
						}`}
					>
						{loading ? 'Adding url...' : 'Submit'}
					</button>
				</form>
			</div>
		</div>
	);
}
