import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { Loader2 } from 'lucide-react';
import { loginWithLinkedin } from '../services/authService';
import { useExtensionFrameCheck } from '../hooks/useExtensionFrameCheck';

export default function LinkedInLogin() {
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState(null);
	const navigate = useNavigate();
	const { isAuthenticated, authChecked } = useAuth();
	const isFromExtension = useExtensionFrameCheck();

	useEffect(() => {
		if (authChecked && isAuthenticated) navigate('/');
	}, [authChecked, isAuthenticated, navigate]);

	const handleLinkedInLogin = async () => {
		setError(null);
		setLoading(true);

		const res = await loginWithLinkedin();
		if (res?.auth_url) {
			if (isFromExtension) {
				window.open(res.auth_url, '_blank');
			} else {
				window.location.href = res.auth_url;
			}
		} else {
			setError(res?.message || 'Unable to start LinkedIn login.');
		}
		setLoading(false);
	};

	if (!authChecked) {
		return (
			<div className="w-screen h-screen flex flex-col items-center justify-center bg-gray-50">
				<div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4"></div>
				<p className="text-gray-600 text-lg font-medium tracking-wide">Just a moment, verifying your session...</p>
			</div>
		);
	}
	return (
		<div className="w-screen h-screen flex items-center justify-center bg-gradient-to-br from-sky-50 to-indigo-100">
			<div className="w-[380px] bg-white p-8 rounded-2xl shadow-xl border border-gray-100">
				<h2 className="text-2xl font-semibold mb-2 text-center text-gray-800">Welcome Back</h2>
				<p className="text-sm text-gray-500 text-center mb-6">Sign in to continue</p>

				{error && <div className="mb-4 text-sm text-red-600 bg-red-50 border border-red-200 p-2 rounded">{error}</div>}

				<div className="space-y-5">
					<button
						type="button"
						onClick={handleLinkedInLogin}
						disabled={loading}
						className={`w-full py-2.5 text-white font-medium rounded-lg transition-all flex items-center justify-center gap-3 ${
							loading ? 'bg-sky-300 cursor-not-allowed' : 'bg-sky-600 hover:bg-sky-700 active:scale-[.98]'
						}`}
					>
						{loading ? (
							<>
								<Loader2 className="animate-spin" size={18} />
								<span>Redirecting...</span>
							</>
						) : (
							<>
								<svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
									<path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.761 0 5-2.239 5-5v-14c0-2.761-2.239-5-5-5zm-11.75 20h-3v-10h3v10zm-1.5-11.268c-.966 0-1.75-.786-1.75-1.752s.784-1.752 1.75-1.752 1.75.786 1.75 1.752-.784 1.752-1.75 1.752zm13.25 11.268h-3v-5.5c0-1.31-.026-2.993-1.826-2.993-1.827 0-2.106 1.427-2.106 2.902v5.591h-3v-10h2.881v1.367h.041c.401-.758 1.379-1.556 2.838-1.556 3.035 0 3.596 1.998 3.596 4.593v5.596z" />
								</svg>
								<span>Sign in with LinkedIn</span>
							</>
						)}
					</button>

					<div className="h-2" />
				</div>
			</div>
		</div>
	);
}
