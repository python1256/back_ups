import { useEffect, useState } from 'react';
import AddFilterModal from '../components/AddFilterModal';
import FilterCard from '../components/FilterCard';
import { getFilters } from '../services/filterService';

export default function Home() {
	const [query, setQuery] = useState('');
	const [showAdd, setShowAdd] = useState(false);
	const [filters, setFilters] = useState([]);
	const [page, setPage] = useState(1);
	const [totalPages, setTotalPages] = useState(1);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState(null);

	const handleSearchChange = (e) => {
		if (e.target.value === '') {
			loadFilters(1, '');
		}
		setQuery(e.target.value);
	};
	const loadFilters = async (p = 1, q = '') => {
		setLoading(true);
		setError(null);
		try {
			const res = await getFilters({ page: p, q });
			setFilters(res?.filters || []);
			setPage(res?.page || p);
			setTotalPages(res?.totalPages || 1);
		} catch (err) {
			console.error('loadFilters error:', err);
			setError(err?.message || 'Failed to load filters');
		} finally {
			setLoading(false);
		}
	};
	useEffect(() => {
		loadFilters(1, '');
	}, []);

	const handleDeleteFilter = (deletedId) => {
		setFilters((prev) => prev.filter((f) => f.id !== deletedId));
	};

	const onSearch = () => loadFilters(1, query);

	return (
		<div className="h-full bg-gray-50">
			<main className="max-w-4xl mx-auto p-6">
				<div className="flex items-center gap-4 mb-6">
					<input
						value={query}
						onChange={(e) => handleSearchChange(e)}
						placeholder="Search filters..."
						className="flex-1 border rounded px-3 py-2 shadow-sm focus:ring-2 focus:ring-indigo-500 outline-none"
					/>
					<button
						onClick={onSearch}
						disabled={!query.trim()}
						className={`px-4 py-2 border rounded-lg transition cursor-pointer ${
							query.trim()
								? 'bg-indigo-600 text-white hover:bg-indigo-700'
								: 'bg-gray-200 text-gray-500 cursor-not-allowed'
						}`}
					>
						Search
					</button>
					<button
						onClick={() => setShowAdd(true)}
						className="px-4 py-2 bg-white border rounded-lg shadow hover:bg-gray-50 transition cursor-pointer"
					>
						Add Filter
					</button>
				</div>

				<AddFilterModal
					open={showAdd}
					onClose={() => setShowAdd(false)}
					onAdded={() => {
						setShowAdd(false);
						loadFilters(page, query);
					}}
				/>

				{loading && <div className="text-center text-gray-600 py-6">Loading filters...</div>}

				{error && (
					<div className="text-center text-red-600 py-6 bg-red-50 border border-red-200 rounded-lg">{error}</div>
				)}

				{!loading && !error && (
					<div className="grid grid-cols-1  gap-4">
						{filters.length > 0 ? (
							filters.map((f) => <FilterCard key={f.id} filter={f} onDelete={handleDeleteFilter} />)
						) : (
							<p className="col-span-full text-center text-gray-500 py-6">No filters found.</p>
						)}
					</div>
				)}

				<div className="mt-6 flex items-center justify-end">
					<div className="flex gap-2">
						<button
							disabled={page <= 1}
							onClick={() => loadFilters(page - 1, query)}
							className="px-3 py-1 border rounded disabled:opacity-50 hover:bg-gray-100"
						>
							Prev
						</button>
						<span className="px-4 py-1 border rounded bg-gray-50">
							{page} / {totalPages}
						</span>
						<button
							disabled={page >= totalPages}
							onClick={() => loadFilters(page + 1, query)}
							className="px-3 py-1 border rounded disabled:opacity-50 hover:bg-gray-100"
						>
							Next
						</button>
					</div>
				</div>
			</main>
		</div>
	);
}
