import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Link, Loader2, MapPin, User, CalendarCheck2 } from 'lucide-react';
import { getProfilesByFilterId } from '../services/profileService';
import { timeAgo } from '../utils/utilFunctions';

export default function ProfilesPage() {
	const { id } = useParams();
	const navigate = useNavigate();

	const [profiles, setProfiles] = useState([]);
	const [filterName, setFilterName] = useState('');
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [page, setPage] = useState(1);
	const [totalProfiles, setTotalProfiles] = useState(0);
	const [pageSize, setPageSize] = useState(5);
	const [pageLoading, setPageLoading] = useState(false);

	useEffect(() => {
		const fetchProfiles = async (pageNum = 1) => {
			try {
				if (pageNum === 1) setLoading(true);
				else setPageLoading(true);

				setError(null);
				const data = await getProfilesByFilterId({ filterId: id, page: pageNum });

				setProfiles(data?.profiles || []);
				setFilterName(data?.filter_name || '');
				setTotalProfiles(data?.total_profiles || 0);
				setPageSize(data?.page_size || 5);
			} catch (err) {
				console.error('Failed to fetch profiles:', err);
				setError(err?.message || 'Failed to load profiles');
			} finally {
				setLoading(false);
				setPageLoading(false);
			}
		};

		fetchProfiles(page);
	}, [id, page]);

	const totalPages = Math.ceil(totalProfiles / pageSize);

	return (
		<div className="max-w-4xl mx-auto p-6">
			<div className="flex items-center justify-between mb-6">
				<button
					onClick={() => navigate(-1)}
					className="flex items-center gap-2 px-3 py-1 border rounded-lg hover:bg-gray-100 text-gray-600 hover:text-indigo-600 transition cursor-pointer"
				>
					<ArrowLeft size={20} />
					<span>Back</span>
				</button>
				<h2 className="text-xl font-semibold flex items-center gap-2">
					Profiles for <span className="text-indigo-600 font-bold">{filterName}</span>
					{pageLoading && <Loader2 className="animate-spin text-indigo-600" size={18} />}
				</h2>
			</div>

			{loading && (
				<div className="flex justify-center py-10">
					<Loader2 className="animate-spin text-indigo-600" size={32} />
				</div>
			)}

			{error && <div className="text-red-600">{error}</div>}

			{!loading && !error && profiles.length === 0 && (
				<div className="text-gray-500 text-center py-8">No profiles found.</div>
			)}

			{!loading && profiles.length > 0 && (
				<div className="grid grid-cols-1 gap-5">
					{profiles.map((profile) => {
						const updatedText = timeAgo(profile?.updatedAt);
						const decisionColors = {
							Accepted: 'bg-green-100 text-green-700',
							Neutral: 'bg-yellow-100 text-yellow-700',
							Rejected: 'bg-red-100 text-red-700',
						};

						const decisionClass = decisionColors[profile.decisionData.decision] || 'bg-red-100 text-red-700';
						return (
							<div
								key={profile.id}
								className="border rounded-xl p-5 shadow-sm hover:shadow-lg transition bg-white cursor-pointer"
								onClick={() => navigate(`/filter/${id}/profiles/${profile.id}`)}
							>
								<div className="flex items-center justify-between">
									<div className="flex items-start gap-3">
										{profile?.profileData?.profile_image_url ? (
											<img
												src={profile.profileData.profile_image_url}
												alt={profile?.profileData?.name || 'Profile Avatar'}
												className="w-12 h-12 rounded-full object-cover border"
											/>
										) : (
											<div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center border">
												<User size={22} className="text-gray-500" />
											</div>
										)}

										<div>
											<h4 className="font-semibold text-lg leading-tight text-gray-900">{profile.profileData.name}</h4>
											<p className="text-sm text-gray-600">{profile?.scoringData?.role || 'No title'}</p>

											{profile?.profileData?.contact_info?.linkedin_profile && (
												<a
													href={`https://${profile?.profileData.contact_info.linkedin_profile}`}
													target="_blank"
													rel="noopener noreferrer"
													onClick={(e) => e.stopPropagation()}
													className="inline-flex items-center gap-1 mt-1 text-indigo-600 hover:underline text-sm"
												>
													<Link size={14} /> LinkedIn Profile
												</a>
											)}
										</div>
									</div>

									<div className="flex flex-col items-end gap-1">
										{profile.scoringData?.overall_match_score !== undefined && (
											<div className="bg-indigo-100 text-indigo-700 text-xs px-3 py-1 rounded-full font-medium">
												{profile.scoringData.overall_match_score}%
											</div>
										)}
										{profile.decisionData?.decision && (
											<div className={`px-3 py-1 rounded-full text-xs font-medium ${decisionClass}`}>
												{profile.decisionData.decision}
											</div>
										)}
									</div>
								</div>

								{(profile.profileData?.location || updatedText) && (
									<div className="flex items-center justify-between text-xs text-gray-500 gap-1 mt-3">
										<div className="flex items-center gap-1">
											{profile.profileData.location && <MapPin size={14} />}
											<span>{profile.profileData.location}</span>
										</div>

										{updatedText ? (
											<div className="flex items-center gap-1 text-xs text-gray-500">
												<CalendarCheck2 size={14} />
												<span className="whitespace-nowrap">{updatedText}</span>
											</div>
										) : null}
									</div>
								)}
							</div>
						);
					})}
				</div>
			)}

			{!loading && totalProfiles > 0 && (
				<div className="flex justify-end mt-6 gap-2">
					<button
						onClick={() => setPage((p) => Math.max(1, p - 1))}
						disabled={page === 1}
						className="px-4 py-1 border rounded disabled:opacity-50 hover:bg-gray-100 transition"
					>
						Prev
					</button>

					<span className="px-4 py-1 border rounded bg-gray-50">
						{page} / {totalPages}
					</span>

					<button
						onClick={() => setPage((p) => (p < totalPages ? p + 1 : p))}
						disabled={page >= totalPages}
						className="px-4 py-1 border rounded disabled:opacity-50 hover:bg-gray-100 transition"
					>
						Next
					</button>
				</div>
			)}
		</div>
	);
}
