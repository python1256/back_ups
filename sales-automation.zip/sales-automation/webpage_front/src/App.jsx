import { Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthProvider';
import ProtectedRoute from './components/ProtectedRoute';
// import Login from './pages/Login';
// import Register from './pages/Register';
import Home from './pages/Home';
import FilterDetail from './pages/FilterDetails';
import './App.css';
import NotFound from './pages/NotFound';
import MainLayout from './components/MainLayout';
import EditFilterPage from './pages/EditFilterPage';
import ProfilesPage from './pages/ProfilesPage';
import ProfileDetailPage from './pages/ProfileDetailPage';
import ContentSectionPage from './pages/content/ContentSectionPage';
import CreateValuePropositionPage from './pages/content/value-proposition/CreateValuePropositionPage';
import CreateSalesAssetPage from './pages/content/sales-assets/CreateSalesAssetPage';
import LinkedInLogin from './pages/LinkedInLogin';
import LinkedInCallback from './pages/LinkedInCallback';
import { useExtensionFrameCheck } from './hooks/useExtensionFrameCheck';
import ExtensionHome from './pages/extension/ExtensionHome';
import AddLinkedinDetails from './pages/AddLinkedinDetails';

export default function App() {
	const isFromExtension = useExtensionFrameCheck();
	return (
		<AuthProvider>
			<Routes>
				{/* <Route path="/register" element={<Register />} /> */}
				{/* <Route path="/login" element={<Login />} /> */}
				<Route path="/login" element={<LinkedInLogin />} />
				<Route path="/linkedin-auth-success" element={<LinkedInCallback />} />
				<Route
					path="/linkedin-auth-details"
					element={
						<ProtectedRoute>
							<AddLinkedinDetails />
						</ProtectedRoute>
					}
				/>

				{isFromExtension ? (
					<Route path="/extension">
						<Route
							index
							element={
								<ProtectedRoute>
									<ExtensionHome />
								</ProtectedRoute>
							}
						/>
					</Route>
				) : (
					<>
						<Route
							path="/"
							element={
								<ProtectedRoute>
									<MainLayout>
										<Home />
									</MainLayout>
								</ProtectedRoute>
							}
						/>
						<Route
							path="/filter/:id"
							element={
								<ProtectedRoute>
									<MainLayout>
										<FilterDetail />
									</MainLayout>
								</ProtectedRoute>
							}
						/>
						<Route
							path="/filter/edit/:id"
							element={
								<ProtectedRoute>
									<MainLayout>
										<EditFilterPage />
									</MainLayout>
								</ProtectedRoute>
							}
						/>
						<Route
							path="/filter/:id/profiles"
							element={
								<ProtectedRoute>
									<MainLayout>
										<ProfilesPage />
									</MainLayout>
								</ProtectedRoute>
							}
						/>
						<Route
							path="/filter/:filterId/profiles/:id"
							element={
								<ProtectedRoute>
									<MainLayout>
										<ProfileDetailPage />
									</MainLayout>
								</ProtectedRoute>
							}
						/>
						<Route
							path="/content-section/*"
							element={
								<ProtectedRoute>
									<MainLayout>
										<ContentSectionPage />
									</MainLayout>
								</ProtectedRoute>
							}
						/>
						<Route
							path="/content-section/value-proposition/create"
							element={
								<ProtectedRoute>
									<MainLayout>
										<CreateValuePropositionPage />
									</MainLayout>
								</ProtectedRoute>
							}
						/>
						<Route
							path="/content-section/sales-assets/create"
							element={
								<ProtectedRoute>
									<MainLayout>
										<CreateSalesAssetPage />
									</MainLayout>
								</ProtectedRoute>
							}
						/>
						<Route path="*" element={<NotFound />} />
					</>
				)}
			</Routes>
		</AuthProvider>
	);
}
