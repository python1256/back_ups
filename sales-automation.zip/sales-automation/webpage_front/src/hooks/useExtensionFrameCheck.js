import { useState, useEffect } from 'react';

export const useExtensionFrameCheck = () => {
	const [isExtensionFrame, setIsExtensionFrame] = useState(false);

	useEffect(() => {
		try {
			const inIframe = window.self !== window.top;
			if (!inIframe) return;

			const origins = window.location.ancestorOrigins;
			const fromExtension =
				(origins.length > 0 && origins[0]?.startsWith('chrome-extension://')) ||
				document.referrer.startsWith('chrome-extension://');

			setIsExtensionFrame(fromExtension);
		} catch {
			setIsExtensionFrame(true);
		}
	}, []);

	return isExtensionFrame;
};
